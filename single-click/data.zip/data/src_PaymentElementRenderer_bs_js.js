"use strict";
(self["webpackChunkorca_payment_page"] = self["webpackChunkorca_payment_page"] || []).push([["src_PaymentElementRenderer_bs_js"],{

/***/ "./node_modules/rescript/lib/es6/belt_Option.js":
/*!******************************************************!*\
  !*** ./node_modules/rescript/lib/es6/belt_Option.js ***!
  \******************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cmp: () => (/* binding */ cmp),
/* harmony export */   cmpU: () => (/* binding */ cmpU),
/* harmony export */   eq: () => (/* binding */ eq),
/* harmony export */   eqU: () => (/* binding */ eqU),
/* harmony export */   flatMap: () => (/* binding */ flatMap),
/* harmony export */   flatMapU: () => (/* binding */ flatMapU),
/* harmony export */   forEach: () => (/* binding */ forEach),
/* harmony export */   forEachU: () => (/* binding */ forEachU),
/* harmony export */   getExn: () => (/* binding */ getExn),
/* harmony export */   getWithDefault: () => (/* binding */ getWithDefault),
/* harmony export */   isNone: () => (/* binding */ isNone),
/* harmony export */   isSome: () => (/* binding */ isSome),
/* harmony export */   keep: () => (/* binding */ keep),
/* harmony export */   keepU: () => (/* binding */ keepU),
/* harmony export */   map: () => (/* binding */ map),
/* harmony export */   mapU: () => (/* binding */ mapU),
/* harmony export */   mapWithDefault: () => (/* binding */ mapWithDefault),
/* harmony export */   mapWithDefaultU: () => (/* binding */ mapWithDefaultU),
/* harmony export */   orElse: () => (/* binding */ orElse)
/* harmony export */ });
/* harmony import */ var _curry_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./curry.js */ "./node_modules/rescript/lib/es6/curry.js");
/* harmony import */ var _caml_option_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");





function keepU(opt, p) {
  if (opt !== undefined && p(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt))) {
    return opt;
  }
  
}

function keep(opt, p) {
  return keepU(opt, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__1(p));
}

function forEachU(opt, f) {
  if (opt !== undefined) {
    return f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt));
  }
  
}

function forEach(opt, f) {
  forEachU(opt, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__1(f));
}

function getExn(x) {
  if (x !== undefined) {
    return _caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(x);
  }
  throw {
        RE_EXN_ID: "Not_found",
        Error: new Error()
      };
}

function mapWithDefaultU(opt, $$default, f) {
  if (opt !== undefined) {
    return f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt));
  } else {
    return $$default;
  }
}

function mapWithDefault(opt, $$default, f) {
  return mapWithDefaultU(opt, $$default, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__1(f));
}

function mapU(opt, f) {
  if (opt !== undefined) {
    return _caml_option_js__WEBPACK_IMPORTED_MODULE_1__.some(f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt)));
  }
  
}

function map(opt, f) {
  return mapU(opt, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__1(f));
}

function flatMapU(opt, f) {
  if (opt !== undefined) {
    return f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt));
  }
  
}

function flatMap(opt, f) {
  return flatMapU(opt, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__1(f));
}

function getWithDefault(opt, $$default) {
  if (opt !== undefined) {
    return _caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(opt);
  } else {
    return $$default;
  }
}

function orElse(opt, other) {
  if (opt !== undefined) {
    return opt;
  } else {
    return other;
  }
}

function isSome(x) {
  return x !== undefined;
}

function isNone(x) {
  return x === undefined;
}

function eqU(a, b, f) {
  if (a !== undefined) {
    if (b !== undefined) {
      return f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(a), _caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(b));
    } else {
      return false;
    }
  } else {
    return b === undefined;
  }
}

function eq(a, b, f) {
  return eqU(a, b, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__2(f));
}

function cmpU(a, b, f) {
  if (a !== undefined) {
    if (b !== undefined) {
      return f(_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(a), _caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(b));
    } else {
      return 1;
    }
  } else if (b !== undefined) {
    return -1;
  } else {
    return 0;
  }
}

function cmp(a, b, f) {
  return cmpU(a, b, _curry_js__WEBPACK_IMPORTED_MODULE_0__.__2(f));
}


/* No side effect */


/***/ }),

/***/ "./src/Components/Accordion.bs.js":
/*!****************************************!*\
  !*** ./src/Components/Accordion.bs.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _Radio_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Radio.bs.js */ "./src/Components/Radio.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE









function Accordion(props) {
  var isActive = props.isActive;
  var paymentOption = props.paymentOption;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.configAtom);
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.optionAtom);
  var layoutClass = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getLayoutClass(match$1.layout);
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.selectedOptionAtom);
  var setSelectedOption = match$2[1];
  var match$3 = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    if (isActive) {
      return ["AccordionItem--selected", "AccordionItemLabel--selected", "AccordionItemIcon--selected", true];
    } else {
      return ["", "", "", false];
    }
  }, [isActive]);
  var match$4 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDisplayNameAndIcon(match$1.customMethodNames, paymentOption.paymentMethodName, paymentOption.displayName, paymentOption.icon);
  var icon = match$4[1];
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "AccordionItem flex flex-col",
    style: {
      border: "1px solid " + themeObj.borderColor,
      borderBottomStyle: props.borderBottom ? "solid" : "hidden",
      cursor: "pointer",
      marginBottom: layoutClass.spacedAccordionItems ? themeObj.spacingAccordionItem : "",
      minHeight: "60px",
      width: "-webkit-fill-available",
      borderRadius: props.borderRadiusStyle
    },
    onClick: function (param) {
      setSelectedOption(function (param) {
        return paymentOption.paymentMethodName;
      });
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-row items-center " + match$3[0],
    style: {
      columnGap: themeObj.spacingUnit
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    condition: layoutClass.radios,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Radio_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
      checked: match$3[3]
    })
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "AccordionItemIcon " + match$3[2] + " flex items-center"
  }, icon !== undefined ? rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__.valFromOption(icon) : "<icon>"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "AccordionItemLabel " + match$3[1] + " flex items-center"
  }, paymentOption.paymentMethodName === "card" ? match.localeString.card : match$4[0])), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    condition: match$2[0] === paymentOption.paymentMethodName,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "mt-4 w-full"
    }, props.checkoutEle)
  }));
}
var make = Accordion;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/AccordionContainer.bs.js":
/*!*************************************************!*\
  !*** ./src/Components/AccordionContainer.bs.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Loader: () => (/* binding */ Loader),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Array_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Array.bs.js */ "./node_modules/@rescript/core/src/Core__Array.bs.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Accordion_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Accordion.bs.js */ "./src/Components/Accordion.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
/* harmony import */ var _PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function AccordionContainer$Loader(props) {
  var cardShimmerCount = props.cardShimmerCount;
  var paymentMethodList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.paymentMethodList);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.configAtom);
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.optionAtom);
  var layoutClass = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getLayoutClass(match$1.layout);
  if (typeof paymentMethodList !== "object" && paymentMethodList === "SemiLoaded") {
    return _rescript_core_src_Core_Array_bs_js__WEBPACK_IMPORTED_MODULE_2__.make(cardShimmerCount - 1 | 0, "").map(function (param, i) {
      var borderStyle = layoutClass.spacedAccordionItems ? themeObj.borderRadius : i === (cardShimmerCount - 2 | 0) ? "0px 0px " + themeObj.borderRadius + " " + themeObj.borderRadius : "";
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        key: i.toString(),
        className: "AccordionItem flex flex-row gap-3 animate-pulse cursor-default place-items-center",
        style: {
          border: "1px solid " + themeObj.borderColor,
          borderTopStyle: i === 0 && !layoutClass.spacedAccordionItems ? "hidden" : "solid",
          borderBottomStyle: i === (cardShimmerCount - 2 | 0) && !layoutClass.spacedAccordionItems || layoutClass.spacedAccordionItems ? "solid" : "hidden",
          cursor: "pointer",
          marginBottom: layoutClass.spacedAccordionItems ? themeObj.spacingAccordionItem : "",
          minHeight: "60px",
          minWidth: "80px",
          width: "100%",
          borderRadius: borderStyle,
          overflowWrap: "hidden"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_11__.Shimmer.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
          className: "w-full h-full animate-pulse",
          style: {
            backgroundColor: themeObj.colorPrimary,
            opacity: "10%"
          }
        }),
        classname: "opacity-50 h-5 w-[10%] rounded-full"
      }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_11__.Shimmer.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
          className: "w-full h-full animate-pulse",
          style: {
            backgroundColor: themeObj.colorPrimary,
            opacity: "10%"
          }
        }),
        classname: "opacity-50 h-2 w-[30%] rounded-full"
      }));
    });
  } else {
    return null;
  }
}
var Loader = {
  make: AccordionContainer$Loader
};
function AccordionContainer(props) {
  var checkoutEle = props.checkoutEle;
  var paymentOptions = props.paymentOptions;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.configAtom);
  var localeString = match.localeString;
  var themeObj = match.themeObj;
  var paymentMethodList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.paymentMethodList);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.optionAtom);
  var layoutClass = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getLayoutClass(match$1.layout);
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setShowMore = match$2[1];
  var showMore = match$2[0];
  var match$3 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.selectedOptionAtom);
  var setSelectedOption = match$3[1];
  var selectedOption = match$3[0];
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.paymentMethodListValue);
  _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.useEmitPaymentMethodInfo(selectedOption, paymentMethodListValue.payment_methods, props.cardProps, props.expiryProps);
  var cardOptionDetails = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_10__.getPaymentDetails(paymentOptions, localeString).slice(0, layoutClass.maxAccordionItems);
  var dropDownOptionsDetails = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_10__.getPaymentDetails(paymentOptions, localeString).slice(layoutClass.maxAccordionItems);
  var getBorderRadiusStyleForCardOptionDetails = function (index) {
    if (!showMore && !layoutClass.spacedAccordionItems && index === 0 && paymentMethodList === "SemiLoaded" && cardOptionDetails.length === 1) {
      return themeObj.borderRadius + " " + themeObj.borderRadius + " 0px 0px";
    } else if (!showMore && !layoutClass.spacedAccordionItems && index === 0 && cardOptionDetails.length === 1) {
      return themeObj.borderRadius;
    } else if (!showMore && !layoutClass.spacedAccordionItems && index === (cardOptionDetails.length - 1 | 0)) {
      return "0px 0px " + themeObj.borderRadius + " " + themeObj.borderRadius;
    } else if (!layoutClass.spacedAccordionItems && index === 0) {
      return themeObj.borderRadius + " " + themeObj.borderRadius + " 0px 0px";
    } else if (layoutClass.spacedAccordionItems) {
      return themeObj.borderRadius;
    } else {
      return "0px";
    }
  };
  var getBorderRadiusStyleForDropDownOptionDetails = function (index) {
    if (!layoutClass.spacedAccordionItems && index === (dropDownOptionsDetails.length - 1 | 0)) {
      return "0px 0px " + themeObj.borderRadius + " " + themeObj.borderRadius;
    } else if (layoutClass.spacedAccordionItems) {
      return themeObj.borderRadius;
    } else {
      return "0px";
    }
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (layoutClass.defaultCollapsed) {
      setSelectedOption(function (param) {
        return "";
      });
    }
  }, []);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-full"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "AccordionContainer flex flex-col overflow-auto no-scrollbar",
    style: {
      marginTop: themeObj.spacingAccordionItem,
      marginBottom: themeObj.spacingAccordionItem,
      width: "-webkit-fill-available"
    }
  }, cardOptionDetails.map(function (payOption, i) {
    var isActive = payOption.paymentMethodName === selectedOption;
    var borderRadiusStyle = getBorderRadiusStyleForCardOptionDetails(i);
    return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_3__.createElementWithKey(i.toString(), _Accordion_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
      paymentOption: payOption,
      isActive: isActive,
      checkoutEle: checkoutEle,
      borderBottom: !showMore && i === (cardOptionDetails.length - 1 | 0) && !layoutClass.spacedAccordionItems || layoutClass.spacedAccordionItems,
      borderRadiusStyle: borderRadiusStyle
    });
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(AccordionContainer$Loader, {
    cardShimmerCount: layoutClass.maxAccordionItems
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
    condition: showMore,
    children: dropDownOptionsDetails.map(function (payOption, i) {
      var isActive = payOption.paymentMethodName === selectedOption;
      var borderRadiusStyle = getBorderRadiusStyleForDropDownOptionDetails(i);
      return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_3__.createElementWithKey(i.toString(), _Accordion_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
        paymentOption: payOption,
        isActive: isActive,
        checkoutEle: checkoutEle,
        borderBottom: i === (dropDownOptionsDetails.length - 1 | 0) && !layoutClass.spacedAccordionItems || layoutClass.spacedAccordionItems,
        borderRadiusStyle: borderRadiusStyle
      });
    })
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
    condition: !showMore && dropDownOptionsDetails.length > 0,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
      className: "AccordionMore flex overflow-auto no-scrollbar",
      style: {
        cursor: "pointer",
        marginTop: themeObj.spacingUnit,
        minHeight: "60px",
        minWidth: "150px",
        padding: "20px",
        width: "100%",
        borderRadius: themeObj.borderRadius,
        columnGap: themeObj.spacingUnit
      },
      onClick: function (param) {
        setShowMore(function (param) {
          return !showMore;
        });
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-row",
      style: {
        columnGap: themeObj.spacingUnit
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "m-2"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
      name: "arrow-down",
      size: 10
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "AccordionItemLabel"
    }, "More")))
  }));
}
var make = AccordionContainer;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/ClickToPayAuthenticate.bs.js":
/*!*****************************************************!*\
  !*** ./src/Components/ClickToPayAuthenticate.bs.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @rescript/core/src/Core__Promise.bs.js */ "./node_modules/@rescript/core/src/Core__Promise.bs.js");
/* harmony import */ var rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rescript/lib/es6/caml_js_exceptions.js */ "./node_modules/rescript/lib/es6/caml_js_exceptions.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Types/PaymentType.bs.js */ "./src/Types/PaymentType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _SavedCardItem_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./SavedCardItem.bs.js */ "./src/Components/SavedCardItem.bs.js");
/* harmony import */ var _ClickToPayNotYou_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./ClickToPayNotYou.bs.js */ "./src/Components/ClickToPayNotYou.bs.js");
/* harmony import */ var _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../Types/ClickToPayHelpers.bs.js */ "./src/Types/ClickToPayHelpers.bs.js");
/* harmony import */ var _ClickToPayUiComponents_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./ClickToPayUiComponents.bs.js */ "./src/Components/ClickToPayUiComponents.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE



















function ClickToPayAuthenticate(props) {
  var closeComponentIfSavedMethodsAreEmpty = props.closeComponentIfSavedMethodsAreEmpty;
  var getVisaCards = props.getVisaCards;
  var cvcProps = props.cvcProps;
  var paymentTokenVal = props.paymentTokenVal;
  var setPaymentToken = props.setPaymentToken;
  var setIsClickToPayAuthenticateError = props.setIsClickToPayAuthenticateError;
  var isClickToPayAuthenticateError = props.isClickToPayAuthenticateError;
  var savedMethods = props.savedMethods;
  var loggerState = props.loggerState;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_13__.clickToPayConfig);
  var setClickToPayConfig = match[1];
  var clickToPayConfig = match[0];
  var setShowPaymentMethodsScreen = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_13__.showPaymentMethodsScreen);
  var match$1 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var setRequiredFieldsBody = match$1[1];
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setIsShowClickToPayNotYou = match$2[1];
  var match$3 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var consumerIdentity = clickToPayConfig.consumerIdentity;
  var clickToPayProvider = clickToPayConfig.clickToPayProvider;
  var clickToPayCards = clickToPayConfig.clickToPayCards;
  var email = clickToPayConfig.email;
  var setIsCTPAuthenticateNotYouClicked = match$3[1];
  var ctpCards = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(clickToPayCards, []);
  var mastercardAuth = function (cards) {
    if (cards.length !== 0) {
      return;
    }
    if (!(!isClickToPayAuthenticateError && email !== "")) {
      if (isClickToPayAuthenticateError) {
        return closeComponentIfSavedMethodsAreEmpty();
      } else {
        return;
      }
    }
    var iframe = document.createElement("iframe");
    iframe.id = "mastercard-account-verification-iframe";
    iframe.width = "100%";
    iframe.height = "410px";
    var element = document.getElementById("mastercard-account-verification");
    try {
      if (element == null) {
        return;
      }
      if (element.children.length !== 0) {
        return;
      }
      element.appendChild(iframe);
      var iframeContentWindow = iframe.contentWindow;
      if (iframeContentWindow === undefined) {
        return closeComponentIfSavedMethodsAreEmpty();
      }
      var authenticateConsumerIdentity_identityType = consumerIdentity.identityType;
      var authenticateConsumerIdentity_identityValue = consumerIdentity.identityValue.replaceAll(" ", "");
      var authenticateConsumerIdentity = {
        identityType: authenticateConsumerIdentity_identityType,
        identityValue: authenticateConsumerIdentity_identityValue
      };
      var authenticatePayload_windowRef = rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_4__.valFromOption(iframeContentWindow);
      var authenticatePayload = {
        windowRef: authenticatePayload_windowRef,
        consumerIdentity: authenticateConsumerIdentity
      };
      _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_6__.$$catch(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_16__.authenticate(authenticatePayload, loggerState).then(function (res) {
        if (res.TAG === "Ok") {
          var cards = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.flatMap(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__.Decode.array(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getJsonFromDict(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(res._0), "cards", null)), function (arr) {
            return arr.map(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_16__.clickToPayCardItemToObjMapper);
          }), []);
          setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.clickToPayCards = cards;
            return newrecord;
          });
          element.replaceChildren();
          if (cards.length === 0) {
            setIsClickToPayAuthenticateError(function (param) {
              return true;
            });
          }
          if (cards.length === 0 && savedMethods.length === 0) {
            setShowPaymentMethodsScreen(function (param) {
              return true;
            });
          }
          return Promise.resolve();
        }
        var errException = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.formatException(res._0);
        loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(JSON.stringify({
          message: "Error authenticating consumer identity - " + JSON.stringify(errException),
          scheme: clickToPayProvider
        }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
        var exceptionMessage = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__.Decode.string(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getJsonFromDict(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(errException), "message", null)), "");
        var isNotYouClicked = exceptionMessage.includes("Not you clicked");
        if (isNotYouClicked) {
          setIsCTPAuthenticateNotYouClicked(function (param) {
            return true;
          });
          setIsShowClickToPayNotYou(function (param) {
            return true;
          });
        } else {
          setIsClickToPayAuthenticateError(function (param) {
            return true;
          });
        }
        element.replaceChildren();
        return Promise.resolve();
      }), function (err) {
        loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(JSON.stringify({
          message: "Error authenticating consumer identity - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.formatException(err)),
          scheme: clickToPayProvider
        }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
        closeComponentIfSavedMethodsAreEmpty();
        return Promise.resolve();
      });
      return;
    } catch (raw_err) {
      var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_7__.internalToOCamlException(raw_err);
      loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(JSON.stringify({
        message: "Error - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.formatException(err)),
        scheme: clickToPayProvider
      }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
      return closeComponentIfSavedMethodsAreEmpty();
    }
  };
  var switchCtpAuthenticate;
  switch (clickToPayProvider) {
    case "VISA":
      switch (clickToPayConfig.visaComponentState) {
        case "CARDS_LOADING":
          switchCtpAuthenticate = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayUiComponents_bs_js__WEBPACK_IMPORTED_MODULE_17__.LoadingState.make, {});
          break;
        case "OTP_INPUT":
          switchCtpAuthenticate = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayNotYou_bs_js__WEBPACK_IMPORTED_MODULE_15__.ClickToPayNotYouText.make, {
            setIsShowClickToPayNotYou: setIsShowClickToPayNotYou
          }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
            className: "h-4 w-1"
          }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayUiComponents_bs_js__WEBPACK_IMPORTED_MODULE_17__.OtpInput.make, {
            getCards: function (otp) {
              return async function () {
                return await getVisaCards(consumerIdentity.identityValue, otp, consumerIdentity.identityType);
              }();
            },
            setIsClickToPayRememberMe: props.setIsClickToPayRememberMe
          }));
          break;
        case "NONE":
          switchCtpAuthenticate = null;
          break;
      }
      break;
    case "MASTERCARD":
      if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.isNone(clickToPayCards)) {
        mastercardAuth(ctpCards);
      }
      switchCtpAuthenticate = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        id: "mastercard-account-verification"
      });
      break;
    case "NONE":
      switchCtpAuthenticate = null;
      break;
  }
  var ctpCardList = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayNotYou_bs_js__WEBPACK_IMPORTED_MODULE_15__.ClickToPayNotYouText.make, {
    setIsShowClickToPayNotYou: setIsShowClickToPayNotYou
  }), ctpCards.map(function (obj, i) {
    var customerMethod = _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_12__.convertClickToPayCardToCustomerMethod(obj, clickToPayProvider);
    return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_8__.createElementWithKey("ctp_" + i.toString(), _SavedCardItem_bs_js__WEBPACK_IMPORTED_MODULE_14__.make, {
      setPaymentToken: setPaymentToken,
      isActive: paymentTokenVal === customerMethod.paymentToken,
      paymentItem: customerMethod,
      brandIcon: _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.getPaymentMethodBrand(customerMethod),
      index: i,
      savedCardlength: ctpCards.length,
      cvcProps: cvcProps,
      setRequiredFieldsBody: setRequiredFieldsBody
    });
  }));
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: !isClickToPayAuthenticateError && email !== "",
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_16__.SrcMark.make, {
      "card-brands": clickToPayConfig.availableCardBrands.join(","),
      height: "32"
    })
  }), match$2[0] ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayNotYou_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
    setIsShowClickToPayNotYou: setIsShowClickToPayNotYou,
    isCTPAuthenticateNotYouClicked: match$3[0],
    getVisaCards: getVisaCards
  }) : ctpCards.length === 0 ? switchCtpAuthenticate : ctpCardList);
}
var make = ClickToPayAuthenticate;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/ClickToPayNotYou.bs.js":
/*!***********************************************!*\
  !*** ./src/Components/ClickToPayNotYou.bs.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ClickToPayNotYouText: () => (/* binding */ ClickToPayNotYouText),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @rescript/core/src/Core__Promise.bs.js */ "./node_modules/@rescript/core/src/Core__Promise.bs.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Types/ClickToPayHelpers.bs.js */ "./src/Types/ClickToPayHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function ClickToPayNotYou(props) {
  var getVisaCards = props.getVisaCards;
  var setIsShowClickToPayNotYou = props.setIsShowClickToPayNotYou;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.configAtom);
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.clickToPayConfig);
  var setClickToPayConfig = match$1[1];
  var clickToPayConfig = match$1[0];
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setIdentifier = match$2[1];
  var identifier = match$2[0];
  var match$3 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setIsValid = match$3[1];
  var isValid = match$3[0];
  var match$4 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "EMAIL_ADDRESS";
  });
  var setIdentifierType = match$4[1];
  var identifierType = match$4[0];
  var updateCtpNotYouState = function (consumerIdentity) {
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.clickToPayCards = [];
      return newrecord;
    });
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.consumerIdentity = consumerIdentity;
      return newrecord;
    });
    setIsShowClickToPayNotYou(function (param) {
      return false;
    });
  };
  var onBack = function (param) {
    setIsShowClickToPayNotYou(function (param) {
      return false;
    });
  };
  var countryAndCodeCodeList = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.getArray(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__.Decode.object(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.phoneNumberJson), {}), "countries");
  var countryCodes = countryAndCodeCodeList.map(function (countryObj) {
    var countryObjDict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.getDictFromJson(countryObj);
    var countryCode = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.getString(countryObjDict, "phone_number_code", "");
    var countryName = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.getString(countryObjDict, "country_code", "");
    return {
      code: countryCode,
      countryISO: countryName
    };
  });
  var match$5 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(countryCodes[0], _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.defaultCountry).countryISO;
  });
  var setCountryCode = match$5[1];
  var countryCode = match$5[0];
  var formatPhoneNumber = function (value) {
    if (value.startsWith("+")) {
      if (value.includes(" ")) {
        return value;
      } else {
        return value.replace(/^\+(\d{1,3})(\d+)$/, "+$1 $2");
      }
    } else if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.isSome(rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_4__.nullable_to_opt(value.match(/^\d+$/)))) {
      return "+" + value;
    } else {
      return value;
    }
  };
  var handleInputChange = function (ev) {
    var target = ev.target;
    var newValue = target.value;
    var formattedValue = identifierType === "MOBILE_PHONE_NUMBER" ? formatPhoneNumber(newValue) : newValue;
    setIdentifier(function (param) {
      return formattedValue;
    });
  };
  var handleTypeChange = function (ev) {
    var target = ev.target;
    var newValue = target.value;
    setIdentifierType(function (param) {
      return newValue;
    });
    setIdentifier(function (param) {
      return "";
    });
  };
  var handleCountryCodeChange = function (ev) {
    var target = ev.target;
    var newValue = target.value;
    setCountryCode(function (param) {
      return newValue;
    });
  };
  var handlePhoneInputChange = function (ev) {
    var target = ev.target;
    var newValue = target.value.replace(/\\D/g, "");
    setIdentifier(function (param) {
      return newValue;
    });
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    setIsValid(function (param) {
      var emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
      var phoneRegex = /^\d{6,14}$/;
      if (identifierType === "EMAIL_ADDRESS") {
        return emailRegex.test(identifier);
      } else {
        return phoneRegex.test(identifier);
      }
    });
  }, [identifier, identifierType]);
  var handleSubmit = function (e) {
    e.preventDefault();
    if (!isValid) {
      return;
    }
    var country = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(countryCodes.find(function (country) {
      return countryCode === country.countryISO;
    }), _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.defaultCountry);
    var submittedIdentifier = identifierType === "MOBILE_PHONE_NUMBER" ? country.code.slice(1) + " " + identifier : identifier;
    var consumerIdentity = {
      identityType: identifierType,
      identityValue: submittedIdentifier
    };
    var match = clickToPayConfig.clickToPayProvider;
    switch (match) {
      case "VISA":
        updateCtpNotYouState(consumerIdentity);
        (async function () {
          setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.visaComponentState = "CARDS_LOADING";
            return newrecord;
          });
          try {
            await _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.signOutVisaUnified();
            return await getVisaCards(consumerIdentity.identityValue, "", consumerIdentity.identityType);
          } catch (exn) {
            return setClickToPayConfig(function (prev) {
              var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
              newrecord.visaComponentState = "NONE";
              return newrecord;
            });
          }
        })();
        return;
      case "MASTERCARD":
        _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_6__.$$catch(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.signOut().finally(function () {
          updateCtpNotYouState(consumerIdentity);
        }), function (err) {
          return Promise.resolve({
            TAG: "Error",
            _0: err
          });
        });
        return;
      case "NONE":
        return;
    }
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "p-4 bg-white rounded-lg border border-[#E6E1E1] flex flex-col space-y-4"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: !props.isCTPAuthenticateNotYouClicked,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
      onClick: onBack
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
      name: "arrow-back",
      size: 16
    }))
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex justify-center items-center"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", undefined, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.SrcMark.make, {
    "card-brands": clickToPayConfig.availableCardBrands.join(","),
    height: "32"
  })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col justify-center items-center space-y-4 px-4"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", {
    className: "text-sm font-normal"
  }, "Enter a new email or mobile number to access a different set of linked cards."), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("form", {
    className: "w-full flex flex-col justify-center items-center space-y-4",
    onSubmit: handleSubmit
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-full flex space-x-2"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "relative w-1/3"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", {
    className: "w-full p-3 pr-10 border border-gray-300 rounded-md appearance-none",
    value: _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.getIdentityType(identifierType),
    onChange: handleTypeChange
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", {
    value: _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.getIdentityType("EMAIL_ADDRESS")
  }, "Email"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", {
    value: _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.getIdentityType("MOBILE_PHONE_NUMBER")
  }, "Phone")), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "absolute inset-y-0 right-4 flex items-center selection:pointer-events-none"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
    name: "arrow-down",
    size: 10,
    className: "absolute z-10 pointer pointer-events-none"
  }))), identifierType === "EMAIL_ADDRESS" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
    className: "w-2/3 p-3 border border-gray-300 rounded-md",
    placeholder: "Enter email",
    required: true,
    type: "text",
    value: identifier,
    onChange: handleInputChange
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-2/3 flex border border-gray-300 rounded-md overflow-hidden"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "relative"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", {
    className: "h-full p-3 appearance-none focus:outline-none",
    value: countryCode,
    onChange: handleCountryCodeChange
  }, countryCodes.map(function (country) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", {
      key: country.code + "-" + country.countryISO,
      value: country.countryISO
    }, country.countryISO + " " + country.code);
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "absolute inset-y-0 right-4 flex items-center selection:pointer-events-none"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
    name: "arrow-down",
    size: 10,
    className: "absolute z-10 pointer pointer-events-none"
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
    className: "flex-grow p-3 focus:outline-none w-full",
    placeholder: "Mobile number",
    required: true,
    type: "tel",
    value: identifier,
    onChange: handlePhoneInputChange
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
    className: "w-full p-3 " + (isValid ? "" : "opacity-50 cursor-not-allowed"),
    style: {
      backgroundColor: themeObj.buttonBackgroundColor,
      color: themeObj.buttonTextColor,
      fontSize: themeObj.buttonTextFontSize,
      borderRadius: themeObj.buttonBorderRadius
    },
    disabled: !isValid,
    type: "submit"
  }, "Switch ID"))));
}
function ClickToPayNotYou$ClickToPayNotYouText(props) {
  var setIsShowClickToPayNotYou = props.setIsShowClickToPayNotYou;
  var onNotYouClick = function (param) {
    setIsShowClickToPayNotYou(function (param) {
      return true;
    });
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex space-x-2 text-sm text-[#484848]"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
    className: "underline cursor-pointer [text-underline-offset:0.2rem]",
    onClick: onNotYouClick
  }, "Not you?"));
}
var ClickToPayNotYouText = {
  make: ClickToPayNotYou$ClickToPayNotYouText
};
var make = ClickToPayNotYou;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/ClickToPayUiComponents.bs.js":
/*!*****************************************************!*\
  !*** ./src/Components/ClickToPayUiComponents.bs.js ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LoadingState: () => (/* binding */ LoadingState),
/* harmony export */   OtpInput: () => (/* binding */ OtpInput)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rescript/lib/es6/caml_js_exceptions.js */ "./node_modules/rescript/lib/es6/caml_js_exceptions.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Types/ClickToPayHelpers.bs.js */ "./src/Types/ClickToPayHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE










function ClickToPayUiComponents$LoadingState(props) {
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(function (prim) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("src-loader", prim);
  }, {});
}
var LoadingState = {
  make: ClickToPayUiComponents$LoadingState
};
function ClickToPayUiComponents$OtpInput(props) {
  var setIsClickToPayRememberMe = props.setIsClickToPayRememberMe;
  var getCards = props.getCards;
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.loggerAtom);
  var match = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setIsOtpSubmitting = match[1];
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.clickToPayConfig);
  var setClickToPayConfig = match$1[1];
  var clickToPayConfig = match$1[0];
  var otpValueRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef("");
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setResendLoading = match$2[1];
  var callBacks_otpChanged = function (ev) {
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.otpError = "";
      return newrecord;
    });
    _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(ev == null ? undefined : rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(ev), function (value) {
      var otp = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(value), "detail", "");
      if (otp.length === 6) {
        otpValueRef.current = otp;
        return;
      }
    });
  };
  var callBacks_continueClicked = function (param) {
    var verifyUserAndGetCards = async function () {
      try {
        setIsOtpSubmitting(function (param) {
          return true;
        });
        await getCards(otpValueRef.current);
        return setIsOtpSubmitting(function (param) {
          return false;
        });
      } catch (raw_err) {
        var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_err);
        return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
          message: "User validation failed - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.formatException(err)),
          scheme: "VISA"
        }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
      }
    };
    verifyUserAndGetCards();
  };
  var callBacks_resendClicked = function (param) {
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.otpError = "";
      return newrecord;
    });
    var resendOtp = async function () {
      try {
        setResendLoading(function (param) {
          return true;
        });
        await getCards("");
        return setResendLoading(function (param) {
          return false;
        });
      } catch (raw_err) {
        var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_err);
        return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
          message: "resend otp failed - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.formatException(err)),
          scheme: "VISA"
        }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
      }
    };
    resendOtp();
  };
  var callBacks_rememberMe = function (ev) {
    _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(ev == null ? undefined : rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(ev), function (e) {
      var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(e);
      var rememberMe = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getBool(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(dict, "detail"), "rememberMe", false);
      setIsClickToPayRememberMe(function (param) {
        return rememberMe;
      });
    });
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var srcOtpInput = document.querySelector("src-otp-input");
    var controller = new AbortController();
    var signal = controller.signal;
    var listeners = [{
      name: "otpChanged",
      callback: callBacks_otpChanged
    }, {
      name: "continue",
      callback: callBacks_continueClicked
    }, {
      name: "resendOtp",
      callback: callBacks_resendClicked
    }, {
      name: "rememberMe",
      callback: callBacks_rememberMe
    }];
    _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(srcOtpInput == null ? undefined : rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(srcOtpInput), function (element) {
      listeners.forEach(function (listener) {
        var $$event = listener.name;
        var callback = listener.callback;
        var options = {
          signal: signal
        };
        _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(element.addEventListener, function (func) {
          func($$event, callback, options);
        });
      });
    });
    return function () {
      controller.abort();
    };
  }, []);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_8__.SrcOtpInput.make, {
    "display-header": false,
    "display-cancel-option": false,
    "display-remember-me": true,
    "disable-elements": match[0],
    "is-successful": false,
    "otp-resend-loading": match$2[0],
    "error-reason": clickToPayConfig.otpError,
    locale: "en-US",
    id: "src-otp-input",
    type: "",
    "card-brands": "",
    "masked-identity-value": clickToPayConfig.maskedIdentity,
    "network-id": " ",
    "auto-submit": false
  });
}
var OtpInput = {
  make: ClickToPayUiComponents$OtpInput
};

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/ErrorComponent.bs.js":
/*!*********************************************!*\
  !*** ./src/Components/ErrorComponent.bs.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_belt_Option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/belt_Option.js */ "./node_modules/rescript/lib/es6/belt_Option.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE







function ErrorComponent(props) {
  var __cvcError = props.cvcError;
  var __expiryError = props.expiryError;
  var __cardError = props.cardError;
  var __errorStr = props.errorStr;
  var errorStr = __errorStr !== undefined ? rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.valFromOption(__errorStr) : undefined;
  var cardError = __cardError !== undefined ? __cardError : "";
  var expiryError = __expiryError !== undefined ? __expiryError : "";
  var cvcError = __cvcError !== undefined ? __cvcError : "";
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.configAtom);
  var themeObj = match.themeObj;
  var match$1 = match.config.appearance;
  var innerLayout = match$1.innerLayout;
  var errorTextStyle_color = themeObj.colorDangerText;
  var errorTextStyle_fontSize = themeObj.fontSizeSm;
  var errorTextStyle_textAlign = "left";
  var errorTextStyle_alignSelf = "start";
  var errorTextStyle = {
    color: errorTextStyle_color,
    fontSize: errorTextStyle_fontSize,
    textAlign: errorTextStyle_textAlign,
    alignSelf: errorTextStyle_alignSelf
  };
  var isSpacedErrorShown = errorStr !== undefined ? errorStr.length > 0 : false;
  var isCompressedErrorShown = innerLayout === "Compressed" && (cardError !== "" || expiryError !== "" || cvcError !== "");
  if (innerLayout === "Spaced") {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
      condition: isSpacedErrorShown,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "Error pt-1",
        style: errorTextStyle
      }, rescript_lib_es6_belt_Option_js__WEBPACK_IMPORTED_MODULE_2__.getWithDefault(errorStr, ""))
    });
  } else {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
      condition: isCompressedErrorShown,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "Error pt-1",
        style: errorTextStyle
      }, "Invalid input")
    });
  }
}
var make = ErrorComponent;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/Or.bs.js":
/*!*********************************!*\
  !*** ./src/Components/Or.bs.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE




function Or(props) {
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_2__.configAtom);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    "aria-hidden": true,
    className: "w-full w-max-[750px] relative flex flex-row my-4 "
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "OrPayUsingLine relative top-[50%] h-[1px] bg-gray-400  w-full self-center"
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "OrPayUsingLabel relative min-w-fit px-5 text-sm text-gray-400 flex justify-center"
  }, match.localeString.orPayUsing), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "OrPayUsingLine relative top-[50%] h-[1px] bg-gray-400 w-full self-center"
  }));
}
var make = Or;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/PayNowButton.bs.js":
/*!*******************************************!*\
  !*** ./src/Components/PayNowButton.bs.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Loader: () => (/* binding */ Loader),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Utilities/PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Context_PaymentTypeContext_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Context/PaymentTypeContext.bs.js */ "./src/Context/PaymentTypeContext.bs.js");
/* harmony import */ var _Utilities_EventListenerManager_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/EventListenerManager.bs.js */ "./src/Utilities/EventListenerManager.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE











function PayNowButton$Loader(props) {
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.configAtom);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-8 h-8 animate-spin",
    style: {
      color: match.themeObj.colorTextSecondary
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    name: "loader",
    size: 32
  }));
}
var Loader = {
  make: PayNowButton$Loader
};
function PayNowButton(props) {
  var label = props.label;
  var onClickHandler = props.onClickHandler;
  var match = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setShowLoader = match[1];
  var match$1 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setIsPayNowButtonDisable = match$1[1];
  var isPayNowButtonDisable = match$1[0];
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.configAtom);
  var themeObj = match$2.themeObj;
  var match$3 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.optionAtom);
  var sdkHandleConfirmPayment = match$3.sdkHandleConfirmPayment;
  var match$4 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_7__.optionAtom);
  var paymentType = _Context_PaymentTypeContext_bs_js__WEBPACK_IMPORTED_MODULE_8__.usePaymentType();
  var confirmPayload = _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_6__.confirmPayloadForSDKButton(sdkHandleConfirmPayment);
  var buttonText;
  buttonText = paymentType === "PaymentMethodsManagement" ? _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(match$4.sdkHandleSavePayment.buttonText, "Save Card") : label !== undefined ? label : _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(sdkHandleConfirmPayment.buttonText, match$2.localeString.payNowButton);
  var handleMessage = function ($$event) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.safeParse(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getStringFromJson($$event.data, ""));
    var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json);
    var submitSuccessfulVal = dict["submitSuccessful"];
    if (submitSuccessfulVal !== undefined && !_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_2__.Decode.bool(submitSuccessfulVal), false)) {
      setIsPayNowButtonDisable(function (param) {
        return false;
      });
      return setShowLoader(function (param) {
        return false;
      });
    }
  };
  var onClickHandlerFunc = function (param) {
    if (onClickHandler !== undefined) {
      return onClickHandler();
    }
  };
  var handleOnClick = function (param) {
    setIsPayNowButtonDisable(function (param) {
      return true;
    });
    setShowLoader(function (param) {
      return true;
    });
    _Utilities_EventListenerManager_bs_js__WEBPACK_IMPORTED_MODULE_9__.addSmartEventListener("message", handleMessage, "onSubmitSuccessful");
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.messageParentWindow(undefined, [["handleSdkConfirm", confirmPayload]]);
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col gap-1 h-auto w-full items-center"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
    className: "w-full flex flex-row justify-center items-center",
    style: {
      backgroundColor: themeObj.buttonBackgroundColor,
      border: themeObj.buttonBorderWidth + " solid " + themeObj.buttonBorderColor,
      cursor: isPayNowButtonDisable ? "not-allowed" : "pointer",
      height: themeObj.buttonHeight,
      width: themeObj.buttonWidth,
      opacity: isPayNowButtonDisable ? "0.6" : "1",
      borderRadius: themeObj.buttonBorderRadius
    },
    disabled: isPayNowButtonDisable,
    onClick: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isNone(onClickHandler) ? handleOnClick : onClickHandlerFunc
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
    id: "button-text",
    style: {
      color: themeObj.buttonTextColor,
      fontSize: themeObj.buttonTextFontSize,
      fontWeight: themeObj.buttonTextFontWeight
    }
  }, match[0] ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(PayNowButton$Loader, {}) : buttonText)));
}
var make = PayNowButton;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/PaymentShimmer.bs.js":
/*!*********************************************!*\
  !*** ./src/Components/PaymentShimmer.bs.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _Block_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Block.bs.js */ "./src/Components/Block.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE







function PaymentShimmer(props) {
  var __showInBlock = props.showInBlock;
  var showInBlock = __showInBlock !== undefined ? __showInBlock : true;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.configAtom);
  var bottomElement = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_5__.Shimmer.make, {
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "w-full h-2 animate-pulse",
      style: {
        backgroundColor: match.themeObj.colorPrimary,
        opacity: "10%"
      }
    }),
    classname: "opacity-50"
  });
  if (showInBlock) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Block_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
      bottomElement: rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__.some(bottomElement)
    });
  } else {
    return bottomElement;
  }
}
var make = PaymentShimmer;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/PoweredBy.bs.js":
/*!****************************************!*\
  !*** ./src/Components/PoweredBy.bs.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE






function PoweredBy(props) {
  var __className = props.className;
  var className = __className !== undefined ? __className : "pt-4";
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.optionAtom);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
    condition: match.branding === "Auto",
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-hidden": true,
      className: "text-xs text-center w-full flex justify-center " + className
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_2__.make, {
      name: "powerd-by-hyper",
      size: 18,
      width: 130
    }))
  });
}
var make = PoweredBy;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/Radio.bs.js":
/*!************************************!*\
  !*** ./src/Components/Radio.bs.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
// Generated by ReScript, PLEASE EDIT WITH CARE


function Radio(props) {
  var __border = props.border;
  var __opacity = props.opacity;
  var __marginTop = props.marginTop;
  var __className = props.className;
  var __padding = props.padding;
  var __height = props.height;
  var checked = props.checked;
  var height = __height !== undefined ? __height : "15px";
  var padding = __padding !== undefined ? __padding : "36%";
  var className = __className !== undefined ? __className : "default";
  var marginTop = __marginTop !== undefined ? __marginTop : "0";
  var opacity = __opacity !== undefined ? __opacity : "100%";
  var border = __border !== undefined ? __border : "2px solid currentColor";
  var $$class = checked ? "active" : "inactive";
  var nonActiveOpacity = checked ? "100%" : opacity;
  var css = "\n  input[type=\"radio\"] {\n    -webkit-appearance: none;\n    appearance: none;\n    -moz-appearance: initial;\n  }\n\n  ." + className + $$class + " input[type=\"radio\"] {\n    visibility: hidden;\n}\n\n." + className + $$class + " input[type=\"radio\"]::before {\n    border: " + border + ";\n    height: " + height + ";\n    width: " + height + ";\n    border-radius: 50%;\n    display: block;\n    content: \" \";\n    opacity: " + nonActiveOpacity + ";\n    cursor: pointer;\n    visibility: visible;\n    margin-top: " + marginTop + ";\n}\n\n." + className + $$class + " input[type=\"radio\"]:checked::before {\n    background: radial-gradient(currentColor " + padding + ", transparent 32%);\n}";
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("style", undefined, css), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: className + $$class + " flex self-center"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", {
    className: "Radio",
    checked: checked,
    readOnly: true,
    type: "radio"
  })));
}
var make = Radio;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/SavedCardItem.bs.js":
/*!********************************************!*\
  !*** ./src/Components/SavedCardItem.bs.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RenderSavedPaymentMethodItem: () => (/* binding */ RenderSavedPaymentMethodItem),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Radio_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Radio.bs.js */ "./src/Components/Radio.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Surcharge_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Surcharge.bs.js */ "./src/Components/Surcharge.bs.js");
/* harmony import */ var _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Utilities/TestUtils.bs.js */ "./src/Utilities/TestUtils.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _DynamicFields_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./DynamicFields.bs.js */ "./src/Components/DynamicFields.bs.js");
/* harmony import */ var _shared_code_sdk_utils_CardValidations_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../../shared-code/sdk-utils/CardValidations.bs.js */ "./shared-code/sdk-utils/CardValidations.bs.js");
/* harmony import */ var _PaymentInputField_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./PaymentInputField.bs.js */ "./src/Components/PaymentInputField.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


















function SavedCardItem$RenderSavedPaymentMethodItem(props) {
  var paymentMethodType = props.paymentMethodType;
  var paymentItem = props.paymentItem;
  var match = paymentItem.paymentMethod;
  switch (match) {
    case "bank_debit":
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-label": paymentMethodType.toUpperCase() + " bank debit account ending in " + paymentItem.bank.mask,
        className: "flex flex-col items-start",
        role: "group"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", undefined, paymentMethodType.toUpperCase() + " " + _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.snakeToTitleCase(paymentItem.paymentMethod)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "PickerItemLabel flex flex-row gap-3 items-center"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-hidden": true,
        className: "tracking-widest"
      }, "****"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-hidden": true
      }, paymentItem.bank.mask)));
    case "card":
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-label": "Card " + paymentItem.card.nickname + ", ending in " + paymentItem.card.last4Digits,
        className: "flex flex-col items-start",
        role: "group"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "text-base tracking-wide"
      }, paymentItem.card.nickname.length > 15 ? paymentItem.card.nickname.slice(0, 13).concat("..") : paymentItem.card.nickname), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "PickerItemLabel flex flex-row gap-3 items-center text-sm"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-hidden": true,
        className: "tracking-widest"
      }, "****"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-hidden": true,
        className: "tracking-wide"
      }, paymentItem.card.last4Digits)));
    default:
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-label": _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.snakeToTitleCase(paymentMethodType)
      }, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.snakeToTitleCase(paymentMethodType));
  }
}
var RenderSavedPaymentMethodItem = {
  make: SavedCardItem$RenderSavedPaymentMethodItem
};
function SavedCardItem(props) {
  var cvcProps = props.cvcProps;
  var paymentItem = props.paymentItem;
  var isActive = props.isActive;
  var setPaymentToken = props.setPaymentToken;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_12__.configAtom);
  var localeString = match.localeString;
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_12__.optionAtom);
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_12__.cardBrand);
  var cvcError = cvcProps.cvcError;
  var cvcNumber = cvcProps.cvcNumber;
  var isCVCValid = cvcProps.isCVCValid;
  var setCardBrand = match$2[1];
  var cvcRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
  var pickerItemClass = isActive ? "PickerItem--selected" : "";
  var focusCVC = function () {
    setCardBrand(function (param) {
      var val = paymentItem.card.scheme;
      if (val !== undefined) {
        return val;
      } else {
        return "";
      }
    });
    var optionalRef = cvcRef.current;
    if (!(optionalRef == null)) {
      _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(optionalRef == null ? undefined : rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(optionalRef), function (input) {
        input.focus();
      });
      return;
    }
  };
  var isCard = paymentItem.paymentMethod === "card";
  var isRenderCvv = isCard && paymentItem.requiresCvv;
  var expiryMonth = paymentItem.card.expiryMonth;
  var expiryYear = paymentItem.card.expiryYear;
  var cardLast4 = paymentItem.card.last4Digits;
  var cardBin = paymentItem.card.cardBin;
  var paymentMethodType = paymentItem.paymentMethodType;
  var paymentMethodType$1 = paymentMethodType !== undefined ? paymentMethodType : "debit";
  var match$3 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.useNonPiiAddressData();
  var pinCode = match$3.pinCode;
  var state = match$3.state;
  var country = match$3.country;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (isActive) {
      focusCVC();
      _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.emitExpiryDate(_shared_code_sdk_utils_CardValidations_bs_js__WEBPACK_IMPORTED_MODULE_15__.formatCardExpiryNumber(expiryMonth + expiryYear.substring(2, 4)));
      _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.emitPaymentMethodInfo(paymentItem.paymentMethod, paymentMethodType$1, _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getCardType(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(paymentItem.card.scheme, "")), cardLast4, cardBin, expiryMonth, expiryYear, country, state, pinCode, true);
    }
  }, [isActive, paymentItem, country, state, pinCode]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.emitIsFormReadyForSubmission(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(isCVCValid, false));
  }, [isCVCValid]);
  var expiryDate = new Date(expiryYear + "-" + expiryMonth);
  expiryDate.setMonth(expiryDate.getMonth() + 1 | 0);
  var currentDate = new Date();
  var isCardExpired = isCard && rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.lessthan(expiryDate, currentDate);
  var billingDetailsArray = [paymentItem.billing.address.line1, paymentItem.billing.address.line2, paymentItem.billing.address.line3, paymentItem.billing.address.city, paymentItem.billing.address.state, paymentItem.billing.address.country, paymentItem.billing.address.zip].map(function (item) {
    return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(item, "");
  }).filter(function (item) {
    return item.trim() !== "";
  });
  var billingDetailsArrayLength = billingDetailsArray.length;
  var isCVCEmpty = cvcNumber.length === 0;
  var match$4 = match.config.appearance;
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
    condition: !match$1.hideExpiredPaymentMethods || !isCardExpired,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
      className: "PickerItem " + pickerItemClass + " flex flex-row items-stretch",
      style: {
        background: "transparent",
        borderTop: "none",
        borderRight: "none",
        borderBottom: props.index === (props.savedCardlength - 1 | 0) ? "0px" : "1px solid " + themeObj.borderColor,
        borderLeft: "none",
        color: themeObj.colorTextSecondary,
        cursor: "pointer",
        minWidth: "150px",
        padding: "1rem 0 1rem 0",
        width: "100%",
        opacity: isCardExpired ? "0.7" : "1",
        borderRadius: "0px",
        boxShadow: "none"
      },
      type: "button",
      onClick: function (param) {
        setPaymentToken(function (param) {
          return {
            paymentToken: paymentItem.paymentToken,
            customerId: paymentItem.customerId
          };
        });
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "w-full"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", undefined, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-row justify-between items-center"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-row justify-center items-center",
      style: {
        columnGap: themeObj.spacingUnit
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      style: {
        color: isActive ? themeObj.colorPrimary : ""
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Radio_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
      checked: isActive,
      height: "18px",
      padding: "46%",
      className: "savedcard",
      marginTop: "-2px",
      opacity: "20%",
      border: "1px solid currentColor"
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "PickerItemIcon mx-3 flex  items-center "
    }, props.brandIcon), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-col"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex items-center gap-4"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(SavedCardItem$RenderSavedPaymentMethodItem, {
      paymentItem: paymentItem,
      paymentMethodType: paymentMethodType$1
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: match$1.displayDefaultSavedPaymentIcon && paymentItem.defaultPaymentMethodSet,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
        name: "checkmark",
        size: 16,
        style: {
          color: themeObj.colorPrimary
        }
      })
    })))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isCard,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-label": "Expires " + expiryMonth + " / " + _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.formatExpiryToTwoDigit(expiryYear),
        className: "flex flex-row items-center justify-end gap-3 -mt-1",
        style: {
          fontSize: "14px",
          opacity: "0.5"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        "aria-hidden": true,
        className: "flex"
      }, expiryMonth + " / " + _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.formatExpiryToTwoDigit(expiryYear)))
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "w-full"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-col items-start mx-8"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isActive && isRenderCvv,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "flex flex-row items-start justify-start gap-2",
        style: {
          fontSize: "14px",
          opacity: "0.5"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "tracking-widest w-12 mt-6"
      }, localeString.cvcTextLabel + ": "), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "flex h mx-4 justify-start w-16 " + (isActive ? "opacity-1 mt-4" : "opacity-0")
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentInputField_bs_js__WEBPACK_IMPORTED_MODULE_16__.make, {
        isValid: rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(isCVCValid),
        setIsValid: cvcProps.setIsCVCValid,
        height: "1.8rem",
        inputFieldClassName: "flex justify-start",
        value: cvcNumber,
        onChange: cvcProps.changeCVCNumber,
        onBlur: cvcProps.handleCVCBlur,
        errorString: "",
        name: _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.cardCVVInputTestId,
        type_: "tel",
        maxLength: 4,
        placeholder: "123",
        className: "tracking-widest justify-start w-full",
        inputRef: cvcRef,
        autocomplete: "cc-csc"
      })))
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isActive && match$1.displayBillingDetails && billingDetailsArrayLength > 0,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "tracking-wide text-sm text-left gap-2 mt-4 ml-2"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "font-semibold"
      }, "Billing Details:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "font-normal"
      }, billingDetailsArray.join(", ")))
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isActive && isCVCEmpty && match$4.innerLayout === "Spaced" && cvcError !== "",
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "Error pt-1 mt-1 ml-2",
        style: {
          color: themeObj.colorDangerText,
          fontSize: themeObj.fontSizeSm
        }
      }, cvcError)
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isCardExpired,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "italic mt-3 ml-1",
        style: {
          fontSize: "14px",
          opacity: "0.7"
        }
      }, "*" + localeString.cardExpiredText)
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: isActive,
      children: null
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DynamicFields_bs_js__WEBPACK_IMPORTED_MODULE_14__.make, {
      paymentMethod: paymentItem.paymentMethod,
      paymentMethodType: paymentMethodType$1,
      setRequiredFieldsBody: props.setRequiredFieldsBody,
      isSavedCardFlow: true,
      savedMethod: paymentItem
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Surcharge_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
      paymentMethod: paymentItem.paymentMethod,
      paymentMethodType: paymentMethodType$1,
      cardBrand: _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getCardType(match$2[0])
    })))))))
  });
}
var make = SavedCardItem;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/SavedMethods.bs.js":
/*!*******************************************!*\
  !*** ./src/Components/SavedMethods.bs.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Promise.bs.js */ "./node_modules/@rescript/core/src/Core__Promise.bs.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @rescript/react/src/RescriptReactRouter.bs.js */ "./node_modules/@rescript/react/src/RescriptReactRouter.bs.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Terms_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Terms.bs.js */ "./src/Components/Terms.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Utilities/TestUtils.bs.js */ "./src/Utilities/TestUtils.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../Utilities/PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../Types/PaymentType.bs.js */ "./src/Types/PaymentType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ../Hooks/UtilityHooks.bs.js */ "./src/Hooks/UtilityHooks.bs.js");
/* harmony import */ var _SavedCardItem_bs_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./SavedCardItem.bs.js */ "./src/Components/SavedCardItem.bs.js");
/* harmony import */ var _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../Utilities/PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
/* harmony import */ var _Utilities_ApplePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../Utilities/ApplePayHelpers.bs.js */ "./src/Utilities/ApplePayHelpers.bs.js");
/* harmony import */ var _Utilities_GooglePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ../Utilities/GooglePayHelpers.bs.js */ "./src/Utilities/GooglePayHelpers.bs.js");
/* harmony import */ var _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ../Types/ClickToPayHelpers.bs.js */ "./src/Types/ClickToPayHelpers.bs.js");
/* harmony import */ var _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../Utilities/SamsungPayHelpers.bs.js */ "./src/Utilities/SamsungPayHelpers.bs.js");
/* harmony import */ var _SaveDetailsCheckbox_bs_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./SaveDetailsCheckbox.bs.js */ "./src/Components/SaveDetailsCheckbox.bs.js");
/* harmony import */ var _PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
/* harmony import */ var _ClickToPayAuthenticate_bs_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./ClickToPayAuthenticate.bs.js */ "./src/Components/ClickToPayAuthenticate.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE






























function SavedMethods(props) {
  var cvcProps = props.cvcProps;
  var loadSavedCards = props.loadSavedCards;
  var savedMethods = props.savedMethods;
  var setPaymentToken = props.setPaymentToken;
  var paymentToken = props.paymentToken;
  var clickToPayConfig = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.clickToPayConfig);
  var clickToPayProvider = clickToPayConfig.clickToPayProvider;
  var customerMethods = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(clickToPayConfig.clickToPayCards, []).map(function (obj) {
    return _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_15__.convertClickToPayCardToCustomerMethod(obj, clickToPayProvider);
  });
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.configAtom);
  var localeString = match.localeString;
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.showPaymentMethodsScreen);
  var setShowPaymentMethodsScreen = match$1[1];
  var showPaymentMethodsScreen = match$1[0];
  var areRequiredFieldsValid = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.areRequiredFieldsValid);
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.isManualRetryEnabled);
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var setRequiredFieldsBody = match$2[1];
  var requiredFieldsBody = match$2[0];
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.loggerAtom);
  var setUserError = function (message) {
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.postFailedSubmitResponse("validation_error", message);
    loggerState.setLogError(message, "INVALID_FORMAT", undefined, undefined, undefined, undefined, undefined);
  };
  var match$3 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.optionAtom);
  var readOnly = match$3.readOnly;
  var savedPaymentMethodsCheckboxCheckedByDefault = match$3.savedPaymentMethodsCheckboxCheckedByDefault;
  var displaySavedPaymentMethodsCheckbox = match$3.displaySavedPaymentMethodsCheckbox;
  var match$4 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return savedPaymentMethodsCheckboxCheckedByDefault;
  });
  var isSaveCardsChecked = match$4[0];
  var isGuestCustomer = _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_19__.useIsGuestCustomer();
  var match$5 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_16__.keys);
  var iframeId = match$5.iframeId;
  var clientSecret = match$5.clientSecret;
  var url = _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_6__.useUrl(undefined, undefined);
  var componentName = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.getQueryParamsDictforKey(url.search, "componentName");
  var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(props.sessions);
  var sessionObj = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.itemToObjMapper(dict, "Others");
  }, [dict]);
  var gPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.getPaymentSessionObj(sessionObj.sessionsToken, "Gpay");
  var applePaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.itemToObjMapper(dict, "ApplePayObject");
  var applePayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.getPaymentSessionObj(applePaySessionObj.sessionsToken, "ApplePay");
  var samsungPaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.itemToObjMapper(dict, "SamsungPayObject");
  var samsungPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_18__.getPaymentSessionObj(samsungPaySessionObj.sessionsToken, "SamsungPay");
  var match$6 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var isClickToPayRememberMe = match$6[0];
  var intent = _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_21__.usePaymentIntent(loggerState, "Card");
  var savedCardlength = savedMethods.length;
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_17__.paymentMethodListValue);
  var customerId = paymentToken.customerId;
  var paymentTokenVal = paymentToken.paymentToken;
  var bottomElement = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    "aria-label": "Saved payment methods",
    className: "PickerItemContainer",
    role: "region",
    tabIndex: 0
  }, savedMethods.map(function (obj, i) {
    return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__.createElementWithKey(i.toString(), _SavedCardItem_bs_js__WEBPACK_IMPORTED_MODULE_20__.make, {
      setPaymentToken: setPaymentToken,
      isActive: paymentTokenVal === obj.paymentToken,
      paymentItem: obj,
      brandIcon: _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.getPaymentMethodBrand(obj),
      index: i,
      savedCardlength: savedCardlength,
      cvcProps: cvcProps,
      setRequiredFieldsBody: setRequiredFieldsBody
    });
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.equal(clickToPayConfig.isReady, true),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ClickToPayAuthenticate_bs_js__WEBPACK_IMPORTED_MODULE_28__.make, {
      loggerState: loggerState,
      savedMethods: savedMethods,
      isClickToPayAuthenticateError: props.isClickToPayAuthenticateError,
      setIsClickToPayAuthenticateError: props.setIsClickToPayAuthenticateError,
      setPaymentToken: setPaymentToken,
      paymentTokenVal: paymentTokenVal,
      cvcProps: cvcProps,
      getVisaCards: props.getVisaCards,
      setIsClickToPayRememberMe: match$6[1],
      closeComponentIfSavedMethodsAreEmpty: props.closeComponentIfSavedMethodsAreEmpty
    })
  }));
  var setCvcError = cvcProps.setCvcError;
  var cvcNumber = cvcProps.cvcNumber;
  var isCVCValid = cvcProps.isCVCValid;
  var complete = isCVCValid !== undefined ? paymentTokenVal !== "" && isCVCValid : false;
  var empty = cvcNumber === "";
  var customerMethod = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(savedMethods.concat(customerMethods).filter(function (savedMethod) {
      return savedMethod.paymentToken === paymentTokenVal;
    })[0], _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_15__.defaultCustomerMethods);
  }, [paymentTokenVal]);
  var isUnknownPaymentMethod = customerMethod.paymentMethod === "";
  var isCardPaymentMethod = customerMethod.paymentMethod === "card";
  var isCardPaymentMethodValid = !customerMethod.requiresCvv || complete && !empty;
  var complete$1 = areRequiredFieldsValid && !isUnknownPaymentMethod && (!isCardPaymentMethod || isCardPaymentMethodValid);
  var paymentMethodType = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(customerMethod.paymentMethodType, customerMethod.paymentMethod);
  _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_19__.useHandlePostMessages(complete$1, empty, paymentMethodType, true);
  _Utilities_GooglePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_23__.useHandleGooglePayResponse([], intent, true, undefined, undefined);
  _Utilities_ApplePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_22__.useHandleApplePayResponse([], intent, undefined, undefined, undefined, true, undefined, undefined);
  _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_25__.useHandleSamsungPayResponse(intent, true, undefined);
  var submitCallback = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_13__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(json));
    var isCustomerAcceptanceRequired = !customerMethod.recurringEnabled || isSaveCardsChecked;
    var match = customerMethod.paymentMethod;
    var savedPaymentMethodBody;
    if (match === "card") {
      savedPaymentMethodBody = _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_14__.savedCardBody(paymentTokenVal, customerId, cvcNumber, customerMethod.requiresCvv, isCustomerAcceptanceRequired);
    } else {
      var paymentMethodType = customerMethod.paymentMethodType;
      var paymentMethodType$1 = paymentMethodType !== undefined && paymentMethodType !== "" ? paymentMethodType : null;
      savedPaymentMethodBody = _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_14__.savedPaymentMethodBody(paymentTokenVal, customerId, customerMethod.paymentMethod, paymentMethodType$1, isCustomerAcceptanceRequired);
    }
    if (!confirm.doSubmit) {
      return;
    }
    if (customerMethod.card.isClickToPayCard) {
      _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_4__.$$catch(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_24__.handleProceedToPay(customerMethod.paymentToken, undefined, undefined, undefined, undefined, undefined, undefined, undefined, loggerState, undefined, clickToPayProvider, isClickToPayRememberMe, clickToPayConfig.clickToPayToken, _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(clientSecret, ""), undefined).then(function (resp) {
        var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(resp.payload);
        switch (clickToPayProvider) {
          case "VISA":
            var clickToPayBody = _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_14__.visaClickToPayBody(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getString(dict, "checkoutResponse", ""), clickToPayConfig.email);
            intent(false, clickToPayBody, confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
            break;
          case "MASTERCARD":
            var headers = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromDict(dict, "headers");
            var merchantTransactionId = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getString(headers, "merchant-transaction-id", "");
            var xSrcFlowId = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getString(headers, "x-src-cx-flow-id", "");
            var correlationId = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getString(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromDict(dict, "checkoutResponseData"), "srcCorrelationId", "");
            var clickToPayBody$1 = _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_14__.mastercardClickToPayBody(merchantTransactionId, correlationId, xSrcFlowId);
            intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.mergeAndFlattenToTuples(clickToPayBody$1, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
            break;
          case "NONE":
            break;
        }
        return Promise.resolve(resp);
      }), function (param) {
        return Promise.resolve({
          status: "ERROR",
          payload: null
        });
      });
      return;
    }
    if (areRequiredFieldsValid && !isUnknownPaymentMethod && (!isCardPaymentMethod || isCardPaymentMethodValid) && confirm.confirmTimestamp >= confirm.readyTimestamp) {
      var match$1 = customerMethod.paymentMethodType;
      if (match$1 !== undefined) {
        switch (match$1) {
          case "apple_pay":
            if (applePayToken.TAG === "ApplePayTokenOptional") {
              return _Utilities_ApplePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_22__.handleApplePayButtonClicked(applePayToken._0, componentName, paymentMethodListValue);
            } else {
              return intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.mergeAndFlattenToTuples(savedPaymentMethodBody, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
            }
          case "google_pay":
            if (gPayToken.TAG === "OtherTokenOptional") {
              return _Utilities_GooglePayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_23__.handleGooglePayClicked(gPayToken._0, componentName, iframeId, readOnly);
            } else {
              return intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.mergeAndFlattenToTuples(savedPaymentMethodBody, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
            }
          case "samsung_pay":
            if (samsungPayToken.TAG === "SamsungPayTokenOptional") {
              return _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_25__.handleSamsungPayClicked(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.getDictFromJson(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(samsungPayToken._0, null)), componentName, iframeId, readOnly);
            } else {
              return intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.mergeAndFlattenToTuples(savedPaymentMethodBody, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
            }
          default:
        }
      }
      return intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.mergeAndFlattenToTuples(savedPaymentMethodBody, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
    }
    if (isUnknownPaymentMethod || confirm.confirmTimestamp < confirm.readyTimestamp) {
      setUserError(localeString.selectPaymentMethodText);
    }
    if (!isUnknownPaymentMethod && cvcNumber === "") {
      setCvcError(function (param) {
        return localeString.cvcNumberEmptyText;
      });
      setUserError(localeString.enterFieldsText);
    }
    if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(isCVCValid, false)) {
      setUserError(localeString.enterValidDetailsText);
    }
    if (!areRequiredFieldsValid) {
      return setUserError(localeString.enterValidDetailsText);
    }
  }, [areRequiredFieldsValid, requiredFieldsBody, empty, complete$1, customerMethod, applePayToken, gPayToken, isManualRetryEnabled]);
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_9__.useSubmitPaymentData(submitCallback);
  var conditionsForShowingSaveCardCheckbox = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    if (!isGuestCustomer && paymentMethodListValue.payment_type === "NEW_MANDATE" && displaySavedPaymentMethodsCheckbox) {
      return customerMethod.requiresCvv;
    } else {
      return false;
    }
  }, [isGuestCustomer, paymentMethodListValue.payment_type, displaySavedPaymentMethodsCheckbox, customerMethod]);
  var enableSavedPaymentShimmer = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    if (savedCardlength === 0 && !showPaymentMethodsScreen) {
      if (loadSavedCards === "LoadingSavedCards") {
        return true;
      } else {
        return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isNone(clickToPayConfig.isReady);
      }
    } else {
      return false;
    }
  }, [savedCardlength, loadSavedCards, showPaymentMethodsScreen, clickToPayConfig.isReady]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col overflow-auto h-auto no-scrollbar animate-slowShow"
  }, enableSavedPaymentShimmer ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_27__.SavedPaymentCardShimmer.make, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: !showPaymentMethodsScreen,
    children: bottomElement
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: conditionsForShowingSaveCardCheckbox,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "pt-4 pb-2 flex items-center justify-start"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_SaveDetailsCheckbox_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {
      isChecked: isSaveCardsChecked,
      setIsChecked: match$4[1]
    }))
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: displaySavedPaymentMethodsCheckbox && paymentMethodListValue.payment_type === "SETUP_MANDATE",
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Terms_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      mode: "Card",
      styles: {
        marginTop: themeObj.spacingGridColumn
      }
    })
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: !enableSavedPaymentShimmer,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-label": "Click to use new payment methods",
      className: "Label flex flex-row gap-3 items-end cursor-pointer mt-4",
      "data-testid": _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_12__.addNewCardIcon,
      role: "button",
      style: {
        color: themeObj.colorPrimary,
        float: "left",
        fontSize: "14px",
        fontWeight: "500",
        width: "fit-content"
      },
      tabIndex: 0,
      onKeyDown: function ($$event) {
        var key = $$event.key;
        var keyCode = $$event.keyCode;
        if (key === "Enter" || keyCode === 13) {
          return setShowPaymentMethodsScreen(function (param) {
            return true;
          });
        }
      },
      onClick: function (param) {
        setShowPaymentMethodsScreen(function (param) {
          return true;
        });
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
      name: "circle-plus",
      size: 22
    }), localeString.newPaymentMethods)
  }));
}
var make = SavedMethods;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/SessionPaymentWrapper.bs.js":
/*!****************************************************!*\
  !*** ./src/Components/SessionPaymentWrapper.bs.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./WalletShimmer.bs.js */ "./src/Components/WalletShimmer.bs.js");
/* harmony import */ var _PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PaymentShimmer.bs.js */ "./src/Components/PaymentShimmer.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE






function SessionPaymentWrapper(props) {
  var children = props.children;
  var sessions = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_2__.sessions);
  var loader;
  loader = props.type_ === "Wallet" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {});
  if (typeof sessions !== "object" && sessions === "Loading") {
    return loader;
  } else {
    return children;
  }
}
var make = SessionPaymentWrapper;

/* react Not a pure module */

/***/ }),

/***/ "./src/Components/Spinner.bs.js":
/*!**************************************!*\
  !*** ./src/Components/Spinner.bs.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE





function Spinner(props) {
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_3__.configAtom);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-8 h-8 animate-spin",
    style: {
      color: match.themeObj.colorTextSecondary
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_2__.make, {
    name: "loader",
    size: 32
  }));
}
var make = Spinner;

/* react Not a pure module */

/***/ }),

/***/ "./src/Hooks/ClickToPayHook.bs.js":
/*!****************************************!*\
  !*** ./src/Hooks/ClickToPayHook.bs.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   useClickToPay: () => (/* binding */ useClickToPay)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @rescript/core/src/Core__Promise.bs.js */ "./node_modules/@rescript/core/src/Core__Promise.bs.js");
/* harmony import */ var rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rescript/lib/es6/caml_js_exceptions.js */ "./node_modules/rescript/lib/es6/caml_js_exceptions.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Types/ClickToPayHelpers.bs.js */ "./src/Types/ClickToPayHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE












function useClickToPay(areClickToPayUIScriptsLoaded, setSessions, setAreClickToPayUIScriptsLoaded, savedMethods, loadSavedCards) {
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.clickToPayConfig);
  var setClickToPayConfig = match[1];
  var clickToPayConfig = match[0];
  var setShowPaymentMethodsScreen = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.showPaymentMethodsScreen);
  var clickToPayProvider = clickToPayConfig.clickToPayProvider;
  var isReady = clickToPayConfig.isReady;
  var setClickToPayProvider = function (provider) {
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.clickToPayProvider = provider;
      return newrecord;
    });
  };
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.loggerAtom);
  var sessionsObj = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.sessions);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.keys);
  var clientSecret = match$1.clientSecret;
  var closeComponentIfSavedMethodsAreEmpty = function () {
    if (savedMethods.length === 0 && loadSavedCards !== "LoadingSavedCards") {
      return setShowPaymentMethodsScreen(function (param) {
        return true;
      });
    }
  };
  var setClickToPayNotReady = function () {
    setClickToPayConfig(function (prev) {
      var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
      newrecord.isReady = false;
      return newrecord;
    });
  };
  var getVisaCards = async function (identityValue, otp, identityType) {
    var consumerIdentity_identityProvider = "SRC";
    var consumerIdentity_identityValue = identityType === "EMAIL_ADDRESS" ? identityValue : identityValue.replaceAll(" ", "");
    var consumerIdentity = {
      identityProvider: consumerIdentity_identityProvider,
      identityType: identityType,
      identityValue: consumerIdentity_identityValue
    };
    var getCardsConfig = otp.length === 6 ? {
      consumerIdentity: consumerIdentity,
      validationData: otp
    } : {
      consumerIdentity: consumerIdentity
    };
    try {
      var cardsResult = await _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getCardsVisaUnified(getCardsConfig);
      var match = cardsResult.actionCode;
      var exit = 0;
      switch (match) {
        case "SUCCESS":
          var profilesArray = cardsResult.profiles;
          var cards;
          if (profilesArray !== undefined) {
            loggerState.setLogInfo(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
              message: "Cards fetched successfully",
              scheme: clickToPayProvider
            }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
            var profile = profilesArray[0];
            cards = profile !== undefined ? profile.maskedCards : undefined;
          } else {
            cards = undefined;
          }
          setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.visaComponentState = "NONE";
            return newrecord;
          });
          return setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.clickToPayCards = cards;
            return newrecord;
          });
        case "PENDING_CONSUMER_IDV":
          return setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.maskedIdentity = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(cardsResult.maskedValidationChannel, "");
            newrecord.visaComponentState = "OTP_INPUT";
            return newrecord;
          });
        case "FAILED":
        case "ERROR":
          exit = 1;
          break;
        case "ADD_CARD":
          return setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.visaComponentState = "NONE";
            return newrecord;
          });
      }
      if (exit === 1) {
        if (otp !== "") {
          var err = cardsResult.error;
          if (err === undefined) {
            return setClickToPayConfig(function (prev) {
              var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
              newrecord.visaComponentState = "NONE";
              return newrecord;
            });
          }
          var reason = err.reason;
          if (reason === undefined) {
            return setClickToPayConfig(function (prev) {
              var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
              newrecord.visaComponentState = "NONE";
              return newrecord;
            });
          }
          switch (reason) {
            case "ACCT_INACCESSIBLE":
              loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
                message: "Maximum getCard call attempts reached (ACCT_INACCESSIBLE) - " + reason,
                scheme: clickToPayProvider
              }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
              return setClickToPayConfig(function (prev) {
                var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
                newrecord.otpError = "ACCT_INACCESSIBLE";
                return newrecord;
              });
            case "OTP_SEND_FAILED":
              loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
                message: "OTP SEND FAILED",
                scheme: clickToPayProvider
              }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
              return setClickToPayConfig(function (prev) {
                var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
                newrecord.otpError = "NONE";
                return newrecord;
              });
            case "VALIDATION_DATA_INVALID":
              return setClickToPayConfig(function (prev) {
                var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
                newrecord.otpError = "VALIDATION_DATA_INVALID";
                return newrecord;
              });
            default:
              setClickToPayConfig(function (prev) {
                var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
                newrecord.otpError = "NONE";
                return newrecord;
              });
              return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
                message: "get cards call failed - " + reason,
                scheme: clickToPayProvider
              }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
          }
        } else {
          setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.visaComponentState = "NONE";
            return newrecord;
          });
          return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
            message: "initial get cards call failed",
            scheme: clickToPayProvider
          }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
        }
      }
    } catch (raw_err) {
      var err$1 = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_6__.internalToOCamlException(raw_err);
      setClickToPayNotReady();
      return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
        message: "get cards call failed - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.formatException(err$1)),
        scheme: clickToPayProvider
      }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
    }
  };
  var initVisaUnified = async function (email) {
    try {
      var token = clickToPayConfig.clickToPayToken;
      if (token === undefined) {
        return;
      }
      var initConfig = _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getVisaInitConfig(token, clientSecret);
      setClickToPayConfig(function (prev) {
        var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
        newrecord.visaComponentState = "CARDS_LOADING";
        return newrecord;
      });
      await window.VSDK.initialize(initConfig);
      await getVisaCards(email, "", "EMAIL_ADDRESS");
      return;
    } catch (raw_err) {
      var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_6__.internalToOCamlException(raw_err);
      setClickToPayNotReady();
      closeComponentIfSavedMethodsAreEmpty();
      return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
        message: "SDK initialization failed - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.formatException(err)),
        scheme: clickToPayProvider
      }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
    }
  };
  var getClickToPayToken = function (ssn) {
    var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDictFromJson(ssn);
    var clickToPaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_9__.itemToObjMapper(dict, "ClickToPayObject");
    var match = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_9__.getPaymentSessionObj(clickToPaySessionObj.sessionsToken, "ClickToPay");
    if (match.TAG === "ClickToPayTokenOptional") {
      var token = match._0;
      if (token !== undefined) {
        setClickToPayConfig(function (prev) {
          var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
          newrecord.clickToPayToken = _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.clickToPayTokenItemToObjMapper(token);
          return newrecord;
        });
        return _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.clickToPayTokenItemToObjMapper(token);
      } else {
        setClickToPayNotReady();
        return;
      }
    }
    setClickToPayNotReady();
  };
  var loadVisaScript = async function (ctpToken) {
    try {
      _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.loadClickToPayUIScripts(loggerState, function () {
        setAreClickToPayUIScriptsLoaded(function (param) {
          return true;
        });
      }, setClickToPayNotReady);
      if (ctpToken !== undefined) {
        return _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.loadVisaScript(ctpToken, function () {
          if (ctpToken !== undefined) {
            return setClickToPayConfig(function (prev) {
              var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
              newrecord.dpaName = ctpToken.dpaName;
              newrecord.email = ctpToken.email;
              newrecord.availableCardBrands = ctpToken.cardBrands;
              newrecord.isReady = true;
              return newrecord;
            });
          } else {
            return setClickToPayNotReady();
          }
        }, function () {
          setClickToPayNotReady();
          loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
            message: "CTP UI script loading failed",
            scheme: clickToPayProvider
          }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
        });
      } else {
        return setClickToPayNotReady();
      }
    } catch (raw_err) {
      var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_6__.internalToOCamlException(raw_err);
      setClickToPayNotReady();
      return loggerState.setLogError(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(JSON.stringify({
        message: "CTP UI script loading failed - " + JSON.stringify(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.formatException(err)),
        scheme: clickToPayProvider
      }), ""), "CLICK_TO_PAY_FLOW", undefined, undefined, undefined, undefined, undefined);
    }
  };
  var loadMastercardClickToPayScript = function (ctpToken) {
    if (ctpToken !== undefined) {
      _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_5__.$$catch(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.loadClickToPayScripts(loggerState).then(function () {
        setAreClickToPayUIScriptsLoaded(function (param) {
          return true;
        });
        return Promise.resolve();
      }), function (param) {
        loggerState.setLogError("ClickToPay UI Kit CSS Load Error", "CLICK_TO_PAY_SCRIPT", undefined, undefined, undefined, undefined, undefined);
        return Promise.resolve();
      });
      _rescript_core_src_Core_Promise_bs_js__WEBPACK_IMPORTED_MODULE_5__.$$catch(_Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.loadMastercardScript(ctpToken, loggerState).then(function (resp) {
        var availableCardBrands = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getArray(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDictFromJson(resp), "availableCardBrands").map(function (item) {
          return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__.Decode.string(item), "");
        }).filter(function (item) {
          return item !== "";
        });
        setClickToPayConfig(function (prev) {
          var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
          newrecord.dpaName = ctpToken.dpaName;
          newrecord.email = ctpToken.email;
          newrecord.availableCardBrands = availableCardBrands;
          newrecord.isReady = true;
          return newrecord;
        });
        return Promise.resolve();
      }), function (param) {
        setClickToPayNotReady();
        return Promise.resolve();
      });
      return;
    } else {
      return setClickToPayNotReady();
    }
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.equal(isReady, true) && clickToPayProvider === "VISA" && areClickToPayUIScriptsLoaded && _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(clickToPayConfig.clickToPayToken)) {
      initVisaUnified(clickToPayConfig.email);
    }
  }, [isReady, areClickToPayUIScriptsLoaded, clickToPayProvider, clickToPayConfig.clickToPayToken]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (clickToPayConfig.email !== "" && clickToPayConfig.consumerIdentity.identityValue === "") {
      setClickToPayConfig(function (prev) {
        var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
        newrecord.consumerIdentity = {
          identityType: "EMAIL_ADDRESS",
          identityValue: clickToPayConfig.email
        };
        return newrecord;
      });
    }
  }, [clickToPayConfig.email]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.equal(isReady, true) && clickToPayProvider === "MASTERCARD") {
      (async function () {
        try {
          var cardsResult = await _Types_ClickToPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getCards(loggerState);
          if (cardsResult.TAG !== "Ok") {
            return;
          }
          var cards = cardsResult._0;
          return setClickToPayConfig(function (prev) {
            var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
            newrecord.clickToPayCards = cards;
            return newrecord;
          });
        } catch (exn) {
          return;
        }
      })();
    }
  }, [isReady, clickToPayProvider]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (typeof sessionsObj === "object" && sessionsObj.TAG === "Loaded") {
      var ssn = sessionsObj._0;
      setSessions(function (param) {
        return ssn;
      });
      var ctpToken = getClickToPayToken(ssn);
      _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.forEach(ctpToken, function (token) {
        var match = token.provider.toLowerCase();
        switch (match) {
          case "mastercard":
            loadMastercardClickToPayScript(ctpToken);
            return setClickToPayProvider("MASTERCARD");
          case "visa":
            loadVisaScript(ctpToken);
            return setClickToPayProvider("VISA");
          default:
            setClickToPayNotReady();
            return setClickToPayProvider("NONE");
        }
      });
    }
  }, [sessionsObj]);
  return [getVisaCards, closeComponentIfSavedMethodsAreEmpty];
}

/* react Not a pure module */

/***/ }),

/***/ "./src/PaymentElement.bs.js":
/*!**********************************!*\
  !*** ./src/PaymentElement.bs.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cardsToRender: () => (/* binding */ cardsToRender),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_belt_Array_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/belt_Array.js */ "./node_modules/rescript/lib/es6/belt_Array.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Components_Or_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Components/Or.bs.js */ "./src/Components/Or.bs.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Payments/GPayLazy.bs.js */ "./src/Payments/GPayLazy.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Components_PoweredBy_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Components/PoweredBy.bs.js */ "./src/Components/PoweredBy.bs.js");
/* harmony import */ var _Payments_BoletoLazy_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Payments/BoletoLazy.bs.js */ "./src/Payments/BoletoLazy.bs.js");
/* harmony import */ var _Utilities_ErrorUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Utilities/ErrorUtils.bs.js */ "./src/Utilities/ErrorUtils.bs.js");
/* harmony import */ var _Payments_PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Payments/PayPalLazy.bs.js */ "./src/Payments/PayPalLazy.bs.js");
/* harmony import */ var _Payments_CardPayment_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Payments/CardPayment.bs.js */ "./src/Payments/CardPayment.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./Types/PaymentType.bs.js */ "./src/Types/PaymentType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Payments_ApplePayLazy_bs_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./Payments/ApplePayLazy.bs.js */ "./src/Payments/ApplePayLazy.bs.js");
/* harmony import */ var _Components_PayNowButton_bs_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./Components/PayNowButton.bs.js */ "./src/Components/PayNowButton.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Components_SavedMethods_bs_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./Components/SavedMethods.bs.js */ "./src/Components/SavedMethods.bs.js");
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./hyper-log-catcher/ErrorBoundary.bs.js */ "./src/hyper-log-catcher/ErrorBoundary.bs.js");
/* harmony import */ var _Payments_PayPalHelpers_bs_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./Payments/PayPalHelpers.bs.js */ "./src/Payments/PayPalHelpers.bs.js");
/* harmony import */ var _Hooks_ClickToPayHook_bs_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./Hooks/ClickToPayHook.bs.js */ "./src/Hooks/ClickToPayHook.bs.js");
/* harmony import */ var _PaymentOptions_bs_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./PaymentOptions.bs.js */ "./src/PaymentOptions.bs.js");
/* harmony import */ var _Components_PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./Components/PaymentShimmer.bs.js */ "./src/Components/PaymentShimmer.bs.js");
/* harmony import */ var _Types_PaymentModeType_bs_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./Types/PaymentModeType.bs.js */ "./src/Types/PaymentModeType.bs.js");
/* harmony import */ var _Payments_ACHBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./Payments/ACHBankDebitLazy.bs.js */ "./src/Payments/ACHBankDebitLazy.bs.js");
/* harmony import */ var _Payments_BacsBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./Payments/BacsBankDebitLazy.bs.js */ "./src/Payments/BacsBankDebitLazy.bs.js");
/* harmony import */ var _Payments_BecsBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(/*! ./Payments/BecsBankDebitLazy.bs.js */ "./src/Payments/BecsBankDebitLazy.bs.js");
/* harmony import */ var _Payments_SepaBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(/*! ./Payments/SepaBankDebitLazy.bs.js */ "./src/Payments/SepaBankDebitLazy.bs.js");
/* harmony import */ var _Components_AccordionContainer_bs_js__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(/*! ./Components/AccordionContainer.bs.js */ "./src/Components/AccordionContainer.bs.js");
/* harmony import */ var _Payments_ACHBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(/*! ./Payments/ACHBankTransferLazy.bs.js */ "./src/Payments/ACHBankTransferLazy.bs.js");
/* harmony import */ var _Payments_BacsBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(/*! ./Payments/BacsBankTransferLazy.bs.js */ "./src/Payments/BacsBankTransferLazy.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(/*! ./Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
/* harmony import */ var _Payments_SepaBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(/*! ./Payments/SepaBankTransferLazy.bs.js */ "./src/Payments/SepaBankTransferLazy.bs.js");
/* harmony import */ var _Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(/*! ./Components/PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
/* harmony import */ var _hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(/*! ./hyper-log-catcher/ReusableReactSuspense.bs.js */ "./src/hyper-log-catcher/ReusableReactSuspense.bs.js");
/* harmony import */ var _Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(/*! ./Components/SessionPaymentWrapper.bs.js */ "./src/Components/SessionPaymentWrapper.bs.js");
/* harmony import */ var _Payments_InstantBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(/*! ./Payments/InstantBankTransferLazy.bs.js */ "./src/Payments/InstantBankTransferLazy.bs.js");
/* harmony import */ var _Payments_PaymentMethodsWrapperLazy_bs_js__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(/*! ./Payments/PaymentMethodsWrapperLazy.bs.js */ "./src/Payments/PaymentMethodsWrapperLazy.bs.js");
/* harmony import */ var _Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(/*! ./Payments/PaymentRequestButtonElement.bs.js */ "./src/Payments/PaymentRequestButtonElement.bs.js");
/* harmony import */ var _Payments_InstantBankTransferPolandLazy_bs_js__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(/*! ./Payments/InstantBankTransferPolandLazy.bs.js */ "./src/Payments/InstantBankTransferPolandLazy.bs.js");
/* harmony import */ var _Payments_InstantBankTransferFinlandLazy_bs_js__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(/*! ./Payments/InstantBankTransferFinlandLazy.bs.js */ "./src/Payments/InstantBankTransferFinlandLazy.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE
















































function cardsToRender(width) {
  return (width - 40 | 0) / 130 | 0;
}
function PaymentElement(props) {
  var cvcProps = props.cvcProps;
  var expiryProps = props.expiryProps;
  var cardProps = props.cardProps;
  var divRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.optionAtom);
  var displaySavedPaymentMethods = match.displaySavedPaymentMethods;
  var paymentMethodOrder = match.paymentMethodOrder;
  var customerPaymentMethods = match.customerPaymentMethods;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.configAtom);
  var themeObj = match$1.themeObj;
  var optionAtomValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.optionAtom);
  var paymentMethodList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.paymentMethodList);
  var isApplePayReady = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.isApplePayReady);
  var isGPayReady = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.isGooglePayReady);
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.loggerAtom);
  var isShowOrPayUsing = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.isShowOrPayUsing);
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.keys);
  var clickToPayConfig = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.clickToPayConfig);
  var match$3 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.selectedOptionAtom);
  var setSelectedOption = match$3[1];
  var selectedOption = match$3[0];
  var match$4 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.showPaymentMethodsScreen);
  var setShowPaymentMethodsScreen = match$4[1];
  var showPaymentMethodsScreen = match$4[0];
  var match$5 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_18__.paymentTokenAtom);
  var setPaymentToken = match$5[1];
  var match$6 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_21__.paymentMethodListValue);
  var setPaymentMethodListValue = match$6[1];
  var paymentMethodListValue = match$6[0];
  var match$7 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var sessions = match$7[0];
  var match$8 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setPaymentOptions = match$8[1];
  var paymentOptions = match$8[0];
  var match$9 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setWalletOptions = match$9[1];
  var walletOptions = match$9[0];
  var match$10 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return 0;
  });
  var cardsContainerWidth = match$10[0];
  var match$11 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setDropDownOptions = match$11[1];
  var dropDownOptions = match$11[0];
  var match$12 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setCardOptions = match$12[1];
  var cardOptions = match$12[0];
  var match$13 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setSavedMethods = match$13[1];
  var savedMethods = match$13[0];
  var match$14 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "LoadingSavedCards";
  });
  var setLoadSavedCards = match$14[1];
  var loadSavedCards = match$14[0];
  var match$15 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var isClickToPayAuthenticateError = match$15[0];
  var match$16 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var areClickToPayUIScriptsLoaded = match$16[0];
  var isShowPaymentMethodsDependingOnClickToPay = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(clickToPayConfig.clickToPayCards, []).length > 0 || _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(clickToPayConfig.isReady, false) && _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isNone(clickToPayConfig.clickToPayCards) || clickToPayConfig.email !== "") {
      return !isClickToPayAuthenticateError;
    } else {
      return false;
    }
  }, [clickToPayConfig, isClickToPayAuthenticateError]);
  var layoutClass = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.getLayoutClass(match.layout);
  var match$17 = _Hooks_ClickToPayHook_bs_js__WEBPACK_IMPORTED_MODULE_26__.useClickToPay(areClickToPayUIScriptsLoaded, match$7[1], match$16[1], savedMethods, loadSavedCards);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (displaySavedPaymentMethods) {
      if (typeof customerPaymentMethods === "object") {
        if (customerPaymentMethods.TAG === "LoadedSavedCards") {
          var isGuestCustomer = customerPaymentMethods._1;
          var displayDefaultSavedPaymentIcon = optionAtomValue.displayDefaultSavedPaymentIcon;
          var sortSavedPaymentMethods = function (a, b) {
            var defaultCompareVal = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.compareLogic(new Date(a.lastUsedAt), new Date(b.lastUsedAt));
            if (displayDefaultSavedPaymentIcon) {
              if (a.defaultPaymentMethodSet) {
                return -1;
              } else if (b.defaultPaymentMethodSet) {
                return 1;
              } else {
                return defaultCompareVal;
              }
            } else {
              return defaultCompareVal;
            }
          };
          var finalSavedPaymentMethods = customerPaymentMethods._0.slice().filter(function (savedMethod) {
            var match = savedMethod.paymentMethodType;
            if (match === undefined) {
              return true;
            }
            switch (match) {
              case "apple_pay":
                return isApplePayReady;
              case "google_pay":
                return isGPayReady;
              default:
                return true;
            }
          });
          finalSavedPaymentMethods.sort(sortSavedPaymentMethods);
          var paymentOrder = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.removeDuplicate(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getOptionalArr(paymentMethodOrder));
          var sortSavedMethodsBasedOnPriority = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_21__.sortCustomerMethodsBasedOnPriority(finalSavedPaymentMethods, paymentOrder, displayDefaultSavedPaymentIcon);
          setSavedMethods(function (param) {
            return sortSavedMethodsBasedOnPriority;
          });
          setLoadSavedCards(function (param) {
            if (finalSavedPaymentMethods.length === 0) {
              return {
                TAG: "NoResult",
                _0: isGuestCustomer
              };
            } else {
              return {
                TAG: "LoadedSavedCards",
                _0: finalSavedPaymentMethods,
                _1: isGuestCustomer
              };
            }
          });
          setShowPaymentMethodsScreen(function (param) {
            if (finalSavedPaymentMethods.length === 0) {
              return !isShowPaymentMethodsDependingOnClickToPay;
            } else {
              return false;
            }
          });
        } else {
          var isGuestCustomer$1 = customerPaymentMethods._0;
          setLoadSavedCards(function (param) {
            return {
              TAG: "NoResult",
              _0: isGuestCustomer$1
            };
          });
          setShowPaymentMethodsScreen(function (param) {
            return !isShowPaymentMethodsDependingOnClickToPay;
          });
        }
      }
    } else {
      setShowPaymentMethodsScreen(function (param) {
        return !isShowPaymentMethodsDependingOnClickToPay;
      });
      setLoadSavedCards(function (param) {
        return {
          TAG: "LoadedSavedCards",
          _0: [],
          _1: true
        };
      });
    }
  }, [customerPaymentMethods, displaySavedPaymentMethods, optionAtomValue, isApplePayReady, isGPayReady, clickToPayConfig.isReady, isShowPaymentMethodsDependingOnClickToPay]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var defaultSelectedPaymentMethod = optionAtomValue.displayDefaultSavedPaymentIcon ? savedMethods.find(function (savedMethod) {
      return savedMethod.defaultPaymentMethodSet;
    }) : savedMethods[0];
    var isSavedMethodsEmpty = savedMethods.length === 0;
    var tokenObj = isSavedMethodsEmpty ? undefined : defaultSelectedPaymentMethod !== undefined ? defaultSelectedPaymentMethod : _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(savedMethods[0], _Types_PaymentType_bs_js__WEBPACK_IMPORTED_MODULE_17__.defaultCustomerMethods);
    if (tokenObj !== undefined) {
      setPaymentToken(function (param) {
        return {
          paymentToken: tokenObj.paymentToken,
          customerId: tokenObj.customerId
        };
      });
    }
  }, [savedMethods]);
  var match$18 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_21__.useGetPaymentMethodList(paymentOptions, props.paymentType, sessions);
  var actualList = match$18[2];
  var paymentOptionsList = match$18[1];
  var walletList = match$18[0];
  var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDictFromJson(sessions);
  var sessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.itemToObjMapper(dict, "Others");
  var applePaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.itemToObjMapper(dict, "ApplePayObject");
  var applePayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.getPaymentSessionObj(applePaySessionObj.sessionsToken, "ApplePay");
  var gPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.getPaymentSessionObj(sessionObj.sessionsToken, "Gpay");
  var googlePayThirdPartySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.itemToObjMapper(dict, "GooglePayThirdPartyObject");
  var googlePayThirdPartyToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_23__.getPaymentSessionObj(googlePayThirdPartySessionObj.sessionsToken, "Gpay");
  var match$19 = _Payments_PayPalHelpers_bs_js__WEBPACK_IMPORTED_MODULE_25__.usePaymentMethodData(paymentMethodListValue, sessionObj);
  var isPaypalRedirectFlow = match$19.isPaypalRedirectFlow;
  var paypalToken = match$19.paypalToken;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var exit = 0;
    if (typeof paymentMethodList !== "object") {
      if (paymentMethodList !== "Loading") {
        exit = 1;
      }
    } else if (paymentMethodList.TAG === "Loaded") {
      var plist = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_37__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDictFromJson(paymentMethodList._0));
      setPaymentOptions(function (param) {
        return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.removeDuplicate(rescript_lib_es6_belt_Array_js__WEBPACK_IMPORTED_MODULE_2__.concatMany([_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.checkPriorityList(paymentMethodOrder) ? ["card"] : [], paymentOptionsList]));
      });
      setWalletOptions(function (param) {
        return walletList;
      });
      setPaymentMethodListValue(function (param) {
        return plist;
      });
      if (!actualList.includes(selectedOption) && selectedOption !== "") {
        _Utilities_ErrorUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.manageErrorWarning("SDK_CONNECTOR_WARNING", "Please enable Card Payment in the dashboard, or 'ShowCard.FormByDefault' to false.", loggerState);
      } else if (!_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.checkPriorityList(paymentMethodOrder)) {
        _Utilities_ErrorUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.manageErrorWarning("SDK_CONNECTOR_WARNING", "'paymentMethodOrder' is " + _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getOptionalArr(paymentMethodOrder).join(", ") + " . Please enable Card Payment as 1st priority to show it as default.", loggerState);
      }
    } else {
      exit = 1;
    }
    if (exit === 1) {
      setPaymentOptions(function (param) {
        if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.checkPriorityList(paymentMethodOrder)) {
          return ["card"];
        } else {
          return [];
        }
      });
    }
  }, [paymentMethodList, walletList, paymentOptionsList, actualList]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (layoutClass.type === "Tabs") {
      var isCard = cardOptions.includes(selectedOption);
      if (!isCard) {
        var match = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.swapCardOption(cardOptions, dropDownOptions, selectedOption);
        var dropdownArr = match[1];
        var cardArr = match[0];
        setCardOptions(function (param) {
          return cardArr;
        });
        setDropDownOptions(function (param) {
          return dropdownArr;
        });
      }
    }
    if (selectedOption !== "") {
      loggerState.setLogInfo("", "PAYMENT_METHOD_CHANGED", undefined, undefined, undefined, undefined, selectedOption.toUpperCase());
    }
  }, [selectedOption, cardOptions, dropDownOptions]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var cardsCount = cardsToRender(cardsContainerWidth);
    var cardOpts = paymentOptions.slice(0, cardsCount);
    var dropOpts = paymentOptions.slice(cardsCount);
    var isCard = cardOpts.includes(selectedOption);
    if (!isCard && selectedOption !== "" && paymentOptions.includes(selectedOption)) {
      var match = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.swapCardOption(cardOpts, dropOpts, selectedOption);
      var dropdownArr = match[1];
      var cardArr = match[0];
      setCardOptions(function (param) {
        return cardArr;
      });
      setDropDownOptions(function (param) {
        return dropdownArr;
      });
    } else {
      setCardOptions(function (param) {
        return cardOpts;
      });
      setDropDownOptions(function (param) {
        return dropOpts;
      });
    }
  }, [cardsContainerWidth, paymentOptions]);
  var cardShimmerCount = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return cardsToRender(cardsContainerWidth);
  }, [cardsContainerWidth]);
  var submitCallback = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_16__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getDictFromJson(json));
    if (confirm.doSubmit && selectedOption === "") {
      return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.postFailedSubmitResponse("validation_error", "Select a payment method");
    }
  }, [selectedOption]);
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.useSubmitPaymentData(submitCallback);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    setSelectedOption(function (prev) {
      if (selectedOption !== "") {
        return prev;
      } else if (layoutClass.defaultCollapsed) {
        return "";
      } else if (typeof paymentMethodList !== "object") {
        if (paymentMethodList === "Loading") {
          return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentOptions[0], "");
        } else if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.checkPriorityList(paymentMethodOrder)) {
          return "card";
        } else {
          return "";
        }
      } else if (paymentMethodList.TAG === "Loaded") {
        if (paymentOptions.includes(selectedOption)) {
          return selectedOption;
        } else {
          return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentOptions[0], "");
        }
      } else if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.checkPriorityList(paymentMethodOrder)) {
        return "card";
      } else {
        return "";
      }
    });
  }, [layoutClass.defaultCollapsed, paymentOptions, paymentMethodList, selectedOption]);
  var loader = function () {
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.handlePostMessageEvents(false, false, selectedOption, loggerState, undefined);
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_28__.make, {});
  };
  var match$20 = _Types_PaymentModeType_bs_js__WEBPACK_IMPORTED_MODULE_29__.paymentMode(selectedOption);
  var tmp;
  switch (match$20) {
    case "Card":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_CardPayment_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
        cardProps: cardProps,
        expiryProps: expiryProps,
        cvcProps: cvcProps
      });
      break;
    case "ACHTransfer":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_ACHBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_35__.make, {}),
        loaderComponent: loader(),
        componentName: "ACHBankTransferLazy"
      });
      break;
    case "SepaTransfer":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_SepaBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_38__.make, {}),
        loaderComponent: loader(),
        componentName: "SepaBankTransferLazy"
      });
      break;
    case "InstantTransfer":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_InstantBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_42__.make, {}),
        loaderComponent: loader(),
        componentName: "InstantBankTransferLazy"
      });
      break;
    case "InstantTransferFinland":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_InstantBankTransferFinlandLazy_bs_js__WEBPACK_IMPORTED_MODULE_46__.make, {}),
        loaderComponent: loader(),
        componentName: "InstantBankTransferFinlandLazy"
      });
      break;
    case "InstantTransferPoland":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_InstantBankTransferPolandLazy_bs_js__WEBPACK_IMPORTED_MODULE_45__.make, {}),
        loaderComponent: loader(),
        componentName: "InstantBankTransferPolandLazy"
      });
      break;
    case "BacsTransfer":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_BacsBankTransferLazy_bs_js__WEBPACK_IMPORTED_MODULE_36__.make, {}),
        loaderComponent: loader(),
        componentName: "BacsBankTransferLazy"
      });
      break;
    case "ACHBankDebit":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_ACHBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_30__.make, {}),
        loaderComponent: loader(),
        componentName: "ACHBankDebitLazy"
      });
      break;
    case "SepaBankDebit":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_SepaBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_33__.make, {}),
        loaderComponent: loader(),
        componentName: "SepaBankDebitLazy"
      });
      break;
    case "BacsBankDebit":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_BacsBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_31__.make, {}),
        loaderComponent: loader(),
        componentName: "BacsBankDebitLazy"
      });
      break;
    case "BecsBankDebit":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_BecsBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_32__.make, {}),
        loaderComponent: loader(),
        componentName: "BecsBankDebitLazy"
      });
      break;
    case "BanContactCard":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_CardPayment_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
        cardProps: cardProps,
        expiryProps: expiryProps,
        cvcProps: cvcProps,
        isBancontact: true
      });
      break;
    case "GooglePay":
      var tmp$1;
      if (gPayToken.TAG === "OtherTokenOptional") {
        var optToken = gPayToken._0;
        var tmp$2;
        tmp$2 = googlePayThirdPartyToken.TAG === "GooglePayThirdPartyTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
          sessionObj: optToken,
          thirdPartySessionObj: googlePayThirdPartyToken._0,
          walletOptions: walletOptions
        }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
          sessionObj: optToken,
          thirdPartySessionObj: undefined,
          walletOptions: walletOptions
        });
        tmp$1 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
          children: tmp$2,
          loaderComponent: loader(),
          componentName: "GPayLazy"
        });
      } else {
        tmp$1 = null;
      }
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_41__.make, {
        children: tmp$1,
        type_: "Wallet"
      });
      break;
    case "ApplePay":
      tmp = applePayToken.TAG === "ApplePayTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_ApplePayLazy_bs_js__WEBPACK_IMPORTED_MODULE_19__.make, {
          sessionObj: applePayToken._0,
          walletOptions: walletOptions
        }),
        loaderComponent: loader(),
        componentName: "ApplePayLazy"
      }) : null;
      break;
    case "Boleto":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_BoletoLazy_bs_js__WEBPACK_IMPORTED_MODULE_12__.make, {}),
        loaderComponent: loader(),
        componentName: "BoletoLazy"
      });
      break;
    case "PayPal":
      var tmp$3;
      if (paypalToken.TAG === "OtherTokenOptional") {
        var exit = 0;
        if (paypalToken._0 !== undefined && match$19.isPaypalSDKFlow) {
          loggerState.setLogInfo("PayPal Invoke SDK Flow in Tabs", "PAYPAL_SDK_FLOW", undefined, undefined, undefined, undefined, undefined);
          tmp$3 = null;
        } else {
          exit = 1;
        }
        if (exit === 1) {
          tmp$3 = isPaypalRedirectFlow ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_14__.make, {
            walletOptions: walletOptions
          }) : null;
        }
      } else {
        tmp$3 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
          condition: isPaypalRedirectFlow,
          children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_14__.make, {
            walletOptions: walletOptions
          })
        });
      }
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_41__.make, {
        children: tmp$3,
        type_: "Wallet"
      });
      break;
    default:
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_40__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PaymentMethodsWrapperLazy_bs_js__WEBPACK_IMPORTED_MODULE_43__.make, {
          paymentMethodName: selectedOption
        }),
        loaderComponent: loader(),
        componentName: "PaymentMethodsWrapperLazy"
      });
  }
  var checkoutEle = rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__.createElementWithKey(selectedOption, _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_24__.make, {
    children: tmp,
    componentName: "PaymentElement",
    publishableKey: match$2.publishableKey
  });
  var paymentLabel = displaySavedPaymentMethods && !showPaymentMethodsScreen ? optionAtomValue.savedPaymentMethodsHeaderText : optionAtomValue.paymentMethodsHeaderText;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var evalMethodsList = function () {
      if (typeof paymentMethodList !== "object" && paymentMethodList === "Loading") {
        return;
      }
      _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.messageParentWindow(undefined, [["ready", true]]);
    };
    if (displaySavedPaymentMethods) {
      if (typeof customerPaymentMethods === "object") {
        if (customerPaymentMethods.TAG === "LoadedSavedCards" && customerPaymentMethods._0.length > 0) {
          _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_7__.messageParentWindow(undefined, [["ready", true]]);
        } else {
          evalMethodsList();
        }
      }
    } else {
      evalMethodsList();
    }
  }, [paymentMethodList, customerPaymentMethods]);
  var match$21 = layoutClass.type;
  var tmp$4;
  tmp$4 = match$21 === "Accordion" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_AccordionContainer_bs_js__WEBPACK_IMPORTED_MODULE_34__.make, {
    paymentOptions: paymentOptions,
    checkoutEle: checkoutEle,
    cardProps: cardProps,
    expiryProps: expiryProps
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentOptions_bs_js__WEBPACK_IMPORTED_MODULE_27__.make, {
    setCardsContainerWidth: match$10[1],
    cardOptions: cardOptions,
    dropDownOptions: dropDownOptions,
    checkoutEle: checkoutEle,
    cardShimmerCount: cardShimmerCount,
    cardProps: cardProps,
    expiryProps: expiryProps
  });
  var tmp$5;
  var exit$1 = 0;
  if (typeof paymentMethodList !== "object" || paymentMethodList.TAG !== "LoadError") {
    exit$1 = 1;
  } else {
    tmp$5 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
      condition: paymentMethodListValue.payment_methods.length === 0,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_24__.ErrorTextAndImage.make, {
        divRef: divRef,
        level: "Top"
      })
    });
  }
  if (exit$1 === 1) {
    tmp$5 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
      condition: !displaySavedPaymentMethods && paymentOptions.length === 0 && walletOptions.length === 0,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_39__.make, {})
    });
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isSome(paymentLabel),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-level": 1,
      className: "PaymentLabel text-2xl font-semibold text-[#151619] mb-6",
      role: "heading"
    }, _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentLabel, ""))
  }), _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isNone(clickToPayConfig.isReady) ? areClickToPayUIScriptsLoaded ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(function (prim) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("src-loader", prim);
  }, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_39__.SavedPaymentCardShimmer.make, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: !showPaymentMethodsScreen && (displaySavedPaymentMethods || isShowPaymentMethodsDependingOnClickToPay),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SavedMethods_bs_js__WEBPACK_IMPORTED_MODULE_22__.make, {
      paymentToken: match$5[0],
      setPaymentToken: setPaymentToken,
      savedMethods: savedMethods,
      loadSavedCards: loadSavedCards,
      cvcProps: cvcProps,
      sessions: sessions,
      isClickToPayAuthenticateError: isClickToPayAuthenticateError,
      setIsClickToPayAuthenticateError: match$15[1],
      getVisaCards: match$17[0],
      closeComponentIfSavedMethodsAreEmpty: match$17[1]
    })
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: (paymentOptions.length > 0 || walletOptions.length > 0) && showPaymentMethodsScreen && _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isSome(clickToPayConfig.isReady),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-label": "Payment Section",
      className: "flex flex-col place-items-center",
      role: "region",
      tabIndex: 0
    }, rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__.createElementWithKey("payment_request_buttons_all", _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_24__.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_44__.make, {
        sessions: sessions,
        walletOptions: walletOptions
      }),
      level: "RequestButton",
      componentName: "PaymentRequestButtonElement"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
      condition: paymentOptions.length > 0 && walletOptions.length > 0 && _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_21__.checkRenderOrComp(walletOptions, isShowOrPayUsing),
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_Or_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {})
    }), tmp$4)
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: (displaySavedPaymentMethods && savedMethods.length > 0 || isShowPaymentMethodsDependingOnClickToPay) && showPaymentMethodsScreen,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-label": "Click to use existing payment methods",
      className: "Label flex flex-row gap-3 items-end cursor-pointer mt-4",
      role: "button",
      style: {
        color: themeObj.colorPrimary,
        float: "left",
        fontSize: "14px",
        fontWeight: themeObj.fontWeightNormal,
        width: "fit-content"
      },
      tabIndex: 0,
      onKeyDown: function ($$event) {
        var key = $$event.key;
        var keyCode = $$event.keyCode;
        if (key === "Enter" || keyCode === 13) {
          return setShowPaymentMethodsScreen(function (param) {
            return false;
          });
        }
      },
      onClick: function (param) {
        setShowPaymentMethodsScreen(function (param) {
          return false;
        });
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
      name: "circle_dots",
      size: 20,
      width: 19
    }), match$1.localeString.useExistingPaymentMethods)
  }), tmp$5, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
    condition: match.sdkHandleConfirmPayment.handleConfirm,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "mt-4"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PayNowButton_bs_js__WEBPACK_IMPORTED_MODULE_20__.make, {}))
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PoweredBy_bs_js__WEBPACK_IMPORTED_MODULE_11__.make, {}));
}
var make = PaymentElement;

/* react Not a pure module */

/***/ }),

/***/ "./src/PaymentElementRenderer.bs.js":
/*!******************************************!*\
  !*** ./src/PaymentElementRenderer.bs.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ $$default)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./GlobalVars.bs.js */ "./src/GlobalVars.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _WalletElement_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./WalletElement.bs.js */ "./src/WalletElement.bs.js");
/* harmony import */ var _Components_WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Components/WalletShimmer.bs.js */ "./src/Components/WalletShimmer.bs.js");
/* harmony import */ var _PaymentElement_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PaymentElement.bs.js */ "./src/PaymentElement.bs.js");
/* harmony import */ var _PaymentElementV2_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./PaymentElementV2.bs.js */ "./src/PaymentElementV2.bs.js");
/* harmony import */ var _Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Components/PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function PaymentElementRenderer(props) {
  var cvcProps = props.cvcProps;
  var expiryProps = props.expiryProps;
  var cardProps = props.cardProps;
  var paymentType = props.paymentType;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.configAtom);
  var paymentMethodList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.paymentMethodList);
  var paymentManagementList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_6__.paymentManagementList);
  var paymentMethodsListV2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_6__.paymentMethodsListV2);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.configAtom);
  var localeString = match$1.localeString;
  var setFullName = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.userFullName);
  var setNickName = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.userCardNickName);
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useTransition();
  var startTransition = match$2[1];
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    startTransition(function () {
      setFullName(function (prev) {
        return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.validateName("", prev, localeString);
      });
      setNickName(function (prev) {
        return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.setNickNameState("", prev, localeString);
      });
    });
  }, []);
  var isLoading;
  if (_GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_4__.sdkVersion === "V1") {
    isLoading = paymentType === "Payment" && typeof paymentMethodList !== "object" && paymentMethodList === "Loading" ? true : false;
  } else {
    switch (paymentType) {
      case "Payment":
        isLoading = typeof paymentMethodsListV2 !== "object" && paymentMethodsListV2 === "LoadingV2" ? true : false;
        break;
      case "PaymentMethodsManagement":
        isLoading = typeof paymentManagementList !== "object" && paymentManagementList === "LoadingV2" ? true : false;
        break;
      default:
        isLoading = false;
    }
  }
  var isWalletElement = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.checkIsWalletElement(paymentType);
  if (isLoading) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
      condition: match.showLoader,
      children: isWalletElement ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_11__.make, {})
    });
  } else if (isWalletElement) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_WalletElement_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
      paymentType: paymentType
    });
  } else if (_GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_4__.sdkVersion === "V1") {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElement_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
      cardProps: cardProps,
      expiryProps: expiryProps,
      cvcProps: cvcProps,
      paymentType: paymentType
    });
  } else {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentElementV2_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
      cardProps: cardProps,
      expiryProps: expiryProps,
      cvcProps: cvcProps,
      paymentType: paymentType
    });
  }
}
var $$default = PaymentElementRenderer;

/* react Not a pure module */

/***/ }),

/***/ "./src/PaymentElementV2.bs.js":
/*!************************************!*\
  !*** ./src/PaymentElementV2.bs.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cardsToRender: () => (/* binding */ cardsToRender),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_belt_Array_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/belt_Array.js */ "./node_modules/rescript/lib/es6/belt_Array.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Components_Or_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Components/Or.bs.js */ "./src/Components/Or.bs.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Payments/GPayLazy.bs.js */ "./src/Payments/GPayLazy.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _VGSVault_VGSVault_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./VGSVault/VGSVault.bs.js */ "./src/VGSVault/VGSVault.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Components_PoweredBy_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./Components/PoweredBy.bs.js */ "./src/Components/PoweredBy.bs.js");
/* harmony import */ var _Payments_CardPayment_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Payments/CardPayment.bs.js */ "./src/Payments/CardPayment.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./Utilities/VaultHelpers.bs.js */ "./src/Utilities/VaultHelpers.bs.js");
/* harmony import */ var _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./hyper-log-catcher/ErrorBoundary.bs.js */ "./src/hyper-log-catcher/ErrorBoundary.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _PaymentOptions_bs_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./PaymentOptions.bs.js */ "./src/PaymentOptions.bs.js");
/* harmony import */ var _Components_PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./Components/PaymentShimmer.bs.js */ "./src/Components/PaymentShimmer.bs.js");
/* harmony import */ var _Utilities_PaymentUtilsV2_bs_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./Utilities/PaymentUtilsV2.bs.js */ "./src/Utilities/PaymentUtilsV2.bs.js");
/* harmony import */ var _Types_PaymentModeType_bs_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./Types/PaymentModeType.bs.js */ "./src/Types/PaymentModeType.bs.js");
/* harmony import */ var _Payments_SepaBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./Payments/SepaBankDebitLazy.bs.js */ "./src/Payments/SepaBankDebitLazy.bs.js");
/* harmony import */ var _Components_AccordionContainer_bs_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ./Components/AccordionContainer.bs.js */ "./src/Components/AccordionContainer.bs.js");
/* harmony import */ var _Payments_CardIframeContainer_bs_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ./Payments/CardIframeContainer.bs.js */ "./src/Payments/CardIframeContainer.bs.js");
/* harmony import */ var _Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(/*! ./Components/PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
/* harmony import */ var _hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(/*! ./hyper-log-catcher/ReusableReactSuspense.bs.js */ "./src/hyper-log-catcher/ReusableReactSuspense.bs.js");
/* harmony import */ var _Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(/*! ./Components/SessionPaymentWrapper.bs.js */ "./src/Components/SessionPaymentWrapper.bs.js");
/* harmony import */ var _Payments_PaymentMethodsWrapperLazy_bs_js__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(/*! ./Payments/PaymentMethodsWrapperLazy.bs.js */ "./src/Payments/PaymentMethodsWrapperLazy.bs.js");
/* harmony import */ var _Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(/*! ./Payments/PaymentRequestButtonElement.bs.js */ "./src/Payments/PaymentRequestButtonElement.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE

































function cardsToRender(width) {
  return (width - 40 | 0) / 130 | 0;
}
function PaymentElementV2(props) {
  var expiryProps = props.expiryProps;
  var cardProps = props.cardProps;
  var divRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.optionAtom);
  var optionAtomValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.optionAtom);
  var paymentManagementList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_19__.paymentManagementList);
  var paymentMethodsListV2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_19__.paymentMethodsListV2);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.paymentManagementListValue);
  var setPaymentManagementListValue = match$1[1];
  var sessionToken = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.sessions);
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_19__.vaultMode);
  var setVaultMode = match$2[1];
  var setPaymentMethodListValueV2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_19__.paymentMethodListValueV2);
  var isShowOrPayUsing = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.isShowOrPayUsing);
  var match$3 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setPaymentOptions = match$3[1];
  var paymentOptions = match$3[0];
  var match$4 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setWalletOptions = match$4[1];
  var walletOptions = match$4[0];
  var match$5 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return 0;
  });
  var cardsContainerWidth = match$5[0];
  var layoutClass = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.getLayoutClass(match.layout);
  var match$6 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.selectedOptionAtom);
  var setSelectedOption = match$6[1];
  var selectedOption = match$6[0];
  var match$7 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setDropDownOptions = match$7[1];
  var dropDownOptions = match$7[0];
  var match$8 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setCardOptions = match$8[1];
  var cardOptions = match$8[0];
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.loggerAtom);
  var setShowPaymentMethodsScreen = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.showPaymentMethodsScreen);
  var match$9 = _Utilities_PaymentUtilsV2_bs_js__WEBPACK_IMPORTED_MODULE_22__.useGetPaymentMethodListV2(paymentOptions, props.paymentType);
  var paymentOptionsList = match$9[1];
  var walletsList = match$9[0];
  var match$10 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var setSessions = match$10[1];
  var sessions = match$10[0];
  var sessionsDict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(sessions);
  var sessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_16__.itemToObjMapper(sessionsDict, "Others");
  var gPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_16__.getPaymentSessionObj(sessionObj.sessionsToken, "Gpay");
  var googlePayThirdPartySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_16__.itemToObjMapper(sessionsDict, "GooglePayThirdPartyObject");
  var googlePayThirdPartyToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_16__.getPaymentSessionObj(googlePayThirdPartySessionObj.sessionsToken, "Gpay");
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    setShowPaymentMethodsScreen(function (param) {
      return true;
    });
  }, []);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var vaultName = _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_17__.getVaultName(sessionToken);
    setVaultMode(function (param) {
      return _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_17__.getVaultModeFromName(vaultName);
    });
    if (typeof sessionToken === "object" && sessionToken.TAG === "Loaded") {
      var val = sessionToken._0;
      setSessions(function (param) {
        return val;
      });
    }
  }, [sessionToken]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var updatePaymentOptions = function () {
      setPaymentOptions(function (param) {
        return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.removeDuplicate(rescript_lib_es6_belt_Array_js__WEBPACK_IMPORTED_MODULE_2__.concatMany([paymentOptionsList]));
      });
    };
    var exit = 0;
    var exit$1 = 0;
    if (typeof paymentManagementList !== "object" || paymentManagementList.TAG !== "LoadedV2") {
      exit$1 = 2;
    } else {
      var paymentlist = paymentManagementList._0;
      updatePaymentOptions();
      setPaymentManagementListValue(function (param) {
        return paymentlist;
      });
    }
    if (exit$1 === 2) {
      if (typeof paymentMethodsListV2 !== "object") {
        if (!(paymentMethodsListV2 === "LoadingV2" && typeof paymentManagementList !== "object" && paymentManagementList === "LoadingV2")) {
          exit = 1;
        }
      } else if (paymentMethodsListV2.TAG === "LoadedV2") {
        var paymentlist$1 = paymentMethodsListV2._0;
        setWalletOptions(function (param) {
          return walletsList;
        });
        updatePaymentOptions();
        setPaymentMethodListValueV2(function (param) {
          return paymentlist$1;
        });
      } else {
        exit = 1;
      }
    }
    if (exit === 1) {
      setPaymentOptions(function (param) {
        return [];
      });
    }
  }, [paymentManagementList, paymentOptionsList, match$9[2], paymentMethodsListV2]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (layoutClass.type === "Tabs") {
      var isCard = cardOptions.includes(selectedOption);
      if (!isCard) {
        var match = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.swapCardOption(cardOptions, dropDownOptions, selectedOption);
        var dropdownArr = match[1];
        var cardArr = match[0];
        setCardOptions(function (param) {
          return cardArr;
        });
        setDropDownOptions(function (param) {
          return dropdownArr;
        });
      }
    }
    if (selectedOption !== "") {
      loggerState.setLogInfo("", "PAYMENT_METHOD_CHANGED", undefined, undefined, undefined, undefined, selectedOption.toUpperCase());
    }
  }, [selectedOption, cardOptions, dropDownOptions]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var cardsCount = cardsToRender(cardsContainerWidth);
    var cardOpts = paymentOptions.slice(0, cardsCount);
    var dropOpts = paymentOptions.slice(cardsCount);
    var isCard = cardOpts.includes(selectedOption);
    if (!isCard && selectedOption !== "" && paymentOptions.includes(selectedOption)) {
      var match = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.swapCardOption(cardOpts, dropOpts, selectedOption);
      var dropdownArr = match[1];
      var cardArr = match[0];
      setCardOptions(function (param) {
        return cardArr;
      });
      setDropDownOptions(function (param) {
        return dropdownArr;
      });
    } else {
      setCardOptions(function (param) {
        return cardOpts;
      });
      setDropDownOptions(function (param) {
        return dropOpts;
      });
    }
  }, [cardsContainerWidth, paymentOptions]);
  var cardShimmerCount = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return cardsToRender(cardsContainerWidth);
  }, [cardsContainerWidth]);
  var submitCallback = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_13__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(json));
    if (confirm.doSubmit && selectedOption === "") {
      return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.postFailedSubmitResponse("validation_error", "Select a payment method");
    }
  }, [selectedOption]);
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.useSubmitPaymentData(submitCallback);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    setSelectedOption(function (prev) {
      if (selectedOption !== "") {
        return prev;
      } else if (layoutClass.defaultCollapsed) {
        return "";
      } else if (typeof paymentManagementList !== "object") {
        if (paymentManagementList === "LoadingV2") {
          return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentOptions[0], "");
        } else {
          return "card";
        }
      } else if (paymentManagementList.TAG === "LoadedV2") {
        if (paymentOptions.includes(selectedOption)) {
          return selectedOption;
        } else {
          return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentOptions[0], "");
        }
      } else {
        return "card";
      }
    });
  }, [layoutClass.defaultCollapsed, paymentOptions, paymentManagementList, selectedOption, paymentMethodsListV2]);
  var loader = function () {
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.handlePostMessageEvents(false, false, selectedOption, loggerState, undefined);
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentShimmer_bs_js__WEBPACK_IMPORTED_MODULE_21__.make, {});
  };
  var match$11 = _Types_PaymentModeType_bs_js__WEBPACK_IMPORTED_MODULE_23__.paymentMode(selectedOption);
  var tmp;
  var exit = 0;
  switch (match$11) {
    case "Card":
      switch (match$2[0]) {
        case "VeryGoodSecurity":
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_VGSVault_VGSVault_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {});
          break;
        case "Hyperswitch":
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_CardIframeContainer_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {});
          break;
        case "None":
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_CardPayment_bs_js__WEBPACK_IMPORTED_MODULE_12__.make, {
            cardProps: cardProps,
            expiryProps: expiryProps,
            cvcProps: props.cvcProps
          });
          break;
      }
      break;
    case "Klarna":
    case "Ideal":
    case "EPS":
      exit = 1;
      break;
    case "SepaBankDebit":
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_28__.make, {
        children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_SepaBankDebitLazy_bs_js__WEBPACK_IMPORTED_MODULE_24__.make, {}),
        loaderComponent: loader(),
        componentName: "SepaBankDebitLazy"
      });
      break;
    case "GooglePay":
      var tmp$1;
      if (gPayToken.TAG === "OtherTokenOptional") {
        var optToken = gPayToken._0;
        var tmp$2;
        tmp$2 = googlePayThirdPartyToken.TAG === "GooglePayThirdPartyTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
          sessionObj: optToken,
          thirdPartySessionObj: googlePayThirdPartyToken._0,
          walletOptions: walletOptions
        }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
          sessionObj: optToken,
          thirdPartySessionObj: undefined,
          walletOptions: walletOptions
        });
        tmp$1 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_28__.make, {
          children: tmp$2,
          loaderComponent: loader(),
          componentName: "GPayLazy"
        });
      } else {
        tmp$1 = null;
      }
      tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_29__.make, {
        children: tmp$1,
        type_: "Wallet"
      });
      break;
    default:
      tmp = null;
  }
  if (exit === 1) {
    tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_28__.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PaymentMethodsWrapperLazy_bs_js__WEBPACK_IMPORTED_MODULE_30__.make, {
        paymentMethodName: selectedOption
      }),
      loaderComponent: loader(),
      componentName: "PaymentMethodsWrapperLazy"
    });
  }
  var checkoutEle = rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__.createElementWithKey(selectedOption, _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_18__.make, {
    children: tmp,
    componentName: "PaymentElement"
  });
  var paymentLabel = optionAtomValue.paymentMethodsHeaderText;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var evalMethodsList = function () {
      if (typeof paymentManagementList !== "object" && paymentManagementList === "LoadingV2" && typeof paymentMethodsListV2 !== "object" && paymentMethodsListV2 === "LoadingV2") {
        return;
      }
      _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, [["ready", true]]);
    };
    evalMethodsList();
  }, [paymentManagementList, paymentMethodsListV2]);
  var match$12 = layoutClass.type;
  var tmp$3;
  tmp$3 = match$12 === "Accordion" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_AccordionContainer_bs_js__WEBPACK_IMPORTED_MODULE_25__.make, {
    paymentOptions: paymentOptions,
    checkoutEle: checkoutEle,
    cardProps: cardProps,
    expiryProps: expiryProps
  }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaymentOptions_bs_js__WEBPACK_IMPORTED_MODULE_20__.make, {
    setCardsContainerWidth: match$5[1],
    cardOptions: cardOptions,
    dropDownOptions: dropDownOptions,
    checkoutEle: checkoutEle,
    cardShimmerCount: cardShimmerCount,
    cardProps: cardProps,
    expiryProps: expiryProps
  });
  var tmp$4;
  var exit$1 = 0;
  var exit$2 = 0;
  if (typeof paymentManagementList !== "object" || paymentManagementList.TAG !== "LoadErrorV2") {
    exit$2 = 2;
  } else {
    tmp$4 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: match$1[0].paymentMethodsEnabled.length === 0,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_18__.ErrorTextAndImage.make, {
        divRef: divRef,
        level: "Top"
      })
    });
  }
  if (exit$2 === 2) {
    if (typeof paymentMethodsListV2 !== "object" || paymentMethodsListV2.TAG !== "LoadErrorV2") {
      exit$1 = 1;
    } else {
      tmp$4 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_18__.ErrorTextAndImage.make, {
        divRef: divRef,
        level: "Top"
      });
    }
  }
  if (exit$1 === 1) {
    tmp$4 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: paymentOptions.length === 0 && walletOptions.length === 0,
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_27__.make, {})
    });
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
    condition: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.isSome(paymentLabel),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "text-2xl font-semibold text-[#151619] mb-6"
    }, _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_3__.getOr(paymentLabel, ""))
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
    condition: paymentOptions.length > 0 || walletOptions.length > 0,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-col place-items-center"
    }, rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_5__.createElementWithKey("payment_request_buttons_all", _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_18__.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_31__.make, {
        sessions: sessions,
        walletOptions: walletOptions
      }),
      level: "RequestButton",
      componentName: "PaymentRequestButtonElement"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_8__.make, {
      condition: paymentOptions.length > 0 && walletOptions.length > 0 && _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.checkRenderOrComp(walletOptions, isShowOrPayUsing),
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_Or_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {})
    }), tmp$3)
  }), tmp$4, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PoweredBy_bs_js__WEBPACK_IMPORTED_MODULE_11__.make, {}));
}
var make = PaymentElementV2;

/* react Not a pure module */

/***/ }),

/***/ "./src/PaymentOptions.bs.js":
/*!**********************************!*\
  !*** ./src/PaymentOptions.bs.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TabLoader: () => (/* binding */ TabLoader),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_int32_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_int32.js */ "./node_modules/rescript/lib/es6/caml_int32.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Array_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Array.bs.js */ "./node_modules/@rescript/core/src/Core__Array.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _TabCard_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./TabCard.bs.js */ "./src/TabCard.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./Utilities/TestUtils.bs.js */ "./src/Utilities/TestUtils.bs.js");
/* harmony import */ var _GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./GlobalVars.bs.js */ "./src/GlobalVars.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
/* harmony import */ var _Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./Components/PaymentElementShimmer.bs.js */ "./src/Components/PaymentElementShimmer.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE




















function PaymentOptions$TabLoader(props) {
  var paymentMethodList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.paymentMethodList);
  var paymentManagementList = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_16__.paymentManagementList);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.configAtom);
  var themeObj = match.themeObj;
  if (_GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_13__.sdkVersion === "V1") {
    if (typeof paymentMethodList === "object") {
      return null;
    }
    if (paymentMethodList !== "SemiLoaded") {
      return null;
    }
  } else {
    if (typeof paymentManagementList === "object") {
      return null;
    }
    if (paymentManagementList !== "SemiLoadedV2") {
      return null;
    }
  }
  return _rescript_core_src_Core_Array_bs_js__WEBPACK_IMPORTED_MODULE_4__.make(props.cardShimmerCount - 1 | 0, "").map(function (param, i) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      key: i.toString(),
      className: "Tab flex flex-col gap-3 animate-pulse cursor-default",
      style: {
        cursor: "pointer",
        minWidth: "5rem",
        padding: themeObj.spacingUnit,
        width: "100%",
        overflowWrap: "hidden"
      }
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_18__.Shimmer.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "w-full h-3 animate-pulse",
        style: {
          backgroundColor: themeObj.colorPrimary,
          opacity: "10%"
        }
      }),
      classname: "opacity-50 w-1/3"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_PaymentElementShimmer_bs_js__WEBPACK_IMPORTED_MODULE_18__.Shimmer.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
        className: "w-full h-2 animate-pulse",
        style: {
          backgroundColor: themeObj.colorPrimary,
          opacity: "10%"
        }
      }),
      classname: "opacity-50"
    }));
  });
}
var TabLoader = {
  make: PaymentOptions$TabLoader
};
function PaymentOptions(props) {
  var setCardsContainerWidth = props.setCardsContainerWidth;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.configAtom);
  var localeString = match.localeString;
  var themeObj = match.themeObj;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.optionAtom);
  var customMethodNames = match$1.customMethodNames;
  var payOptionsRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
  var selectRef = react__WEBPACK_IMPORTED_MODULE_0__.useRef(null);
  var match$2 = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_8__.useWindowSize();
  var match$3 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_14__.selectedOptionAtom);
  var setSelectedOption = match$3[1];
  var selectedOption = match$3[0];
  var match$4 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return 0;
  });
  var setMoreIconIndex = match$4[1];
  var match$5 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setToggleIconElement = match$5[1];
  var toggleIconElement = match$5[0];
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.paymentMethodListValue);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var ref = payOptionsRef.current;
    var width = !(ref == null) ? ref.clientWidth : 0;
    setCardsContainerWidth(function (param) {
      return width;
    });
  }, [match$2[1], match$2[0]]);
  var handleChange = function (ev) {
    var target = ev.target;
    var value = target.value;
    setSelectedOption(function (param) {
      return value;
    });
    _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.blurRef(selectRef);
  };
  var cardOptionDetails = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_17__.getPaymentDetails(props.cardOptions, localeString);
  var dropDownOptionsDetails = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_17__.getPaymentDetails(props.dropDownOptions, localeString);
  var allOptions = cardOptionDetails.concat(dropDownOptionsDetails);
  var selectedPaymentOption = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOr(allOptions.find(function (item) {
    return item.paymentMethodName === selectedOption;
  }), _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_17__.defaultPaymentFieldsInfo);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var intervalId = setInterval(function () {
      if (dropDownOptionsDetails.length > 1) {
        setMoreIconIndex(function (prev) {
          return rescript_lib_es6_caml_int32_js__WEBPACK_IMPORTED_MODULE_2__.mod_(prev + 1 | 0, dropDownOptionsDetails.length);
        });
        setToggleIconElement(function (param) {
          return true;
        });
        setTimeout(function () {
          setToggleIconElement(function (param) {
            return false;
          });
        }, 10);
        return;
      }
    }, 5000);
    return function () {
      clearInterval(intervalId);
    };
  }, [dropDownOptionsDetails]);
  _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.useEmitPaymentMethodInfo(selectedPaymentOption.paymentMethodName, paymentMethodListValue.payment_methods, props.cardProps, props.expiryProps);
  var displayIcon = function (ele) {
    return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", {
      className: "scale-90 animate-slowShow " + (toggleIconElement ? "hidden" : "")
    }, ele);
  };
  var paymentFieldsInfo = dropDownOptionsDetails[match$4[0]];
  var tmp;
  if (paymentFieldsInfo !== undefined) {
    var ele = paymentFieldsInfo.miniIcon;
    if (ele !== undefined) {
      tmp = displayIcon(rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.valFromOption(ele));
    } else {
      var ele$1 = paymentFieldsInfo.icon;
      tmp = ele$1 !== undefined ? displayIcon(rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.valFromOption(ele$1)) : null;
    }
  } else {
    tmp = null;
  }
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "w-full"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    ref: rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(payOptionsRef),
    className: "TabHeader flex flex-row overflow-auto no-scrollbar",
    "data-testid": _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_12__.paymentMethodListTestId,
    style: {
      height: "auto",
      marginBottom: themeObj.spacingGridColumn,
      padding: "4px",
      paddingBottom: "7px",
      columnGap: themeObj.spacingTab
    }
  }, cardOptionDetails.map(function (payOption, i) {
    var isActive = payOption.paymentMethodName === selectedOption;
    return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_6__.createElementWithKey(i.toString(), _TabCard_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
      paymentOption: payOption,
      isActive: isActive
    });
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(PaymentOptions$TabLoader, {
    cardShimmerCount: props.cardShimmerCount
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
    condition: dropDownOptionsDetails.length > 0,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex relative h-auto justify-center"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-col items-center absolute mt-3 pointer-events-none gap-y-1.5"
    }, tmp, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
      name: "arrow-down",
      size: 10
    })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", {
      ref: rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_3__.some(selectRef),
      className: "TabMore place-items-start outline-none",
      "data-testid": _Utilities_TestUtils_bs_js__WEBPACK_IMPORTED_MODULE_12__.paymentMethodDropDownTestId,
      style: {
        background: themeObj.colorBackground,
        color: "transparent",
        cursor: "pointer",
        height: "inherit",
        paddingLeft: themeObj.spacingUnit,
        width: "40px",
        borderRadius: themeObj.borderRadius,
        appearance: "none"
      },
      disabled: match$1.readOnly,
      value: selectedPaymentOption.paymentMethodName,
      onChange: handleChange
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", {
      disabled: true,
      value: selectedPaymentOption.paymentMethodName
    }, _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.getDisplayNameAndIcon(customMethodNames, selectedPaymentOption.paymentMethodName, selectedPaymentOption.displayName, selectedPaymentOption.icon)[0]), dropDownOptionsDetails.map(function (item, i) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", {
        key: i.toString(),
        style: {
          color: themeObj.colorPrimary
        },
        value: item.paymentMethodName
      }, _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.getDisplayNameAndIcon(customMethodNames, item.paymentMethodName, item.displayName, item.icon)[0]);
    })))
  })), props.checkoutEle);
}
var make = PaymentOptions;

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/ACHBankDebitLazy.bs.js":
/*!*********************************************!*\
  !*** ./src/Payments/ACHBankDebitLazy.bs.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return Promise.all(/*! import() */[__webpack_require__.e("src_Components_AddressPaymentInput_bs_js"), __webpack_require__.e("src_Components_AddBankAccount_bs_js-src_Components_FullScreenPortal_bs_js-src_Payments_BankDe-63c528"), __webpack_require__.e("src_Payments_ACHBankDebit_bs_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ACHBankDebit.bs.js */ "./src/Payments/ACHBankDebit.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/ACHBankTransferLazy.bs.js":
/*!************************************************!*\
  !*** ./src/Payments/ACHBankTransferLazy.bs.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_ACHBankTransfer_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./ACHBankTransfer.bs.js */ "./src/Payments/ACHBankTransfer.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/ApplePayLazy.bs.js":
/*!*****************************************!*\
  !*** ./src/Payments/ApplePayLazy.bs.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_ApplePay_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./ApplePay.bs.js */ "./src/Payments/ApplePay.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/BacsBankDebitLazy.bs.js":
/*!**********************************************!*\
  !*** ./src/Payments/BacsBankDebitLazy.bs.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return Promise.all(/*! import() */[__webpack_require__.e("src_Components_AddressPaymentInput_bs_js"), __webpack_require__.e("src_Payments_BacsBankDebit_bs_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./BacsBankDebit.bs.js */ "./src/Payments/BacsBankDebit.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/BacsBankTransferLazy.bs.js":
/*!*************************************************!*\
  !*** ./src/Payments/BacsBankTransferLazy.bs.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_BacsBankTransfer_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./BacsBankTransfer.bs.js */ "./src/Payments/BacsBankTransfer.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/BecsBankDebitLazy.bs.js":
/*!**********************************************!*\
  !*** ./src/Payments/BecsBankDebitLazy.bs.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return Promise.all(/*! import() */[__webpack_require__.e("src_Components_AddressPaymentInput_bs_js"), __webpack_require__.e("src_Components_AddBankAccount_bs_js-src_Components_FullScreenPortal_bs_js-src_Payments_BankDe-63c528"), __webpack_require__.e("src_Payments_BecsBankDebit_bs_js")]).then(__webpack_require__.bind(__webpack_require__, /*! ./BecsBankDebit.bs.js */ "./src/Payments/BecsBankDebit.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/BoletoLazy.bs.js":
/*!***************************************!*\
  !*** ./src/Payments/BoletoLazy.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_Boleto_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./Boleto.bs.js */ "./src/Payments/Boleto.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/CardIframeContainer.bs.js":
/*!************************************************!*\
  !*** ./src/Payments/CardIframeContainer.bs.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_obj.js */ "./node_modules/rescript/lib/es6/caml_obj.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Window_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Window.bs.js */ "./src/Window.bs.js");
/* harmony import */ var _Utilities_ApiEndpoint_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Utilities/ApiEndpoint.bs.js */ "./src/Utilities/ApiEndpoint.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Utilities/VaultHelpers.bs.js */ "./src/Utilities/VaultHelpers.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Utilities/PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
/* harmony import */ var _Utilities_EventListenerManager_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Utilities/EventListenerManager.bs.js */ "./src/Utilities/EventListenerManager.bs.js");
/* harmony import */ var _Utilities_PaymentManagementBody_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../Utilities/PaymentManagementBody.bs.js */ "./src/Utilities/PaymentManagementBody.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE
















function CardIframeContainer(props) {
  var config = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.configAtom);
  var setKeys = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.keys);
  var session = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.sessions);
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.loggerAtom);
  var customPodUri = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.customPodUri);
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.isManualRetryEnabled);
  var paymentMethodListValueV2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_11__.paymentMethodListValueV2);
  var setVaultPublishableKey = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_11__.vaultPublishableKey);
  var setVaultProfileId = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_11__.vaultProfileId);
  var match = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "0px";
  });
  var setInnerIframeHeight = match[1];
  var intent = _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_12__.usePaymentIntent(loggerState, "Card");
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handleMessage = function (ev) {
      var json = ev.data;
      var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json);
      var heightValue = dict["cardIframeContentHeight"];
      if (heightValue === undefined) {
        return;
      }
      var h = _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_3__.Decode.$$float(heightValue);
      if (h !== undefined) {
        var newHeightPx = h.toString() + "px";
        return setInnerIframeHeight(function (param) {
          return newHeightPx;
        });
      }
      console.warn("Received cardIframeContentHeight but value is not a float");
    };
    window.addEventListener("message", handleMessage);
    return function () {
      window.removeEventListener("message", handleMessage);
    };
  }, []);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handle = function (ev) {
      var json = ev.data;
      var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json);
      if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["innerIframeMountedCallback"])) {
        return;
      }
      var match = _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getHyperswitchVaultDetails(session);
      var vaultProfileId = match.vaultProfileId;
      var vaultPublishableKey = match.vaultPublishableKey;
      var pmClientSecret = match.pmClientSecret;
      var pmSessionId = match.pmSessionId;
      setKeys(function (prev) {
        var newrecord = rescript_lib_es6_caml_obj_js__WEBPACK_IMPORTED_MODULE_2__.obj_dup(prev);
        newrecord.pmClientSecret = pmClientSecret;
        newrecord.pmSessionId = pmSessionId;
        return newrecord;
      });
      setVaultPublishableKey(function (param) {
        return vaultPublishableKey;
      });
      setVaultProfileId(function (param) {
        return vaultProfileId;
      });
      var metaData = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getJsonFromArrayOfJson([["config", config.config], ["pmSessionId", pmSessionId], ["pmClientSecret", pmClientSecret], ["vaultPublishableKey", vaultPublishableKey], ["vaultProfileId", vaultProfileId], ["paymentList", paymentMethodListValueV2], ["endpoint", _Utilities_ApiEndpoint_bs_js__WEBPACK_IMPORTED_MODULE_7__.getApiEndPoint(undefined, undefined)], ["customPodUri", customPodUri]]);
      var innerIframe = document.querySelector("#orca-inneriframe");
      _Window_bs_js__WEBPACK_IMPORTED_MODULE_6__.iframePostMessage(innerIframe, Object.fromEntries([["metadata", metaData], ["innerIframeMounted", true]]));
    };
    window.addEventListener("message", handle);
    return function () {
      window.removeEventListener("message", handle);
    };
  }, []);
  var submitCallback = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_8__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json));
    if (!confirm.doSubmit) {
      return;
    }
    var innerIframe = document.querySelector("#orca-inneriframe");
    _Window_bs_js__WEBPACK_IMPORTED_MODULE_6__.iframePostMessage(innerIframe, Object.fromEntries([["generateToken", true]]));
    var handle = function (ev) {
      var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.safeParse(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getStringFromJson(ev.data, ""));
      var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json);
      if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["paymentToken"])) {
        var token = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getString(dict, "paymentToken", "");
        var cardBody = _Utilities_PaymentManagementBody_bs_js__WEBPACK_IMPORTED_MODULE_14__.hyperswitchVaultBody(token);
        return intent(false, cardBody, confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, undefined);
      }
      if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["errorMsg"])) {
        return;
      }
      var errorMsg = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getString(dict, "errorMsg", "");
      _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.postFailedSubmitResponse("validation_error", errorMsg);
    };
    _Utilities_EventListenerManager_bs_js__WEBPACK_IMPORTED_MODULE_13__.addSmartEventListener("message", handle, "handleCardVaultToken");
  }, undefined);
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.useSubmitPaymentData(submitCallback);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    id: "iframe-for-card",
    style: {
      height: match[0],
      position: "relative",
      width: "100%"
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("iframe", {
    className: "mb-[4px] mr-4px ml-4px",
    id: "orca-inneriframe",
    style: {
      border: "none",
      height: "100%",
      left: "0",
      position: "absolute",
      top: "0",
      width: "100%"
    },
    src: _Utilities_ApiEndpoint_bs_js__WEBPACK_IMPORTED_MODULE_7__.sdkDomainUrl + "/fullscreenIndex.html?fullscreenType=cardVault"
  }));
}
var make = CardIframeContainer;

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/GPayLazy.bs.js":
/*!*************************************!*\
  !*** ./src/Payments/GPayLazy.bs.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_GPay_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./GPay.bs.js */ "./src/Payments/GPay.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/InstantBankTransferFinlandLazy.bs.js":
/*!***********************************************************!*\
  !*** ./src/Payments/InstantBankTransferFinlandLazy.bs.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_InstantBankTransferFinland_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./InstantBankTransferFinland.bs.js */ "./src/Payments/InstantBankTransferFinland.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/InstantBankTransferLazy.bs.js":
/*!****************************************************!*\
  !*** ./src/Payments/InstantBankTransferLazy.bs.js ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_InstantBankTransfer_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./InstantBankTransfer.bs.js */ "./src/Payments/InstantBankTransfer.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/InstantBankTransferPolandLazy.bs.js":
/*!**********************************************************!*\
  !*** ./src/Payments/InstantBankTransferPolandLazy.bs.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_InstantBankTransferPoland_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./InstantBankTransferPoland.bs.js */ "./src/Payments/InstantBankTransferPoland.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/KlarnaCheckoutLazy.bs.js":
/*!***********************************************!*\
  !*** ./src/Payments/KlarnaCheckoutLazy.bs.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_KlarnaCheckout_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./KlarnaCheckout.bs.js */ "./src/Payments/KlarnaCheckout.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/KlarnaHelpers.bs.js":
/*!******************************************!*\
  !*** ./src/Payments/KlarnaHelpers.bs.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   usePaymentMethodExperience: () => (/* binding */ usePaymentMethodExperience)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE




function usePaymentMethodExperience(paymentMethodListValue, sessionObj) {
  var klarnaPaymentMethodExperience = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return _PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_2__.getPaymentExperienceTypeFromPML(paymentMethodListValue, "pay_later", "klarna");
  }, [paymentMethodListValue]);
  var klarnaTokenObj = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_1__.getPaymentSessionObj(sessionObj.sessionsToken, "Klarna");
  }, [sessionObj]);
  var isKlarnaSDKFlow = klarnaPaymentMethodExperience.includes("InvokeSDK");
  var isKlarnaCheckoutFlow = klarnaPaymentMethodExperience.includes("RedirectToURL");
  return {
    klarnaTokenObj: klarnaTokenObj,
    isKlarnaSDKFlow: isKlarnaSDKFlow,
    isKlarnaCheckoutFlow: isKlarnaCheckoutFlow
  };
}

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/KlarnaSDKLazy.bs.js":
/*!******************************************!*\
  !*** ./src/Payments/KlarnaSDKLazy.bs.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_KlarnaSDK_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./KlarnaSDK.bs.js */ "./src/Payments/KlarnaSDK.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/PayPalLazy.bs.js":
/*!***************************************!*\
  !*** ./src/Payments/PayPalLazy.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_PayPal_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./PayPal.bs.js */ "./src/Payments/PayPal.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/PaymentMethodsWrapperLazy.bs.js":
/*!******************************************************!*\
  !*** ./src/Payments/PaymentMethodsWrapperLazy.bs.js ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_PaymentMethodsWrapper_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./PaymentMethodsWrapper.bs.js */ "./src/Payments/PaymentMethodsWrapper.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/PaymentRequestButtonElement.bs.js":
/*!********************************************************!*\
  !*** ./src/Payments/PaymentRequestButtonElement.bs.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   WalletsSaveDetailsText: () => (/* binding */ WalletsSaveDetailsText),
/* harmony export */   make: () => (/* binding */ make),
/* harmony export */   paymentMode: () => (/* binding */ paymentMode)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./GPayLazy.bs.js */ "./src/Payments/GPayLazy.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Components_Surcharge_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Components/Surcharge.bs.js */ "./src/Components/Surcharge.bs.js");
/* harmony import */ var _GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../GlobalVars.bs.js */ "./src/GlobalVars.bs.js");
/* harmony import */ var _PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PayPalLazy.bs.js */ "./src/Payments/PayPalLazy.bs.js");
/* harmony import */ var _PazeButton_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./PazeButton.bs.js */ "./src/Payments/PazeButton.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _ApplePayLazy_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./ApplePayLazy.bs.js */ "./src/Payments/ApplePayLazy.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../Types/SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
/* harmony import */ var _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../Hooks/UtilityHooks.bs.js */ "./src/Hooks/UtilityHooks.bs.js");
/* harmony import */ var _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../hyper-log-catcher/ErrorBoundary.bs.js */ "./src/hyper-log-catcher/ErrorBoundary.bs.js");
/* harmony import */ var _KlarnaHelpers_bs_js__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./KlarnaHelpers.bs.js */ "./src/Payments/KlarnaHelpers.bs.js");
/* harmony import */ var _KlarnaSDKLazy_bs_js__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./KlarnaSDKLazy.bs.js */ "./src/Payments/KlarnaSDKLazy.bs.js");
/* harmony import */ var _PayPalHelpers_bs_js__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./PayPalHelpers.bs.js */ "./src/Payments/PayPalHelpers.bs.js");
/* harmony import */ var _PaypalSDKLazy_bs_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./PaypalSDKLazy.bs.js */ "./src/Payments/PaypalSDKLazy.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ../Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _Components_WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ../Components/WalletShimmer.bs.js */ "./src/Components/WalletShimmer.bs.js");
/* harmony import */ var _KlarnaCheckoutLazy_bs_js__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ./KlarnaCheckoutLazy.bs.js */ "./src/Payments/KlarnaCheckoutLazy.bs.js");
/* harmony import */ var _SamsungPayComponent_bs_js__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(/*! ./SamsungPayComponent.bs.js */ "./src/Payments/SamsungPayComponent.bs.js");
/* harmony import */ var _hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(/*! ../hyper-log-catcher/ReusableReactSuspense.bs.js */ "./src/hyper-log-catcher/ReusableReactSuspense.bs.js");
/* harmony import */ var _Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(/*! ../Components/SessionPaymentWrapper.bs.js */ "./src/Components/SessionPaymentWrapper.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE




























function paymentMode(str) {
  switch (str) {
    case "apple_pay":
    case "applepay":
      return "ApplePayWallet";
    case "google_pay":
    case "gpay":
      return "GPayWallet";
    case "klarna":
      return "KlarnaWallet";
    case "paypal":
      return "PaypalWallet";
    case "paze":
      return "PazeWallet";
    case "samsung_pay":
    case "samsungpay":
      return "SamsungPayWallet";
    default:
      return "NONE";
  }
}
function PaymentRequestButtonElement$WalletsSaveDetailsText(props) {
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_11__.areOneClickWalletsRendered);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_11__.configAtom);
  var isGuestCustomer = _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_15__.useIsGuestCustomer();
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.paymentMethodListValue);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
    condition: _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.isAppendingCustomerAcceptance(isGuestCustomer, paymentMethodListValue.payment_type) && (match.isGooglePay || match.isApplePay || match.isPaypal || match.isSamsungPay),
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "SaveWalletDetailsLabel flex items-center text-xs mt-2 text-left text-gray-400"
    }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
      name: "lock",
      size: 10,
      className: "mr-1"
    }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("em", undefined, match$1.localeString.saveWalletDetails))
  });
}
var WalletsSaveDetailsText = {
  make: PaymentRequestButtonElement$WalletsSaveDetailsText
};
function PaymentRequestButtonElement(props) {
  var walletOptions = props.walletOptions;
  var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_4__.getDictFromJson(props.sessions);
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_13__.paymentMethodListValue);
  var paymentMethodListValueV2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_21__.paymentMethodListValueV2);
  var sessionObj = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    return _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.itemToObjMapper(dict, "Others");
  }, [dict]);
  var paypalPaymentMethodDataV1 = _PayPalHelpers_bs_js__WEBPACK_IMPORTED_MODULE_19__.usePaymentMethodData(paymentMethodListValue, sessionObj);
  var paypalPaymentMethodDataV2 = _PayPalHelpers_bs_js__WEBPACK_IMPORTED_MODULE_19__.usePaymentMethodDataV2(paymentMethodListValueV2, sessionObj);
  var match;
  match = _GlobalVars_bs_js__WEBPACK_IMPORTED_MODULE_8__.sdkVersion === "V1" ? paypalPaymentMethodDataV1 : paypalPaymentMethodDataV2;
  var isPaypalRedirectFlow = match.isPaypalRedirectFlow;
  var isPaypalSDKFlow = match.isPaypalSDKFlow;
  var paypalToken = match.paypalToken;
  var gPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(sessionObj.sessionsToken, "Gpay");
  var applePaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.itemToObjMapper(dict, "ApplePayObject");
  var applePayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(applePaySessionObj.sessionsToken, "ApplePay");
  var samsungPaySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.itemToObjMapper(dict, "SamsungPayObject");
  var samsungPayToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(samsungPaySessionObj.sessionsToken, "SamsungPay");
  var googlePayThirdPartySessionObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.itemToObjMapper(dict, "GooglePayThirdPartyObject");
  var googlePayThirdPartyToken = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(googlePayThirdPartySessionObj.sessionsToken, "Gpay");
  var match$1 = _KlarnaHelpers_bs_js__WEBPACK_IMPORTED_MODULE_17__.usePaymentMethodExperience(paymentMethodListValue, sessionObj);
  var isKlarnaCheckoutFlow = match$1.isKlarnaCheckoutFlow;
  var isKlarnaSDKFlow = match$1.isKlarnaSDKFlow;
  var klarnaTokenObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(sessionObj.sessionsToken, "Klarna");
  var pazeTokenObj = _Types_SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_14__.getPaymentSessionObj(sessionObj.sessionsToken, "Paze");
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_11__.keys);
  var clientSecret = match$2.clientSecret;
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_11__.optionAtom);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    "aria-label": "Wallet Section",
    className: "flex flex-col gap-2 h-auto w-full",
    role: "region"
  }, walletOptions.map(function (item, i) {
    var tmp;
    if (clientSecret !== undefined) {
      var match = paymentMode(item);
      switch (match) {
        case "GPayWallet":
          var tmp$1;
          if (gPayToken.TAG === "OtherTokenOptional") {
            var optToken = gPayToken._0;
            tmp$1 = googlePayThirdPartyToken.TAG === "GooglePayThirdPartyTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
              sessionObj: optToken,
              thirdPartySessionObj: googlePayThirdPartyToken._0,
              walletOptions: walletOptions
            }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_GPayLazy_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
              sessionObj: optToken,
              thirdPartySessionObj: undefined,
              walletOptions: walletOptions
            });
          } else {
            tmp$1 = null;
          }
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {
            children: tmp$1,
            type_: "Wallet"
          });
          break;
        case "PaypalWallet":
          var tmp$2;
          if (paypalToken.TAG === "OtherTokenOptional") {
            var optToken$1 = paypalToken._0;
            var exit = 0;
            if (optToken$1 !== undefined && isPaypalSDKFlow) {
              tmp$2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PaypalSDKLazy_bs_js__WEBPACK_IMPORTED_MODULE_20__.make, {
                sessionObj: optToken$1
              });
            } else {
              exit = 1;
            }
            if (exit === 1) {
              tmp$2 = isPaypalRedirectFlow ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
                walletOptions: walletOptions
              }) : null;
            }
          } else {
            tmp$2 = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
              condition: isPaypalRedirectFlow,
              children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PayPalLazy_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
                walletOptions: walletOptions
              })
            });
          }
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {
            children: tmp$2,
            type_: "Wallet"
          });
          break;
        case "ApplePayWallet":
          tmp = applePayToken.TAG === "ApplePayTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_ApplePayLazy_bs_js__WEBPACK_IMPORTED_MODULE_12__.make, {
            sessionObj: applePayToken._0,
            walletOptions: walletOptions
          }) : null;
          break;
        case "KlarnaWallet":
          var tmp$3;
          if (klarnaTokenObj.TAG === "OtherTokenOptional") {
            var optToken$2 = klarnaTokenObj._0;
            tmp$3 = optToken$2 !== undefined ? isKlarnaSDKFlow ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_KlarnaSDKLazy_bs_js__WEBPACK_IMPORTED_MODULE_18__.make, {
              sessionObj: optToken$2
            }) : isKlarnaCheckoutFlow ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_KlarnaCheckoutLazy_bs_js__WEBPACK_IMPORTED_MODULE_23__.make, {}) : null : isKlarnaCheckoutFlow ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_KlarnaCheckoutLazy_bs_js__WEBPACK_IMPORTED_MODULE_23__.make, {}) : null;
          } else {
            tmp$3 = null;
          }
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {
            children: tmp$3,
            type_: "Others"
          });
          break;
        case "SamsungPayWallet":
          tmp = samsungPayToken.TAG === "SamsungPayTokenOptional" ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_SamsungPayComponent_bs_js__WEBPACK_IMPORTED_MODULE_24__.make, {
            sessionObj: samsungPayToken._0,
            walletOptions: walletOptions
          }) : null;
          break;
        case "PazeWallet":
          var tmp$4;
          if (pazeTokenObj.TAG === "OtherTokenOptional") {
            var optToken$3 = pazeTokenObj._0;
            tmp$4 = optToken$3 !== undefined ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_PazeButton_bs_js__WEBPACK_IMPORTED_MODULE_10__.make, {
              token: optToken$3
            }) : null;
          } else {
            tmp$4 = null;
          }
          tmp = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {
            condition: options.wallets.paze === "Auto",
            children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_SessionPaymentWrapper_bs_js__WEBPACK_IMPORTED_MODULE_26__.make, {
              children: tmp$4,
              type_: "Wallet"
            })
          });
          break;
        case "NONE":
          tmp = null;
          break;
      }
    } else {
      tmp = null;
    }
    return rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_2__.createElementWithKey(item + "-" + i.toString() + "-request-button", _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_16__.make, {
      children: rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_2__.createElementWithKey(i.toString(), _hyper_log_catcher_ReusableReactSuspense_bs_js__WEBPACK_IMPORTED_MODULE_25__.make, {
        children: tmp,
        loaderComponent: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_WalletShimmer_bs_js__WEBPACK_IMPORTED_MODULE_22__.make, {}),
        componentName: "PaymentRequestButtonElement"
      }),
      level: "RequestButton",
      componentName: "PaymentRequestButtonElement"
    });
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_Surcharge_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
    paymentMethod: "wallet",
    paymentMethodType: "google_pay",
    isForWallets: true
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(PaymentRequestButtonElement$WalletsSaveDetailsText, {}));
}
var make = PaymentRequestButtonElement;

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/PaypalSDKLazy.bs.js":
/*!******************************************!*\
  !*** ./src/Payments/PaypalSDKLazy.bs.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_PaypalSDK_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./PaypalSDK.bs.js */ "./src/Payments/PaypalSDK.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/PazeButton.bs.js":
/*!***************************************!*\
  !*** ./src/Payments/PazeButton.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/react/src/RescriptReactRouter.bs.js */ "./node_modules/@rescript/react/src/RescriptReactRouter.bs.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Components_Spinner_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Components/Spinner.bs.js */ "./src/Components/Spinner.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Utilities/PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function PazeButton(props) {
  var token = props.token;
  var url = _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_3__.useUrl(undefined, undefined);
  var componentName = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.getQueryParamsDictforKey(url.search, "componentName");
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.keys);
  var iframeId = match.iframeId;
  var publishableKey = match.publishableKey;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.configAtom);
  var themeObj = match$1.themeObj;
  var updateSession = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.updateSession);
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.optionAtom);
  var setIsShowOrPayUsing = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.isShowOrPayUsing);
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.loggerAtom);
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_9__.isManualRetryEnabled);
  var intent = _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.usePaymentIntent(loggerState, "Paze");
  var paymentIntentID = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getPaymentId(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.getOr(match.clientSecret, ""));
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return false;
  });
  var setShowLoader = match$2[1];
  var showLoader = match$2[0];
  var match$3 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.useNonPiiAddressData();
  var pinCode = match$3.pinCode;
  var state = match$3.state;
  var country = match$3.country;
  var onClick = function (param) {
    loggerState.setLogInfo("Paze SDK Button Clicked", "PAZE_SDK_FLOW", undefined, undefined, undefined, undefined, "PAZE");
    _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.emitPaymentMethodInfo("wallet", "paze", undefined, undefined, undefined, undefined, undefined, country, state, pinCode, undefined);
    setShowLoader(function (param) {
      return true;
    });
    var metadata = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getJsonFromArrayOfJson([["componentName", componentName], ["wallet", token.walletName], ["clientId", token.clientId], ["clientName", token.clientName], ["clientProfileId", token.clientProfileId], ["sessionId", paymentIntentID], ["publishableKey", publishableKey], ["emailAddress", token.email_address], ["transactionAmount", token.transaction_amount], ["transactionCurrencyCode", token.transaction_currency_code]]);
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.messageParentWindow(undefined, [["fullscreen", true], ["param", "pazeWallet"], ["iframeId", iframeId], ["metadata", metadata]]);
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handlePazeCallback = function (ev) {
      var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.safeParse(ev.data);
      var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromDict(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDictFromJson(json), "data");
      if (!_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getBool(dict, "isPaze", false)) {
        return;
      }
      setShowLoader(function (param) {
        return false;
      });
      _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.messageParentWindow(undefined, [["fullscreen", true], ["param", "paymentloader"], ["iframeId", iframeId]]);
      if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.isSome(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getOptionString(dict, "completeResponse"))) {
        return;
      }
      var completeResponse = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getString(dict, "completeResponse", "");
      intent(false, _Utilities_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_8__.pazeBody(completeResponse), {
        return_url: options.wallets.walletReturnUrl,
        publishableKey: publishableKey
      }, undefined, undefined, undefined, isManualRetryEnabled, undefined);
    };
    setIsShowOrPayUsing(function (param) {
      return true;
    });
    window.addEventListener("message", handlePazeCallback);
    return function () {
      window.removeEventListener("message", handlePazeCallback);
    };
  }, []);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
    className: "w-full flex flex-row justify-center items-center",
    style: {
      backgroundColor: "#2B63FF",
      border: themeObj.buttonBorderWidth + " solid " + themeObj.buttonBorderColor,
      cursor: showLoader ? "not-allowed" : "pointer",
      height: themeObj.buttonHeight,
      width: themeObj.buttonWidth,
      opacity: showLoader || updateSession ? "0.5" : "1.0",
      borderRadius: themeObj.buttonBorderRadius,
      pointerEvents: updateSession ? "none" : "auto"
    },
    disabled: showLoader,
    onClick: onClick
  }, showLoader ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_Spinner_bs_js__WEBPACK_IMPORTED_MODULE_6__.make, {}) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    name: "paze",
    size: 55
  }));
}
var make = PazeButton;

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/SamsungPayComponent.bs.js":
/*!************************************************!*\
  !*** ./src/Payments/SamsungPayComponent.bs.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @rescript/react/src/RescriptReactRouter.bs.js */ "./node_modules/@rescript/react/src/RescriptReactRouter.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
/* harmony import */ var _Hooks_CommonHooks_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Hooks/CommonHooks.bs.js */ "./src/Hooks/CommonHooks.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Utilities/PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
/* harmony import */ var _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Utilities/SamsungPayHelpers.bs.js */ "./src/Utilities/SamsungPayHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function SamsungPayComponent(props) {
  var sessionObj = props.sessionObj;
  var url = _rescript_react_src_RescriptReactRouter_bs_js__WEBPACK_IMPORTED_MODULE_3__.useUrl(undefined, undefined);
  var isSamsungPayReady = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.isSamsungPayReady);
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.loggerAtom);
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.optionAtom);
  var updateSession = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.updateSession);
  var setIsShowOrPayUsing = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.isShowOrPayUsing);
  var areOneClickWalletsRendered = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.areOneClickWalletsRendered);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.keys);
  var iframeId = match.iframeId;
  var status = _Hooks_CommonHooks_bs_js__WEBPACK_IMPORTED_MODULE_7__.useScript("https://img.mpay.samsung.com/gsmpi/sdk/samsungpay_web_sdk.js", undefined);
  var isWallet = props.walletOptions.includes("samsung_pay");
  var componentName = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getQueryParamsDictforKey(url.search, "componentName");
  var intent = _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.usePaymentIntent(loggerState, "Samsungpay");
  var match$1 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.useNonPiiAddressData();
  var pinCode = match$1.pinCode;
  var state = match$1.state;
  var country = match$1.country;
  var match$2 = options.wallets.style.height;
  var heightType = match$2[4];
  var height;
  height = heightType.TAG === "SamsungPay" ? heightType._0 : 48;
  _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.useHandleSamsungPayResponse(intent, undefined, isWallet);
  var onSamsungPaymentButtonClick = function (param) {
    loggerState.setLogInfo("SamsungPay Button Clicked", "SAMSUNG_PAY", undefined, undefined, undefined, undefined, "SAMSUNG_PAY");
    _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_9__.emitPaymentMethodInfo("wallet", "samsung_pay", undefined, undefined, undefined, undefined, undefined, country, state, pinCode, undefined);
    _Utilities_SamsungPayHelpers_bs_js__WEBPACK_IMPORTED_MODULE_11__.handleSamsungPayClicked(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_4__.getDictFromJson(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.getOr(sessionObj, null)), componentName, iframeId, options.readOnly);
  };
  var buttonStyle = {
    onClick: onSamsungPaymentButtonClick,
    buttonStyle: "black",
    type: "buy"
  };
  var addSamsungPayButton = function (param) {
    var paymentClient = new SamsungPay.PaymentClient({
      environment: "PRODUCTION"
    });
    var button = paymentClient.createButton(buttonStyle);
    var spayWrapper = document.getElementById("samsungpay-container");
    spayWrapper.innerHTML = "";
    spayWrapper.appendChild(button);
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (status === "ready" && isSamsungPayReady && isWallet) {
      setIsShowOrPayUsing(function (param) {
        return true;
      });
      addSamsungPayButton();
    }
  }, [status, sessionObj, isSamsungPayReady]);
  var isRenderSamsungPayButton = isSamsungPayReady && isWallet;
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    areOneClickWalletsRendered(function (prev) {
      return {
        isGooglePay: prev.isGooglePay,
        isApplePay: prev.isApplePay,
        isPaypal: prev.isPaypal,
        isKlarna: prev.isKlarna,
        isSamsungPay: isRenderSamsungPayButton
      };
    });
  }, [isRenderSamsungPayButton]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
    condition: isRenderSamsungPayButton,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "w-full flex flex-row justify-center rounded-md  [&>*]:w-full [&>button]:!bg-contain",
      id: "samsungpay-container",
      style: {
        height: height.toString() + "px",
        opacity: updateSession ? "0.5" : "1.0",
        pointerEvents: updateSession ? "none" : "auto"
      }
    })
  });
}
var make = SamsungPayComponent;

/* react Not a pure module */

/***/ }),

/***/ "./src/Payments/SepaBankDebitLazy.bs.js":
/*!**********************************************!*\
  !*** ./src/Payments/SepaBankDebitLazy.bs.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_SepaBankDebit_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./SepaBankDebit.bs.js */ "./src/Payments/SepaBankDebit.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/Payments/SepaBankTransferLazy.bs.js":
/*!*************************************************!*\
  !*** ./src/Payments/SepaBankTransferLazy.bs.js ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/react/src/React.bs.js */ "./node_modules/@rescript/react/src/React.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


var make = _rescript_react_src_React_bs_js__WEBPACK_IMPORTED_MODULE_0__.lazy_(function () {
  return __webpack_require__.e(/*! import() */ "src_Payments_SepaBankTransfer_bs_js").then(__webpack_require__.bind(__webpack_require__, /*! ./SepaBankTransfer.bs.js */ "./src/Payments/SepaBankTransfer.bs.js")).then(function (m) {
    return m.default;
  });
});

/* make Not a pure module */

/***/ }),

/***/ "./src/TabCard.bs.js":
/*!***************************!*\
  !*** ./src/TabCard.bs.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _Icon_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Icon.bs.js */ "./src/Icon.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE







function TabCard(props) {
  var isActive = props.isActive;
  var paymentOption = props.paymentOption;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.configAtom);
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.optionAtom);
  var setSelectedOption = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.selectedOptionAtom);
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useMemo(function () {
    if (isActive) {
      return ["Tab--selected", "TabLabel--selected", "TabIcon--selected"];
    } else {
      return ["", "", ""];
    }
  }, [isActive]);
  var match$3 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_5__.getDisplayNameAndIcon(match$1.customMethodNames, paymentOption.paymentMethodName, paymentOption.displayName, paymentOption.icon);
  var icon = match$3[1];
  var onClick = function (param) {
    setSelectedOption(function (param) {
      return paymentOption.paymentMethodName;
    });
  };
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", {
    className: "Tab " + match$2[0] + " flex flex-col animate-slowShow",
    style: {
      cursor: "pointer",
      minWidth: "5rem",
      padding: match.themeObj.spacingUnit,
      width: "100%",
      overflowWrap: "anywhere"
    },
    disabled: match$1.readOnly,
    type: "button",
    onClick: onClick
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "TabIcon " + match$2[2]
  }, icon !== undefined ? rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__.valFromOption(icon) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Icon_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
    name: "default-card",
    size: 19
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "TabLabel " + match$2[1]
  }, paymentOption.paymentMethodName === "card" ? match.localeString.card : match$3[0]));
}
var make = TabCard;

/* react Not a pure module */

/***/ }),

/***/ "./src/Types/ApplePayTypes.bs.js":
/*!***************************************!*\
  !*** ./src/Types/ApplePayTypes.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   billingContactItemToObjMapper: () => (/* binding */ billingContactItemToObjMapper),
/* harmony export */   defaultHeadlessApplePayToken: () => (/* binding */ defaultHeadlessApplePayToken),
/* harmony export */   getPaymentRequestFromSession: () => (/* binding */ getPaymentRequestFromSession),
/* harmony export */   getTotal: () => (/* binding */ getTotal),
/* harmony export */   jsonToPaymentRequestDataType: () => (/* binding */ jsonToPaymentRequestDataType),
/* harmony export */   shippingContactItemToObjMapper: () => (/* binding */ shippingContactItemToObjMapper)
/* harmony export */ });
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE




var defaultHeadlessApplePayToken_paymentRequestData = null;
var defaultHeadlessApplePayToken = {
  paymentRequestData: defaultHeadlessApplePayToken_paymentRequestData,
  sessionTokenData: undefined
};
function getTotal(totalDict) {
  if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "type", "") === "") {
    return {
      label: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "label", ""),
      amount: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "amount", "")
    };
  } else {
    return {
      label: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "label", ""),
      type: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "type", ""),
      amount: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(totalDict, "amount", "")
    };
  }
}
function jsonToPaymentRequestDataType(jsonDict) {
  if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "merchant_identifier", "") === "") {
    return {
      countryCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "country_code", _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.defaultCountryCode),
      currencyCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "currency_code", ""),
      total: getTotal(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromObj(jsonDict, "total")),
      merchantCapabilities: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(jsonDict, "merchant_capabilities"),
      supportedNetworks: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(jsonDict, "supported_networks")
    };
  } else {
    return {
      countryCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "country_code", ""),
      currencyCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "currency_code", ""),
      total: getTotal(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromObj(jsonDict, "total")),
      merchantCapabilities: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(jsonDict, "merchant_capabilities"),
      supportedNetworks: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(jsonDict, "supported_networks"),
      merchantIdentifier: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(jsonDict, "merchant_identifier", "")
    };
  }
}
function billingContactItemToObjMapper(dict) {
  return {
    addressLines: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(dict, "addressLines"),
    administrativeArea: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "administrativeArea", ""),
    countryCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "countryCode", ""),
    familyName: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "familyName", ""),
    givenName: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "givenName", ""),
    locality: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "locality", ""),
    postalCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "postalCode", "")
  };
}
function shippingContactItemToObjMapper(dict) {
  return {
    emailAddress: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "emailAddress", ""),
    phoneNumber: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "phoneNumber", ""),
    addressLines: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(dict, "addressLines"),
    administrativeArea: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "administrativeArea", ""),
    countryCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "countryCode", ""),
    familyName: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "familyName", ""),
    givenName: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "givenName", ""),
    locality: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "locality", ""),
    postalCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "postalCode", "")
  };
}
function getPaymentRequestFromSession(sessionObj, componentName) {
  var paymentRequest = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.flatMap(sessionObj, _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__.Decode.object), {})["payment_request_data"], {}), "CamelCase");
  var requiredShippingContactFields = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getStrArray(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromJson(paymentRequest), "requiredShippingContactFields");
  if (!_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getIsExpressCheckoutComponent(componentName) && requiredShippingContactFields.length !== 0) {
    var shippingFieldsWithoutPostalAddress = requiredShippingContactFields.filter(function (item) {
      return item !== "postalAddress";
    });
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromJson(paymentRequest)["requiredShippingContactFields"] = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getArrofJsonString(shippingFieldsWithoutPostalAddress);
  }
  return paymentRequest;
}

/* Utils-OrcaPaymentPage Not a pure module */

/***/ }),

/***/ "./src/Types/GooglePayType.bs.js":
/*!***************************************!*\
  !*** ./src/Types/GooglePayType.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   baseRequest: () => (/* binding */ baseRequest),
/* harmony export */   billingContactItemToObjMapper: () => (/* binding */ billingContactItemToObjMapper),
/* harmony export */   defaultPaymentMethodData: () => (/* binding */ defaultPaymentMethodData),
/* harmony export */   defaultTokenizationData: () => (/* binding */ defaultTokenizationData),
/* harmony export */   getLabel: () => (/* binding */ getLabel),
/* harmony export */   getPaymentDataFromSession: () => (/* binding */ getPaymentDataFromSession),
/* harmony export */   getPaymentMethodData: () => (/* binding */ getPaymentMethodData),
/* harmony export */   getTokenizationData: () => (/* binding */ getTokenizationData),
/* harmony export */   itemToObjMapper: () => (/* binding */ itemToObjMapper),
/* harmony export */   jsonToPaymentRequestDataType: () => (/* binding */ jsonToPaymentRequestDataType)
/* harmony export */ });
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./SessionsType.bs.js */ "./src/Types/SessionsType.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE





function getLabel($$var) {
  switch ($$var) {
    case "Default":
      return "plain";
    case "Buy":
      return "buy";
    case "Donate":
      return "donate";
    case "Checkout":
      return "checkout";
    case "Subscribe":
      return "subscribe";
    case "Book":
      return "book";
    case "Pay":
      return "pay";
    case "Order":
      return "order";
  }
}
var defaultTokenizationData = {
  token: ""
};
var defaultPaymentMethodData_info = {};
var defaultPaymentMethodData_tokenizationData = {};
var defaultPaymentMethodData = {
  description: "",
  info: defaultPaymentMethodData_info,
  tokenizationData: defaultPaymentMethodData_tokenizationData,
  type: ""
};
function getTokenizationData(str, dict) {
  return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.map(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.flatMap(dict[str], _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__.Decode.object), function (json) {
    return {
      token: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(json, "token", "")
    };
  }), defaultTokenizationData);
}
function getPaymentMethodData(str, dict) {
  return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.map(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.flatMap(dict[str], _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__.Decode.object), function (json) {
    return {
      description: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(json, "description", ""),
      info: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getJsonFromDict(json, "info", {}),
      tokenizationData: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getJsonFromDict(json, "tokenizationData", {}),
      type: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(json, "type", "")
    };
  }), defaultPaymentMethodData);
}
function itemToObjMapper(dict) {
  return {
    paymentMethodData: getPaymentMethodData("paymentMethodData", dict)
  };
}
function jsonToPaymentRequestDataType(paymentRequest, jsonDict) {
  paymentRequest.allowedPaymentMethods = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getArray(jsonDict, "allowed_payment_methods").map(function (json) {
    return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(json, "CamelCase");
  });
  paymentRequest.transactionInfo = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getJsonFromDict(jsonDict, "transaction_info", null), "CamelCase");
  paymentRequest.merchantInfo = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getJsonFromDict(jsonDict, "merchant_info", null), "CamelCase");
  return paymentRequest;
}
function billingContactItemToObjMapper(dict) {
  return {
    address1: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "address1", ""),
    address2: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "address2", ""),
    address3: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "address3", ""),
    administrativeArea: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "administrativeArea", ""),
    countryCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "countryCode", ""),
    locality: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "locality", ""),
    name: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "name", ""),
    phoneNumber: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "phoneNumber", ""),
    postalCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "postalCode", ""),
    sortingCode: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "sortingCode", "")
  };
}
var baseRequest = {
  apiVersion: 2,
  apiVersionMinor: 0
};
function getPaymentDataFromSession(sessionObj, componentName) {
  var gpayobj = sessionObj !== undefined ? sessionObj : _SessionsType_bs_js__WEBPACK_IMPORTED_MODULE_3__.defaultToken;
  var paymentDataRequest = Object.assign({}, baseRequest);
  paymentDataRequest.allowedPaymentMethods = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.arrayJsonToCamelCase(gpayobj.allowed_payment_methods);
  paymentDataRequest.transactionInfo = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(gpayobj.transaction_info, "CamelCase");
  paymentDataRequest.merchantInfo = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(gpayobj.merchant_info, "CamelCase");
  paymentDataRequest.emailRequired = gpayobj.emailRequired;
  if (_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getIsExpressCheckoutComponent(componentName)) {
    paymentDataRequest.shippingAddressRequired = gpayobj.shippingAddressRequired;
    paymentDataRequest.shippingAddressParameters = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.transformKeys(gpayobj.shippingAddressParameters, "CamelCase");
    paymentDataRequest.callbackIntents = ["SHIPPING_ADDRESS"];
  }
  return paymentDataRequest;
}

/* Utils-OrcaPaymentPage Not a pure module */

/***/ }),

/***/ "./src/Utilities/ApplePayHelpers.bs.js":
/*!*********************************************!*\
  !*** ./src/Utilities/ApplePayHelpers.bs.js ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createApplePayTransactionInfo: () => (/* binding */ createApplePayTransactionInfo),
/* harmony export */   getApplePayFromResponse: () => (/* binding */ getApplePayFromResponse),
/* harmony export */   handleApplePayBraintreeClick: () => (/* binding */ handleApplePayBraintreeClick),
/* harmony export */   handleApplePayBraintreePaymentSession: () => (/* binding */ handleApplePayBraintreePaymentSession),
/* harmony export */   handleApplePayButtonClicked: () => (/* binding */ handleApplePayButtonClicked),
/* harmony export */   processPayment: () => (/* binding */ processPayment),
/* harmony export */   startApplePaySession: () => (/* binding */ startApplePaySession),
/* harmony export */   thirdPartyApplePayConnectors: () => (/* binding */ thirdPartyApplePayConnectors),
/* harmony export */   useHandleApplePayResponse: () => (/* binding */ useHandleApplePayResponse),
/* harmony export */   useSubmitCallback: () => (/* binding */ useSubmitCallback)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var rescript_lib_es6_belt_Option_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rescript/lib/es6/belt_Option.js */ "./node_modules/rescript/lib/es6/belt_Option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rescript/lib/es6/caml_js_exceptions.js */ "./node_modules/rescript/lib/es6/caml_js_exceptions.js");
/* harmony import */ var _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Window_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Window.bs.js */ "./src/Window.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Hooks/UtilityHooks.bs.js */ "./src/Hooks/UtilityHooks.bs.js");
/* harmony import */ var _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Types/ApplePayTypes.bs.js */ "./src/Types/ApplePayTypes.bs.js");
/* harmony import */ var _TaxCalculation_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./TaxCalculation.bs.js */ "./src/Utilities/TaxCalculation.bs.js");
/* harmony import */ var _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./DynamicFieldsUtils.bs.js */ "./src/Utilities/DynamicFieldsUtils.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


















function processPayment(bodyArr, isThirdPartyFlowOpt, isGuestCustomer, paymentMethodListValueOpt, intent, options, publishableKey, isManualRetryEnabled) {
  var isThirdPartyFlow = isThirdPartyFlowOpt !== undefined ? isThirdPartyFlowOpt : false;
  var paymentMethodListValue = paymentMethodListValueOpt !== undefined ? paymentMethodListValueOpt : _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_16__.defaultList;
  var requestBody = _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.appendedCustomerAcceptance(isGuestCustomer, paymentMethodListValue.payment_type, bodyArr);
  intent(true, requestBody, {
    return_url: options.wallets.walletReturnUrl,
    publishableKey: publishableKey
  }, undefined, isThirdPartyFlow, undefined, isManualRetryEnabled, undefined);
}
function getApplePayFromResponse(token, billingContactDict, shippingContactDict, requiredFieldsOpt, connectors, isPaymentSessionOpt, isSavedMethodsFlowOpt) {
  var requiredFields = requiredFieldsOpt !== undefined ? requiredFieldsOpt : [];
  var isPaymentSession = isPaymentSessionOpt !== undefined ? isPaymentSessionOpt : false;
  var isSavedMethodsFlow = isSavedMethodsFlowOpt !== undefined ? isSavedMethodsFlowOpt : false;
  var billingContact = _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__.billingContactItemToObjMapper(billingContactDict);
  var shippingContact = _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__.shippingContactItemToObjMapper(shippingContactDict);
  var requiredFieldsBody = isPaymentSession || isSavedMethodsFlow ? _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.getApplePayRequiredFields(billingContact, shippingContact, undefined) : _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.getApplePayRequiredFields(billingContact, shippingContact, requiredFields);
  var bodyDict = _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_9__.applePayBody(token, connectors);
  return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.mergeAndFlattenToTuples(bodyDict, requiredFieldsBody);
}
function startApplePaySession(paymentRequest, applePaySessionRef, applePayPresent, logger, callBackFunc, resolvePromise, clientSecret, publishableKey, isTaxCalculationEnabledOpt) {
  var isTaxCalculationEnabled = isTaxCalculationEnabledOpt !== undefined ? isTaxCalculationEnabledOpt : false;
  var ssn = new ApplePaySession(3, paymentRequest);
  var session = applePaySessionRef.contents;
  if (!(session == null)) {
    try {
      session.abort();
    } catch (raw_error) {
      var error = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_error);
      console.error("Abort fail", error);
    }
  }
  applePaySessionRef.contents = ssn;
  ssn.onvalidatemerchant = function (_event) {
    var merchantSession = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.transformKeys(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(rescript_lib_es6_belt_Option_js__WEBPACK_IMPORTED_MODULE_3__.flatMap(applePayPresent, _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_2__.Decode.object), {})["session_token_data"], {}), "CamelCase");
    ssn.completeMerchantValidation(merchantSession);
  };
  ssn.onshippingcontactselected = function (shippingAddressChangeEvent) {
    var currentTotal = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(paymentRequest), "total");
    var label = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(currentTotal, "label", "apple");
    var currentAmount = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(currentTotal, "amount", "0.00");
    var type = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(currentTotal, "type", "final");
    var oldTotal = {
      label: label,
      amount: currentAmount,
      type: type
    };
    var currentOrderDetails_newLineItems = [oldTotal];
    var currentOrderDetails = {
      newTotal: oldTotal,
      newLineItems: currentOrderDetails_newLineItems
    };
    if (isTaxCalculationEnabled) {
      var newShippingContact = _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__.shippingContactItemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(shippingAddressChangeEvent.shippingContact));
      var newShippingAddress = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getJsonFromArrayOfJson([["state", newShippingContact.administrativeArea], ["country", newShippingContact.countryCode], ["zip", newShippingContact.postalCode]]);
      return _TaxCalculation_bs_js__WEBPACK_IMPORTED_MODULE_14__.calculateTax(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getJsonFromArrayOfJson([["address", newShippingAddress]]), logger, clientSecret, publishableKey, "apple_pay", undefined).then(function (response) {
        var taxCalculationResponse = _TaxCalculation_bs_js__WEBPACK_IMPORTED_MODULE_14__.taxResponseToObjMapper(response);
        if (taxCalculationResponse === undefined) {
          return ssn.completeShippingContactSelection(currentOrderDetails);
        }
        var netAmount = taxCalculationResponse.net_amount;
        var ordertaxAmount = taxCalculationResponse.order_tax_amount;
        var shippingCost = taxCalculationResponse.shipping_cost;
        var newTotal_amount = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.minorUnitToString(netAmount);
        var newTotal = {
          label: label,
          amount: newTotal_amount,
          type: type
        };
        var newLineItems = [{
          label: "Subtotal",
          amount: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.minorUnitToString((netAmount - ordertaxAmount | 0) - shippingCost | 0),
          type: "final"
        }, {
          label: "Order Tax Amount",
          amount: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.minorUnitToString(ordertaxAmount),
          type: "final"
        }, {
          label: "Shipping Cost",
          amount: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.minorUnitToString(shippingCost),
          type: "final"
        }];
        var updatedOrderDetails = {
          newTotal: newTotal,
          newLineItems: newLineItems
        };
        ssn.completeShippingContactSelection(updatedOrderDetails);
      });
    }
    ssn.completeShippingContactSelection(currentOrderDetails);
    return Promise.resolve();
  };
  ssn.onpaymentauthorized = function ($$event) {
    ssn.completePayment({
      status: ssn.STATUS_SUCCESS
    });
    applePaySessionRef.contents = null;
    logger.setLogInfo("Payment Data Filled: New Payment Method", "PAYMENT_DATA_FILLED", undefined, undefined, undefined, undefined, "APPLE_PAY");
    var payment = $$event.payment;
    callBackFunc(payment);
  };
  ssn.oncancel = function () {
    applePaySessionRef.contents = null;
    logger.setLogError("Apple Pay Payment Cancelled", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
    resolvePromise(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.handleFailureResponse("ApplePay Session Cancelled", "apple_pay"));
  };
  ssn.begin();
}
function useHandleApplePayResponse(connectors, intent, setApplePayClickedOpt, syncPaymentOpt, isInvokeSDKFlowOpt, isSavedMethodsFlowOpt, isWalletOpt, requiredFieldsBodyOpt) {
  var setApplePayClicked = setApplePayClickedOpt !== undefined ? setApplePayClickedOpt : function (param) {};
  var syncPayment = syncPaymentOpt !== undefined ? syncPaymentOpt : function () {};
  var isInvokeSDKFlow = isInvokeSDKFlowOpt !== undefined ? isInvokeSDKFlowOpt : true;
  var isSavedMethodsFlow = isSavedMethodsFlowOpt !== undefined ? isSavedMethodsFlowOpt : false;
  var isWallet = isWalletOpt !== undefined ? isWalletOpt : true;
  var requiredFieldsBody = requiredFieldsBodyOpt !== undefined ? requiredFieldsBodyOpt : {};
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.optionAtom);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.keys);
  var publishableKey = match.publishableKey;
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.paymentMethodListValue);
  var logger = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.loggerAtom);
  var isGuestCustomer = _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_12__.useIsGuestCustomer();
  var paymentMethodTypes = _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_15__.usePaymentMethodTypeFromList(paymentMethodListValue, "wallet", "apple_pay");
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.isManualRetryEnabled);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handleApplePayMessages = function (ev) {
      var json = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.safeParse(ev.data);
      try {
        var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(json);
        if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["applePayPaymentToken"])) {
          var token = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.getOr(dict["applePayPaymentToken"], {});
          var billingContactDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(dict, "applePayBillingContact");
          var shippingContactDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(dict, "applePayShippingContact");
          var applePayBody = getApplePayFromResponse(token, billingContactDict, shippingContactDict, paymentMethodTypes.required_fields, connectors, undefined, isSavedMethodsFlow);
          var bodyArr = isWallet ? applePayBody : _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.mergeAndFlattenToTuples(applePayBody, requiredFieldsBody);
          return processPayment(bodyArr, false, isGuestCustomer, paymentMethodListValue, intent, options, publishableKey, isManualRetryEnabled);
        }
        if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["showApplePayButton"])) {
          setApplePayClicked(function (param) {
            return false;
          });
          if (isSavedMethodsFlow || !isWallet) {
            return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.postFailedSubmitResponse("server_error", "Something went wrong");
          } else {
            return;
          }
        }
        if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["applePaySyncPayment"])) {
          return syncPayment();
        }
        if (!_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_4__.isSome(dict["applePayBraintreeSuccess"])) {
          return;
        }
        var token$1 = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(dict, "token", "");
        return processPayment(_PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_9__.applePayThirdPartySdkBody(connectors, token$1), true, isGuestCustomer, paymentMethodListValue, intent, options, publishableKey, isManualRetryEnabled);
      } catch (exn) {
        return logger.setLogError("Error in parsing Apple Pay Data", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
      }
    };
    window.addEventListener("message", handleApplePayMessages);
    return function () {
      _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, [["applePaySessionAbort", true]]);
      window.removeEventListener("message", handleApplePayMessages);
    };
  }, [isInvokeSDKFlow, processPayment, isManualRetryEnabled, isWallet, requiredFieldsBody]);
}
function handleApplePayButtonClicked(sessionObj, componentName, paymentMethodListValue) {
  var paymentRequest = _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__.getPaymentRequestFromSession(sessionObj, componentName);
  var authToken = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getOptionsDict(sessionObj), "session_token_data"), "secrets"), "display", "");
  var connector = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getOptionsDict(sessionObj), "connector", "");
  var message = [["applePayButtonClicked", true], ["applePayPaymentRequest", paymentRequest], ["isTaxCalculationEnabled", paymentMethodListValue.is_tax_calculation_enabled], ["componentName", componentName], ["authToken", authToken], ["connector", connector]];
  _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, message);
}
function useSubmitCallback(isWallet, sessionObj, componentName) {
  var areRequiredFieldsValid = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.areRequiredFieldsValid);
  var areRequiredFieldsEmpty = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.areRequiredFieldsEmpty);
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.optionAtom);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_10__.configAtom);
  var localeString = match.localeString;
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_11__.paymentMethodListValue);
  return react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    if (isWallet) {
      return;
    }
    var json = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_8__.itemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromJson(json));
    if (confirm.doSubmit && areRequiredFieldsValid && !areRequiredFieldsEmpty) {
      if (!options.readOnly) {
        return handleApplePayButtonClicked(sessionObj, componentName, paymentMethodListValue);
      } else {
        return;
      }
    } else if (areRequiredFieldsEmpty) {
      return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.postFailedSubmitResponse("validation_error", localeString.enterFieldsText);
    } else if (!areRequiredFieldsValid) {
      return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.postFailedSubmitResponse("validation_error", localeString.enterValidDetailsText);
    } else {
      return;
    }
  }, [areRequiredFieldsValid, areRequiredFieldsEmpty, isWallet, sessionObj, componentName]);
}
function createApplePayTransactionInfo(jsonDict) {
  return {
    countryCode: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(jsonDict, "countryCode", _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.defaultCountryCode),
    currencyCode: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getString(jsonDict, "currencyCode", ""),
    total: _Types_ApplePayTypes_bs_js__WEBPACK_IMPORTED_MODULE_13__.getTotal(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getDictFromObj(jsonDict, "total")),
    merchantCapabilities: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getStrArray(jsonDict, "merchantCapabilities"),
    supportedNetworks: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.getStrArray(jsonDict, "supportedNetworks")
  };
}
var thirdPartyApplePayConnectors = ["braintree"];
function handleApplePayBraintreePaymentSession(applePayPaymentRequest, applePayInstance, onError, onSuccess) {
  try {
    var transactionInfo = createApplePayTransactionInfo(applePayPaymentRequest);
    var paymentRequest = applePayInstance.createPaymentRequest(transactionInfo);
    var sessions = new ApplePaySession(3, paymentRequest);
    sessions.onvalidatemerchant = function ($$event) {
      applePayInstance.performValidation({
        validationURL: $$event.validationURL,
        displayName: transactionInfo.total.label
      }, function (err, merchantSession) {
        if (err == null) {
          return sessions.completeMerchantValidation(merchantSession);
        } else {
          onError(err);
          return sessions.abort();
        }
      });
    };
    sessions.onpaymentauthorized = function ($$event) {
      applePayInstance.tokenize({
        token: $$event.payment.token,
        billingContact: null,
        shippingContact: null
      }, function (err, payload) {
        var ssn = window.ApplePaySession;
        if (ssn == null) {
          return onError("ApplePay session is null in onpaymentauthorized.");
        } else if (err == null) {
          sessions.completePayment(ssn.STATUS_SUCCESS);
          return onSuccess(payload.nonce);
        } else {
          sessions.completePayment(ssn.STATUS_FAILURE);
          return onError("ApplePay Tokenization Failed");
        }
      });
    };
    sessions.oncancel = function () {
      onError("Apple Pay Payment Cancelled.");
    };
    return sessions.begin();
  } catch (raw_err) {
    var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_err);
    return onError(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.formatException(err));
  }
}
function handleApplePayBraintreeClick(authorization, applePayPaymentRequest, selectorString, logger, $$event) {
  _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, [["fullscreen", true], ["param", "paymentloader"], ["iframeId", selectorString]]);
  var onSuccess = function (token) {
    if (token === "") {
      _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, [["fullscreen", false], ["param", "paymentloader"], ["iframeId", selectorString]]);
      _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.postFailedSubmitResponse("validation_error", "ApplePay Braintree nonce is empty");
      return logger.setLogError("ApplePay Braintree nonce is empty", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
    } else {
      logger.setLogInfo("ApplePay Braintree payment Successfull", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
      return _Window_bs_js__WEBPACK_IMPORTED_MODULE_7__.sendPostMessage($$event.source, Object.fromEntries([["applePayBraintreeSuccess", true], ["token", token]]));
    }
  };
  var onError = function (err) {
    logger.setLogError(JSON.stringify(err), "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
    _Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.messageParentWindow(undefined, [["fullscreen", false], ["param", "paymentloader"], ["iframeId", selectorString]]);
    _Window_bs_js__WEBPACK_IMPORTED_MODULE_7__.sendPostMessage($$event.source, Object.fromEntries([["showApplePayButton", true]]));
  };
  try {
    braintree.client.create({
      authorization: authorization
    }, function (err, clientInstance) {
      if (!(err == null)) {
        return onError(err);
      }
      try {
        logger.setLogInfo("Braintree ApplePay instance created successfully", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
        braintree.applePay.create({
          client: clientInstance
        }, function (err, applePayInstance) {
          if (err == null) {
            logger.setLogInfo("Braintree ApplePay payment session started", "APPLE_PAY_FLOW", undefined, undefined, undefined, undefined, "APPLE_PAY");
            return handleApplePayBraintreePaymentSession(applePayPaymentRequest, applePayInstance, onError, onSuccess);
          } else {
            return onError(err);
          }
        });
        return;
      } catch (raw_err) {
        var err$1 = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_err);
        return onError(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.formatException(err$1));
      }
    });
    return;
  } catch (raw_err) {
    var err = rescript_lib_es6_caml_js_exceptions_js__WEBPACK_IMPORTED_MODULE_5__.internalToOCamlException(raw_err);
    return onError(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_6__.formatException(err));
  }
}

/* react Not a pure module */

/***/ }),

/***/ "./src/Utilities/GooglePayHelpers.bs.js":
/*!**********************************************!*\
  !*** ./src/Utilities/GooglePayHelpers.bs.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getGooglePayBodyFromResponse: () => (/* binding */ getGooglePayBodyFromResponse),
/* harmony export */   handleGooglePayClicked: () => (/* binding */ handleGooglePayClicked),
/* harmony export */   processPayment: () => (/* binding */ processPayment),
/* harmony export */   useHandleGooglePayResponse: () => (/* binding */ useHandleGooglePayResponse),
/* harmony export */   useSubmitCallback: () => (/* binding */ useSubmitCallback)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Hooks/UtilityHooks.bs.js */ "./src/Hooks/UtilityHooks.bs.js");
/* harmony import */ var _Types_GooglePayType_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Types/GooglePayType.bs.js */ "./src/Types/GooglePayType.bs.js");
/* harmony import */ var _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./DynamicFieldsUtils.bs.js */ "./src/Utilities/DynamicFieldsUtils.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE













function getGooglePayBodyFromResponse(gPayResponse, isGuestCustomer, paymentMethodListValueOpt, connectors, requiredFieldsOpt, isPaymentSessionOpt, isSavedMethodsFlowOpt) {
  var paymentMethodListValue = paymentMethodListValueOpt !== undefined ? paymentMethodListValueOpt : _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_11__.defaultList;
  var requiredFields = requiredFieldsOpt !== undefined ? requiredFieldsOpt : [];
  var isPaymentSession = isPaymentSessionOpt !== undefined ? isPaymentSessionOpt : false;
  var isSavedMethodsFlow = isSavedMethodsFlowOpt !== undefined ? isSavedMethodsFlowOpt : false;
  var obj = _Types_GooglePayType_bs_js__WEBPACK_IMPORTED_MODULE_9__.itemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(gPayResponse));
  var gPayBody = _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.appendedCustomerAcceptance(isGuestCustomer, paymentMethodListValue.payment_type, _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_5__.gpayBody(obj, connectors));
  var billingContact = _Types_GooglePayType_bs_js__WEBPACK_IMPORTED_MODULE_9__.billingContactItemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getJsonObjectFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(obj.paymentMethodData.info), "billingAddress")));
  var shippingContact = _Types_GooglePayType_bs_js__WEBPACK_IMPORTED_MODULE_9__.billingContactItemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getJsonObjectFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(gPayResponse), "shippingAddress")));
  var email = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(gPayResponse), "email", "");
  var requiredFieldsBody = isPaymentSession || isSavedMethodsFlow ? _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.getGooglePayRequiredFields(billingContact, shippingContact, undefined, email) : _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.getGooglePayRequiredFields(billingContact, shippingContact, requiredFields, email);
  return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.mergeAndFlattenToTuples(gPayBody, requiredFieldsBody);
}
function processPayment(body, isThirdPartyFlowOpt, intent, options, publishableKey, isManualRetryEnabled) {
  var isThirdPartyFlow = isThirdPartyFlowOpt !== undefined ? isThirdPartyFlowOpt : false;
  intent(true, body, {
    return_url: options.wallets.walletReturnUrl,
    publishableKey: publishableKey
  }, undefined, isThirdPartyFlow, undefined, isManualRetryEnabled, undefined);
}
function useHandleGooglePayResponse(connectors, intent, isSavedMethodsFlowOpt, isWalletOpt, requiredFieldsBodyOpt) {
  var isSavedMethodsFlow = isSavedMethodsFlowOpt !== undefined ? isSavedMethodsFlowOpt : false;
  var isWallet = isWalletOpt !== undefined ? isWalletOpt : true;
  var requiredFieldsBody = requiredFieldsBodyOpt !== undefined ? requiredFieldsBodyOpt : {};
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.optionAtom);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.keys);
  var publishableKey = match.publishableKey;
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.isManualRetryEnabled);
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_7__.paymentMethodListValue);
  var isGuestCustomer = _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_8__.useIsGuestCustomer();
  var paymentMethodTypes = _DynamicFieldsUtils_bs_js__WEBPACK_IMPORTED_MODULE_10__.usePaymentMethodTypeFromList(paymentMethodListValue, "wallet", "google_pay");
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handle = function (ev) {
      var json = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.safeParse(ev.data);
      var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(json);
      if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.isSome(dict["gpayResponse"])) {
        var metadata = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getJsonObjectFromDict(dict, "gpayResponse");
        var body = getGooglePayBodyFromResponse(metadata, isGuestCustomer, paymentMethodListValue, connectors, paymentMethodTypes.required_fields, undefined, isSavedMethodsFlow);
        var googlePayBody = isWallet ? body : _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.mergeAndFlattenToTuples(body, requiredFieldsBody);
        processPayment(googlePayBody, false, intent, options, publishableKey, isManualRetryEnabled);
      }
      if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.isSome(dict["gpayError"])) {
        _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["fullscreen", false]]);
        if (isSavedMethodsFlow || !isWallet) {
          return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.postFailedSubmitResponse("server_error", "Something went wrong");
        } else {
          return;
        }
      }
    };
    window.addEventListener("message", handle);
    return function () {
      window.removeEventListener("message", handle);
    };
  }, [paymentMethodTypes, isManualRetryEnabled, requiredFieldsBody, isWallet]);
}
function handleGooglePayClicked(sessionObj, componentName, iframeId, readOnly) {
  var paymentDataRequest = _Types_GooglePayType_bs_js__WEBPACK_IMPORTED_MODULE_9__.getPaymentDataFromSession(sessionObj, componentName);
  _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["fullscreen", true], ["param", "paymentloader"], ["iframeId", iframeId]]);
  if (!readOnly) {
    return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["GpayClicked", true], ["GpayPaymentDataRequest", paymentDataRequest]]);
  }
}
function useSubmitCallback(isWallet, sessionObj, componentName) {
  var areRequiredFieldsValid = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.areRequiredFieldsValid);
  var areRequiredFieldsEmpty = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.areRequiredFieldsEmpty);
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.optionAtom);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.configAtom);
  var localeString = match.localeString;
  var match$1 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_6__.keys);
  var iframeId = match$1.iframeId;
  return react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    if (isWallet) {
      return;
    }
    var json = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_4__.itemToObjMapper(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(json));
    if (confirm.doSubmit && areRequiredFieldsValid && !areRequiredFieldsEmpty) {
      return handleGooglePayClicked(sessionObj, componentName, iframeId, options.readOnly);
    } else if (areRequiredFieldsEmpty) {
      return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.postFailedSubmitResponse("validation_error", localeString.enterFieldsText);
    } else if (!areRequiredFieldsValid) {
      return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.postFailedSubmitResponse("validation_error", localeString.enterValidDetailsText);
    } else {
      return;
    }
  }, [areRequiredFieldsValid, areRequiredFieldsEmpty, isWallet, sessionObj, componentName, iframeId]);
}

/* react Not a pure module */

/***/ }),

/***/ "./src/Utilities/SamsungPayHelpers.bs.js":
/*!***********************************************!*\
  !*** ./src/Utilities/SamsungPayHelpers.bs.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPaymentMethodData: () => (/* binding */ getPaymentMethodData),
/* harmony export */   getSamsungPayBodyFromResponse: () => (/* binding */ getSamsungPayBodyFromResponse),
/* harmony export */   getTransactionDetail: () => (/* binding */ getTransactionDetail),
/* harmony export */   handleSamsungPayClicked: () => (/* binding */ handleSamsungPayClicked),
/* harmony export */   itemToObjMapper: () => (/* binding */ itemToObjMapper),
/* harmony export */   useHandleSamsungPayResponse: () => (/* binding */ useHandleSamsungPayResponse)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PaymentBody.bs.js */ "./src/Utilities/PaymentBody.bs.js");
/* harmony import */ var _RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Hooks/UtilityHooks.bs.js */ "./src/Hooks/UtilityHooks.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE









function getTransactionDetail(dict) {
  var amountDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromDict(dict, "amount");
  var merchantDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromDict(dict, "merchant");
  return {
    orderNumber: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(dict, "order_number", ""),
    merchant: {
      name: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(merchantDict, "name", ""),
      url: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(merchantDict, "url", ""),
      countryCode: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(merchantDict, "country_code", "")
    },
    amount: {
      option: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(amountDict, "option", ""),
      currency: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(amountDict, "currency_code", ""),
      total: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(amountDict, "total", "")
    }
  };
}
function handleSamsungPayClicked(sessionObj, componentName, iframeId, readOnly) {
  _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["fullscreen", true], ["param", "paymentloader"], ["iframeId", iframeId], ["componentName", componentName]]);
  if (!readOnly) {
    return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["SamsungPayClicked", true], ["SPayPaymentDataRequest", getTransactionDetail(sessionObj)]]);
  }
}
function getPaymentMethodData(dict) {
  var threeDSDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromDict(dict, "3DS");
  return {
    method: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(dict, "method", ""),
    recurring_payment: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getBool(dict, "recurring_payment", false),
    card_brand: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(dict, "card_brand", ""),
    card_last4digits: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(dict, "card_last4digits", ""),
    "3_d_s": {
      type: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(threeDSDict, "type", ""),
      version: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(threeDSDict, "version", ""),
      data: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(threeDSDict, "data", "")
    }
  };
}
function itemToObjMapper(dict) {
  return {
    paymentMethodData: getPaymentMethodData(dict)
  };
}
function getSamsungPayBodyFromResponse(sPayResponse) {
  var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(sPayResponse);
  return {
    paymentMethodData: getPaymentMethodData(dict)
  };
}
function useHandleSamsungPayResponse(intent, isSavedMethodsFlowOpt, isWalletOpt) {
  var isSavedMethodsFlow = isSavedMethodsFlowOpt !== undefined ? isSavedMethodsFlowOpt : false;
  var isWallet = isWalletOpt !== undefined ? isWalletOpt : true;
  var options = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.optionAtom);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.keys);
  var publishableKey = match.publishableKey;
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.isManualRetryEnabled);
  var paymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__.paymentMethodListValue);
  var isGuestCustomer = _Hooks_UtilityHooks_bs_js__WEBPACK_IMPORTED_MODULE_7__.useIsGuestCustomer();
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var handleSamsung = function (ev) {
      var json = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.safeParse(ev.data);
      var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(json);
      if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.isSome(dict["samsungPayResponse"])) {
        var metadata = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getJsonObjectFromDict(dict, "samsungPayResponse");
        var getBody = getSamsungPayBodyFromResponse(metadata);
        var body = _PaymentBody_bs_js__WEBPACK_IMPORTED_MODULE_4__.samsungPayBody(getBody.paymentMethodData);
        var finalBody = _PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__.appendedCustomerAcceptance(isGuestCustomer, paymentMethodListValue.payment_type, body);
        intent(false, finalBody, {
          return_url: options.wallets.walletReturnUrl,
          publishableKey: publishableKey
        }, undefined, undefined, undefined, isManualRetryEnabled, undefined);
      }
      if (_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.isSome(dict["samsungPayError"])) {
        _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.messageParentWindow(undefined, [["fullscreen", false]]);
        if (isSavedMethodsFlow || !isWallet) {
          return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.postFailedSubmitResponse("server_error", "Something went wrong");
        } else {
          return;
        }
      }
    };
    window.addEventListener("message", handleSamsung);
    return function () {
      window.removeEventListener("message", handleSamsung);
    };
  }, []);
}

/* react Not a pure module */

/***/ }),

/***/ "./src/Utilities/TaxCalculation.bs.js":
/*!********************************************!*\
  !*** ./src/Utilities/TaxCalculation.bs.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   calculateTax: () => (/* binding */ calculateTax),
/* harmony export */   taxResponseToObjMapper: () => (/* binding */ taxResponseToObjMapper)
/* harmony export */ });
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE






function taxResponseToObjMapper(resp) {
  return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.map(_rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__.Decode.object(resp), function (dict) {
    return {
      payment_id: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getString(dict, "payment_id", ""),
      net_amount: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getInt(dict, "net_amount", 0),
      order_tax_amount: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getInt(dict, "order_tax_amount", 0),
      shipping_cost: _Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getInt(dict, "shipping_cost", 0)
    };
  });
}
function calculateTax(shippingAddress, logger, clientSecret, publishableKey, paymentMethodType, sessionIdOpt) {
  var sessionId = sessionIdOpt !== undefined ? rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_1__.valFromOption(sessionIdOpt) : undefined;
  return _PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_4__.calculateTax(publishableKey, clientSecret, paymentMethodType, shippingAddress, logger, "", sessionId);
}

/* Utils-OrcaPaymentPage Not a pure module */

/***/ }),

/***/ "./src/Utilities/VaultHelpers.bs.js":
/*!******************************************!*\
  !*** ./src/Utilities/VaultHelpers.bs.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getHyperswitchVaultDetails: () => (/* binding */ getHyperswitchVaultDetails),
/* harmony export */   getVGSVaultDetails: () => (/* binding */ getVGSVaultDetails),
/* harmony export */   getVaultModeFromName: () => (/* binding */ getVaultModeFromName),
/* harmony export */   getVaultName: () => (/* binding */ getVaultName),
/* harmony export */   getVaultNameFromMode: () => (/* binding */ getVaultNameFromMode)
/* harmony export */ });
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Utils.bs.js */ "./src/Utilities/Utils.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE



function getVaultModeFromName(val) {
  switch (val) {
    case "hyperswitch_vault":
      return "Hyperswitch";
    case "vgs":
      return "VeryGoodSecurity";
    default:
      return "None";
  }
}
function getVaultNameFromMode(val) {
  switch (val) {
    case "VeryGoodSecurity":
      return "vgs";
    case "Hyperswitch":
      return "hyperswitch_vault";
    case "None":
      return "";
  }
}
function getVaultName(sessionObj) {
  if (typeof sessionObj !== "object") {
    return "";
  }
  if (sessionObj.TAG !== "Loaded") {
    return "";
  }
  var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromJson(sessionObj._0);
  var vaultDetailsDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromDict(dict, "vault_details");
  var keys = Object.keys(vaultDetailsDict);
  return _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_0__.getOr(keys[0], "");
}
function getVGSVaultDetails(sessionObj, vaultName) {
  if (typeof sessionObj !== "object") {
    return {
      vaultId: "",
      vaultEnv: ""
    };
  }
  if (sessionObj.TAG !== "Loaded") {
    return {
      vaultId: "",
      vaultEnv: ""
    };
  }
  var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromJson(sessionObj._0);
  var vgsVaultDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromDict(dict, "vault_details"), vaultName);
  var vaultId = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getString(vgsVaultDict, "external_vault_id", "");
  var vaultEnv = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getString(vgsVaultDict, "sdk_env", "");
  return {
    vaultId: vaultId,
    vaultEnv: vaultEnv
  };
}
function getHyperswitchVaultDetails(sessionObj) {
  if (typeof sessionObj !== "object") {
    return {
      pmSessionId: "",
      pmClientSecret: "",
      vaultPublishableKey: "",
      vaultProfileId: ""
    };
  }
  if (sessionObj.TAG !== "Loaded") {
    return {
      pmSessionId: "",
      pmClientSecret: "",
      vaultPublishableKey: "",
      vaultProfileId: ""
    };
  }
  var dict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromJson(sessionObj._0);
  var hyperswitchVaultDict = _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromDict(_Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getDictFromDict(dict, "vault_details"), "hyperswitch_vault");
  var getVaultValue = function (key) {
    return _Utils_bs_js__WEBPACK_IMPORTED_MODULE_1__.getString(hyperswitchVaultDict, key, "");
  };
  var pmSessionId = getVaultValue("payment_method_session_id");
  var pmClientSecret = getVaultValue("client_secret");
  var vaultPublishableKey = getVaultValue("publishable_key");
  var vaultProfileId = getVaultValue("profile_id");
  return {
    pmSessionId: pmSessionId,
    pmClientSecret: pmClientSecret,
    vaultPublishableKey: vaultPublishableKey,
    vaultProfileId: vaultProfileId
  };
}

/* Utils-OrcaPaymentPage Not a pure module */

/***/ }),

/***/ "./src/VGSVault/VGSConstants.bs.js":
/*!*****************************************!*\
  !*** ./src/VGSVault/VGSConstants.bs.js ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cardCvcOptions: () => (/* binding */ cardCvcOptions),
/* harmony export */   cardExpiryOptions: () => (/* binding */ cardExpiryOptions),
/* harmony export */   cardNumberOptions: () => (/* binding */ cardNumberOptions),
/* harmony export */   fieldsCssValue: () => (/* binding */ fieldsCssValue),
/* harmony export */   vgsScriptURL: () => (/* binding */ vgsScriptURL)
/* harmony export */ });
// Generated by ReScript, PLEASE EDIT WITH CARE

var fieldsCssValue = {
  "font-size": "16px",
  "font-weight": "400",
  opacity: "0.6"
};
var cardNumberOptions_validations = ["required", "validCardNumber"];
var cardNumberOptions_showCardIcon = true;
var cardNumberOptions_css = fieldsCssValue;
var cardNumberOptions = {
  type: "card-number",
  name: "card_number",
  placeholder: "1234 1234 1234 1234",
  validations: cardNumberOptions_validations,
  showCardIcon: cardNumberOptions_showCardIcon,
  css: cardNumberOptions_css
};
function cardExpiryOptions(expiryPlaceholder, vault) {
  return {
    type: "card-expiration-date",
    name: "card_exp",
    placeholder: expiryPlaceholder,
    validations: ["required", "validCardExpirationDate"],
    showCardIcon: false,
    css: fieldsCssValue,
    yearLength: 2,
    serializers: [vault.SERIALIZERS.separate({
      monthName: "card_exp_month",
      yearName: "card_exp_year"
    })]
  };
}
var cardCvcOptions_validations = ["required", "validCardSecurityCode"];
var cardCvcOptions_showCardIcon = true;
var cardCvcOptions_css = fieldsCssValue;
var cardCvcOptions = {
  type: "card-security-code",
  name: "card_cvc",
  placeholder: "123",
  validations: cardCvcOptions_validations,
  showCardIcon: cardCvcOptions_showCardIcon,
  css: cardCvcOptions_css
};
var vgsScriptURL = "https://js.verygoodvault.com/vgs-collect/2.27.2/vgs-collect.js";

/* No side effect */

/***/ }),

/***/ "./src/VGSVault/VGSHelpers.bs.js":
/*!***************************************!*\
  !*** ./src/VGSVault/VGSHelpers.bs.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getErrorStr: () => (/* binding */ getErrorStr),
/* harmony export */   getExpiryToken: () => (/* binding */ getExpiryToken),
/* harmony export */   getTokenizedData: () => (/* binding */ getTokenizedData),
/* harmony export */   handleVGSField: () => (/* binding */ handleVGSField),
/* harmony export */   submitUserError: () => (/* binding */ submitUserError),
/* harmony export */   vgsErrorHandler: () => (/* binding */ vgsErrorHandler)
/* harmony export */ });
/* harmony import */ var _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @rescript/core/src/Core__JSON.bs.js */ "./node_modules/@rescript/core/src/Core__JSON.bs.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../CardUtils.bs.js */ "./src/CardUtils.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE





function handleVGSField(field, setFocus, setError) {
  if (field !== undefined) {
    field.on("focus", function (param) {
      setFocus(function (param) {
        return true;
      });
      setError(function (param) {
        return "";
      });
    });
    return field.on("blur", function (param) {
      setFocus(function (param) {
        return false;
      });
    });
  }
}
function getExpiryToken(dict) {
  var cardExpiry = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromDict(dict, "card_exp");
  return {
    month: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(cardExpiry, "card_exp_month", ""),
    year: _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(cardExpiry, "card_exp_year", "")
  };
}
function getTokenizedData(data) {
  var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getDictFromJson(data);
  var expiryDetails = getExpiryToken(dict);
  var cardNumber = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "card_number", "");
  var cardCvc = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getString(dict, "card_cvc", "");
  var prefix = _CardUtils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getExpiryYearPrefix();
  return [cardNumber, expiryDetails.month, prefix + expiryDetails.year, cardCvc];
}
function getErrorStr(fieldname, emptyOpt, localeString) {
  var empty = emptyOpt !== undefined ? emptyOpt : false;
  switch (fieldname) {
    case "card_cvc":
      if (empty) {
        return localeString.cvcNumberEmptyText;
      } else {
        return localeString.inCompleteCVCErrorText;
      }
    case "card_exp":
      if (empty) {
        return localeString.cardExpiryDateEmptyText;
      } else {
        return localeString.inValidExpiryErrorText;
      }
    case "card_number":
      if (empty) {
        return localeString.cardNumberEmptyText;
      } else {
        return localeString.enterValidCardNumberErrorText;
      }
    default:
      return "";
  }
}
function submitUserError(message) {
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.postFailedSubmitResponse("validation_error", message);
}
function vgsErrorHandler(dict, fieldname, isSubmitOpt, localeString) {
  var isSubmit = isSubmitOpt !== undefined ? isSubmitOpt : false;
  var emptyErr = getErrorStr(fieldname, true, localeString);
  var invalidErr = getErrorStr(fieldname, undefined, localeString);
  var dataDict = _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.flatMap(dict[fieldname], _rescript_core_src_Core_JSON_bs_js__WEBPACK_IMPORTED_MODULE_0__.Decode.object);
  var getBoolFromDictOpt = function (optDict, key, fallbackOpt) {
    var fallback = fallbackOpt !== undefined ? fallbackOpt : true;
    return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.getBool(_rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_1__.getOr(optDict, {}), key, fallback);
  };
  var isFocused = getBoolFromDictOpt(dataDict, "isFocused", undefined);
  var isEmpty = getBoolFromDictOpt(dataDict, "isEmpty", undefined);
  var isValid = getBoolFromDictOpt(dataDict, "isValid", undefined);
  if (isFocused) {
    return "";
  } else if (isEmpty) {
    if (isSubmit) {
      _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.postFailedSubmitResponse("validation_error", localeString.enterFieldsText);
      return emptyErr;
    } else {
      return "";
    }
  } else if (isValid) {
    return "";
  } else {
    _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_2__.postFailedSubmitResponse("validation_error", localeString.enterValidDetailsText);
    return invalidErr;
  }
}

/* Utils-OrcaPaymentPage Not a pure module */

/***/ }),

/***/ "./src/VGSVault/VGSInputComponent.bs.js":
/*!**********************************************!*\
  !*** ./src/VGSVault/VGSInputComponent.bs.js ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/caml_option.js */ "./node_modules/rescript/lib/es6/caml_option.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Components_ErrorComponent_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../Components/ErrorComponent.bs.js */ "./src/Components/ErrorComponent.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE







function VGSInputComponent(props) {
  var __isFocused = props.isFocused;
  var __id = props.id;
  var __fieldName = props.fieldName;
  var fieldName = __fieldName !== undefined ? __fieldName : "";
  var id = __id !== undefined ? __id : "";
  var isFocused = __isFocused !== undefined ? __isFocused : false;
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_4__.configAtom);
  var themeObj = match.themeObj;
  var config = match.config;
  var match$1 = config.appearance;
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "input-empty";
  });
  var setFocusClass = match$2[1];
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    setFocusClass(function (param) {
      if (isFocused) {
        return "VGSField--focused";
      } else {
        return "input-empty";
      }
    });
  }, [isFocused]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col w-full",
    style: {
      color: themeObj.colorText
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_3__.make, {
    condition: fieldName.length > 0 && config.appearance.labels === "Above" && match$1.innerLayout === "Spaced",
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      "aria-hidden": true,
      className: "Label Label--empty",
      style: {
        fontSize: themeObj.fontSizeLg,
        fontWeight: themeObj.fontWeightNormal,
        marginBottom: "5px",
        opacity: "0.6"
      }
    }, fieldName)
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-row ",
    style: {
      direction: "ltr"
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "relative w-full "
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: " flex flex-col w-full",
    style: {
      color: themeObj.colorText
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-row ",
    style: {
      direction: ""
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "Input Input--empty focus:outline-none transition-shadow ease-out duration-200 border border-gray-300 focus:border-[#006DF9] rounded-md text-sm " + match$2[0],
    id: id,
    style: {
      background: themeObj.colorBackground,
      height: "50px",
      padding: themeObj.spacingUnit,
      width: "100%"
    }
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_ErrorComponent_bs_js__WEBPACK_IMPORTED_MODULE_5__.make, {
    errorStr: rescript_lib_es6_caml_option_js__WEBPACK_IMPORTED_MODULE_2__.some(props.errorStr)
  })))));
}
var make = VGSInputComponent;

/* react Not a pure module */

/***/ }),

/***/ "./src/VGSVault/VGSVault.bs.js":
/*!*************************************!*\
  !*** ./src/VGSVault/VGSVault.bs.js ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ $$default),
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @rescript/core/src/Core__Option.bs.js */ "./node_modules/@rescript/core/src/Core__Option.bs.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./VGSHelpers.bs.js */ "./src/VGSVault/VGSHelpers.bs.js");
/* harmony import */ var _Hooks_CommonHooks_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Hooks/CommonHooks.bs.js */ "./src/Hooks/CommonHooks.bs.js");
/* harmony import */ var _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Types/ConfirmType.bs.js */ "./src/Types/ConfirmType.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _VGSConstants_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./VGSConstants.bs.js */ "./src/VGSVault/VGSConstants.bs.js");
/* harmony import */ var _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Utilities/VaultHelpers.bs.js */ "./src/Utilities/VaultHelpers.bs.js");
/* harmony import */ var _Components_DynamicFields_bs_js__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Components/DynamicFields.bs.js */ "./src/Components/DynamicFields.bs.js");
/* harmony import */ var _Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Utilities/RecoilAtomsV2.bs.js */ "./src/Utilities/RecoilAtomsV2.bs.js");
/* harmony import */ var _Components_ErrorComponent_bs_js__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Components/ErrorComponent.bs.js */ "./src/Components/ErrorComponent.bs.js");
/* harmony import */ var _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../Utilities/PaymentHelpers.bs.js */ "./src/Utilities/PaymentHelpers.bs.js");
/* harmony import */ var _VGSInputComponent_bs_js__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./VGSInputComponent.bs.js */ "./src/VGSVault/VGSInputComponent.bs.js");
/* harmony import */ var _Utilities_PaymentManagementBody_bs_js__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../Utilities/PaymentManagementBody.bs.js */ "./src/Utilities/PaymentManagementBody.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE


















function VGSVault(props) {
  var vaultMode = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtomsV2_bs_js__WEBPACK_IMPORTED_MODULE_12__.vaultMode);
  var loggerState = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.loggerAtom);
  var isManualRetryEnabled = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.isManualRetryEnabled);
  var sessionToken = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.sessions);
  var areRequiredFieldsValid = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.areRequiredFieldsValid);
  var areRequiredFieldsEmpty = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.areRequiredFieldsEmpty);
  var match = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_8__.configAtom);
  var localeString = match.localeString;
  var themeObj = match.themeObj;
  var match$1 = match.config.appearance;
  var innerLayout = match$1.innerLayout;
  var match$2 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var match$3 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var match$4 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var match$5 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var setForm = match$5[1];
  var form = match$5[0];
  var match$6 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var setCardField = match$6[1];
  var match$7 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var setExpiryField = match$7[1];
  var match$8 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {});
  var setCVCField = match$8[1];
  var match$9 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setVgsCardError = match$9[1];
  var vgsCardError = match$9[0];
  var match$10 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setVgsExpiryError = match$10[1];
  var vgsExpiryError = match$10[0];
  var match$11 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setVgsCVCError = match$11[1];
  var vgsCVCError = match$11[0];
  var match$12 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setId = match$12[1];
  var id = match$12[0];
  var match$13 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return "";
  });
  var setVgsEnv = match$13[1];
  var vgsEnv = match$13[0];
  var match$14 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var requiredFieldsBody = match$14[0];
  var intent = _Utilities_PaymentHelpers_bs_js__WEBPACK_IMPORTED_MODULE_14__.usePaymentIntent(loggerState, "Card");
  var status = _Hooks_CommonHooks_bs_js__WEBPACK_IMPORTED_MODULE_6__.useScript(_VGSConstants_bs_js__WEBPACK_IMPORTED_MODULE_9__.vgsScriptURL, undefined);
  _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.handleVGSField(match$6[0], match$2[1], setVgsCardError);
  _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.handleVGSField(match$7[0], match$4[1], setVgsExpiryError);
  _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.handleVGSField(match$8[0], match$3[1], setVgsCVCError);
  var initializeVGSFields = function (vault) {
    setCardField(function (param) {
      return vault.field("#vgs-cc-number", _VGSConstants_bs_js__WEBPACK_IMPORTED_MODULE_9__.cardNumberOptions);
    });
    setExpiryField(function (param) {
      return vault.field("#vgs-cc-expiry", _VGSConstants_bs_js__WEBPACK_IMPORTED_MODULE_9__.cardExpiryOptions(localeString.expiryPlaceholder, vault));
    });
    setCVCField(function (param) {
      return vault.field("#vgs-cc-cvc", _VGSConstants_bs_js__WEBPACK_IMPORTED_MODULE_9__.cardCvcOptions);
    });
    setForm(function (param) {
      return vault;
    });
  };
  var handleVGSErrors = function (vgsState) {
    var dict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(vgsState);
    setVgsCardError(function (param) {
      return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(dict, "card_number", undefined, localeString);
    });
    setVgsExpiryError(function (param) {
      return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(dict, "card_exp", undefined, localeString);
    });
    setVgsCVCError(function (param) {
      return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(dict, "card_cvc", undefined, localeString);
    });
  };
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    var match = _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getVGSVaultDetails(sessionToken, _Utilities_VaultHelpers_bs_js__WEBPACK_IMPORTED_MODULE_10__.getVaultNameFromMode(vaultMode));
    var vaultEnv = match.vaultEnv;
    var vaultId = match.vaultId;
    setVgsEnv(function (param) {
      return vaultEnv;
    });
    setId(function (param) {
      return vaultId;
    });
  }, [sessionToken, vaultMode]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (status === "ready" && id !== "" && vgsEnv !== "") {
      var vault = VGSCollect.create(id, vgsEnv, handleVGSErrors);
      initializeVGSFields(vault);
    }
  }, [id, vgsEnv, status]);
  var submitCallback = react__WEBPACK_IMPORTED_MODULE_0__.useCallback(function (ev) {
    var json = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.safeParse(ev.data);
    var confirm = _Types_ConfirmType_bs_js__WEBPACK_IMPORTED_MODULE_7__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(json));
    if (!confirm.doSubmit) {
      return;
    }
    if (form !== undefined) {
      var emptyPayload = {};
      var onSuccess = function (param, data) {
        var match = _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.getTokenizedData(data);
        var cardBody = _Utilities_PaymentManagementBody_bs_js__WEBPACK_IMPORTED_MODULE_16__.vgsCardBody(match[0], match[1], match[2], match[3]);
        if (areRequiredFieldsValid && !areRequiredFieldsEmpty) {
          return intent(false, _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.mergeAndFlattenToTuples(cardBody, requiredFieldsBody), confirm.confirmParams, undefined, undefined, undefined, isManualRetryEnabled, true);
        } else {
          return _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.postFailedSubmitResponse("validation_error", localeString.enterValidDetailsText);
        }
      };
      var onError = function (err) {
        var errorDict = _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(err);
        setVgsCardError(function (param) {
          return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(errorDict, "card_number", true, localeString);
        });
        setVgsExpiryError(function (param) {
          return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(errorDict, "card_exp", true, localeString);
        });
        setVgsCVCError(function (param) {
          return _VGSHelpers_bs_js__WEBPACK_IMPORTED_MODULE_5__.vgsErrorHandler(errorDict, "card_cvc", true, localeString);
        });
      };
      return form.submit("/post", emptyPayload, onSuccess, onError);
    }
    console.error("VGS Vault not initialized for submission");
  }, [form, requiredFieldsBody, areRequiredFieldsValid, areRequiredFieldsEmpty]);
  _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.useSubmitPaymentData(submitCallback);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "animate-slowShow"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col",
    style: {
      gridGap: themeObj.spacingGridColumn
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-col w-full",
    style: {
      gridGap: themeObj.spacingGridColumn
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    condition: innerLayout === "Compressed",
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      style: {
        fontSize: themeObj.fontSizeLg,
        marginBottom: "5px",
        opacity: "0.6"
      }
    }, localeString.cardHeader)
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_VGSInputComponent_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
    fieldName: localeString.cardNumberLabel,
    id: "vgs-cc-number",
    isFocused: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.getOr(match$2[0], false),
    errorStr: vgsCardError
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: "flex flex-row w-full place-content-between",
    style: {
      gridColumnGap: innerLayout === "Spaced" ? themeObj.spacingGridRow : ""
    }
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: innerLayout === "Spaced" ? "w-[47%]" : "w-[50%]"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_VGSInputComponent_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
    fieldName: localeString.validThruText,
    id: "vgs-cc-expiry",
    isFocused: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.getOr(match$4[0], false),
    errorStr: vgsExpiryError
  })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
    className: innerLayout === "Spaced" ? "w-[47%]" : "w-[50%]"
  }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_VGSInputComponent_bs_js__WEBPACK_IMPORTED_MODULE_15__.make, {
    fieldName: localeString.cvcTextLabel,
    id: "vgs-cc-cvc",
    isFocused: _rescript_core_src_Core_Option_bs_js__WEBPACK_IMPORTED_MODULE_2__.getOr(match$3[0], false),
    errorStr: vgsCVCError
  }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_ErrorComponent_bs_js__WEBPACK_IMPORTED_MODULE_13__.make, {
    cardError: vgsCardError,
    expiryError: vgsExpiryError,
    cvcError: vgsCVCError
  }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_DynamicFields_bs_js__WEBPACK_IMPORTED_MODULE_11__.make, {
    paymentMethod: "card",
    paymentMethodType: "credit",
    setRequiredFieldsBody: match$14[1]
  }))));
}
var make = VGSVault;
var $$default = VGSVault;

/* react Not a pure module */

/***/ }),

/***/ "./src/WalletElement.bs.js":
/*!*********************************!*\
  !*** ./src/WalletElement.bs.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   make: () => (/* binding */ make)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var recoil__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! recoil */ "./node_modules/recoil/es/index.js");
/* harmony import */ var rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rescript/lib/es6/jsxPPXReactSupportU.js */ "./node_modules/rescript/lib/es6/jsxPPXReactSupportU.js");
/* harmony import */ var _Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Utilities/Utils.bs.js */ "./src/Utilities/Utils.bs.js");
/* harmony import */ var _Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./Components/RenderIf.bs.js */ "./src/Components/RenderIf.bs.js");
/* harmony import */ var _Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Utilities/RecoilAtoms.bs.js */ "./src/Utilities/RecoilAtoms.bs.js");
/* harmony import */ var _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./Utilities/PaymentUtils.bs.js */ "./src/Utilities/PaymentUtils.bs.js");
/* harmony import */ var _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./hyper-log-catcher/ErrorBoundary.bs.js */ "./src/hyper-log-catcher/ErrorBoundary.bs.js");
/* harmony import */ var _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./Payments/PaymentMethodsRecord.bs.js */ "./src/Payments/PaymentMethodsRecord.bs.js");
/* harmony import */ var _Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Payments/PaymentRequestButtonElement.bs.js */ "./src/Payments/PaymentRequestButtonElement.bs.js");
// Generated by ReScript, PLEASE EDIT WITH CARE











function WalletElement(props) {
  var sessionsObj = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.sessions);
  var methodslist = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.paymentMethodList);
  var match = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return {};
  });
  var setSessions = match[1];
  var sessions = match[0];
  var match$1 = react__WEBPACK_IMPORTED_MODULE_0__.useState(function () {
    return [];
  });
  var setWalletOptions = match$1[1];
  var walletOptions = match$1[0];
  var match$2 = recoil__WEBPACK_IMPORTED_MODULE_1__.useRecoilValue(_Utilities_RecoilAtoms_bs_js__WEBPACK_IMPORTED_MODULE_5__.keys);
  var setPaymentMethodListValue = recoil__WEBPACK_IMPORTED_MODULE_1__.useSetRecoilState(_Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__.paymentMethodListValue);
  var match$3 = _Utilities_PaymentUtils_bs_js__WEBPACK_IMPORTED_MODULE_6__.useGetPaymentMethodList([], props.paymentType, sessions);
  var walletList = match$3[0];
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (typeof methodslist === "object" && methodslist.TAG === "Loaded") {
      var plist = _Payments_PaymentMethodsRecord_bs_js__WEBPACK_IMPORTED_MODULE_8__.itemToObjMapper(_Utilities_Utils_bs_js__WEBPACK_IMPORTED_MODULE_3__.getDictFromJson(methodslist._0));
      setWalletOptions(function (param) {
        return walletList;
      });
      setPaymentMethodListValue(function (param) {
        return plist;
      });
    }
  }, [methodslist, walletList]);
  react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
    if (typeof sessionsObj === "object" && sessionsObj.TAG === "Loaded") {
      var ssn = sessionsObj._0;
      setSessions(function (param) {
        return ssn;
      });
    }
  }, [sessionsObj]);
  return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Components_RenderIf_bs_js__WEBPACK_IMPORTED_MODULE_4__.make, {
    condition: walletOptions.length > 0,
    children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", {
      className: "flex flex-col place-items-center"
    }, rescript_lib_es6_jsxPPXReactSupportU_js__WEBPACK_IMPORTED_MODULE_2__.createElementWithKey("payment_request_buttons_all", _hyper_log_catcher_ErrorBoundary_bs_js__WEBPACK_IMPORTED_MODULE_7__.make, {
      children: /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_0__.createElement(_Payments_PaymentRequestButtonElement_bs_js__WEBPACK_IMPORTED_MODULE_9__.make, {
        sessions: sessions,
        walletOptions: walletOptions
      }),
      level: "RequestButton",
      componentName: "WalletElement",
      publishableKey: match$2.publishableKey
    }))
  });
}
var make = WalletElement;

/* react Not a pure module */

/***/ })

}]);
//# sourceMappingURL=src_PaymentElementRenderer_bs_js.js.map